/* 8-5-17 */
ALTER TABLE `qc_quotes` ADD COLUMN `qc_fav_count` INT(11) NULL AFTER `qc_type`; 
/* 5-1-17 */
CREATE TABLE `qc_picture_quote` (
  `qc_pic_quote_id` int(10) NOT NULL AUTO_INCREMENT,
  `qc_pic_quote_qc_id` int(11) DEFAULT NULL,
  `qc_pic_quote_acolor` varchar(20) DEFAULT NULL,
  `qc_pic_quote_afont` varchar(20) DEFAULT NULL,
  `qc_pic_quote_afontsize` int(10) DEFAULT NULL,
  `qc_pic_quote_afontstyle` varchar(20) DEFAULT 'normal',
  `qc_pic_quote_ax` int(10) DEFAULT NULL,
  `qc_pic_quote_ay` int(10) DEFAULT NULL,
  `qc_pic_quote_bgcolor` varchar(20) DEFAULT NULL,
  `qc_pic_quote_picture_original` text,
  `qc_pic_quote_picture` text,
  `qc_pic_quote_picture_preview` text,
  `qc_pic_quote_qalign` varchar(20) DEFAULT 'left',
  `qc_pic_quote_qcolor` varchar(20) DEFAULT NULL,
  `qc_pic_quote_qfont` varchar(20) DEFAULT NULL,
  `qc_pic_quote_qfontsize` int(10) DEFAULT NULL,
  `qc_pic_quote_qfontstyle` varchar(20) DEFAULT 'normal',
  `qc_pic_quote_qmaxheight` int(10) DEFAULT NULL,
  `qc_pic_quote_qwidth` int(10) DEFAULT NULL,
  `qc_pic_quote_qx` int(10) DEFAULT NULL,
  `qc_pic_quote_qy` int(10) DEFAULT NULL,
  `qc_pic_quote_created_at` datetime DEFAULT NULL,
  `qc_pic_quote_updated_at` datetime DEFAULT NULL,
  `qc_pic_quote_created_status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`qc_pic_quote_id`)
)
ALTER TABLE `quotes`.`qc_quotes` ADD COLUMN `qc_pic_bottom` TEXT NULL AFTER `qc_name`;
ALTER TABLE `quotes`.`qc_quotes` ADD COLUMN `qc_type` TINYINT DEFAULT 1 NULL AFTER `qc_quote_short_flag`; 
/* 4-27-2017 */
ALTER TABLE `qc_authors` ADD COLUMN `au_now` TINYINT NULL AFTER `au_updated_at`; 
ALTER TABLE `qc_authors` ADD COLUMN `au_profession` VARCHAR(200) NULL AFTER `au_now`; 
 ALTER TABLE `qc_quotes` ADD COLUMN `qc_quote_short_flag` SMALLINT(5) NULL AFTER `qc_quote_of_day_date`; 
/* 4-24-2017 */
ALTER TABLE `quotes`.`qc_quotes` ADD COLUMN `qc_approved` TINYINT NULL AFTER `qc_clip`; 
ALTER TABLE `quotes`.`qc_users` ADD COLUMN `u_subscribe` TINYINT NULL COMMENT '1:subscribe,0:unsubscribe' AFTER `u_social_logout`; 
/* End */
/*02-11-2016*/
ALTER TABLE `quotes`.`qc_categories` ADD COLUMN `qc_cat_pic` VARCHAR(150) NULL AFTER `qc_cat_popular`; 
/* 28_10_2016 */
ALTER TABLE `quotes`.`qc_quotes` ADD COLUMN `qc_quote_of_day_date` DATETIME NULL AFTER `qc_updated_at`;

/* 15_10_16*/
ALTER TABLE `quotes`.`qc_users` ADD COLUMN `u_updated_at` DATETIME NULL AFTER `u_created_at`; 
/* 13_10_16 */
ALTER TABLE `qc_quotes` ADD FULLTEXT INDEX `FullText` (qc_name ASC, qc_tags ASC); 
/* 06-10-16*/
ALTER TABLE `quotes`.`qc_categories` CHANGE `qc_created_at` `qc_cat_created_at` DATETIME NULL, CHANGE `qc_updated_at` `qc_cat_updated_at` DATETIME NULL; 
/* 4/10/16 */
ALTER TABLE `quotes`.`qc_views` CHANGE `view_u_id` `view_u_id` VARCHAR(255) NULL;
ALTER TABLE `quotes`.`qc_views` ADD COLUMN `view_count` VARCHAR(255) NULL AFTER `view_qc_id`; 
ALTER TABLE `quotes`.`qc_views` CHANGE `view_count` `view_count` VARCHAR(255) CHARSET latin1 COLLATE latin1_swedish_ci DEFAULT '0' NULL;  
/* 29_9_16 */
ALTER TABLE `quotes`.`qc_categories` CHANGE `qc_cat_popular` `qc_cat_popular` INT(11) DEFAULT 0 NULL;
ALTER TABLE `quotes`.`qc_authors` ADD COLUMN `au_popular` INT(11) DEFAULT 0 NULL AFTER `au_wiki_link`;  

/* 25-10-2016 */
ALTER TABLE `quotes`.`qc_authors` ADD COLUMN `au_u_id` INT(11) NULL AFTER `au_id`; 