<?php
	$dir = sys_get_temp_dir();
	session_save_path($dir);
	include 'public/index.php';
	
	
?>