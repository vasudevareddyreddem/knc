* Includes: jQuery-2.1.4.min.js,https://code.jquery.com/ui/1.11.4/jquery-ui.min.js,bootstrap.min.js,
https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js,morris.min.js,query.sparkline.min.js,
jquery-jvectormap-1.2.2.min.js,jquery-jvectormap-world-mill-en.js,jquery.knob.js,
https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js,daterangepicker.js,bootstrap-datepicker.js,
bootstrap3-wysihtml5.all.min.js,jquery.slimscroll.min.js,fastclick.min.js,app.js,dashboard.js,demo.js