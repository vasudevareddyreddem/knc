<?php

class Social{
  
 function facebook(){
     $facebook = new Facebook(array(
		'appId'		=>  APP_ID,
		'secret'	=> APP_SECRET,
		'cookie'    => TRUE, /* Optional */
		));
		$user =null;
			//get the user facebook id		
			$user = $facebook->getUser();
			//echo $user;exit;
			if($user){
				try{
					//get the facebook user profile data
					$user_profile = $facebook->api('/me?fields=id,name,email');
					$params = array('next' => BASE_URL.'logout/logout');
					//logout url
					$logout =$facebook->getLogoutUrl($params);
					$fuser['User']=$user_profile;
					$fuser['facebook_logout']=$logout;
					return $fuser;
				}catch(FacebookApiException $e){
					error_log($e);
					$user = NULL;
				}		
			}
			if(empty($user)){
			  //login url	
			  $loginurl = $facebook->getLoginUrl(array(
							'scope'			=> 'email,publish_actions,user_birthday, user_location, user_work_history, user_hometown, user_photos',
							'redirect_uri'	=> BASE_URL.'social-sign-in?id=info',
							'display'=>'popup'
							));
			  header('Location: '.$loginurl);
			}
  
  }
    function google(){
	  
			global $client;
			
			$oauth2 = new Google_Oauth2Service($client);
			if (isset($_GET['code'])) {
			  $client->authenticate($_GET['code']);
			  $_SESSION['token'] = $client->getAccessToken();
			}
			if (isset($_SESSION['token'])) {
			 $client->setAccessToken($_SESSION['token']);
			}
			if (isset($_REQUEST['error'])) {
			 echo '<script type="text/javascript">window.close();</script>'; exit;
			}
			if ($client->getAccessToken()) {
			  $user = $oauth2->userinfo->get();
			  $user['User']=$user;
			  $_SESSION['token'] = $client->getAccessToken();
			  return $user;
			} else {
			  $authUrl = $client->createAuthUrl();
			  header('Location: '.$authUrl);
			
			}
      }
}
?>