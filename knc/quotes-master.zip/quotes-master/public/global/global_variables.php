<?php
	/* register subject */
global $regSubject;
global $regMessage;
$regSubject= "Registration confirmation";
$regMessage='<body>
	<div style="width:600px; font-family: Arial,sans-serif;font-size: 12px !important;line-height: 1.5;">
		<table  border="0" style="border-collapse: collapse; border:1px solid #E4E4E4;" cellpadding="10">
			<tr bgcolor="#03a9f4">
				<td width="50%"><a href="http://spreadthequote.com" alt="Spread the Quote" target="_blank" style="text-decoration: none;">
					<img src="http://spreadthequote.com/public/images/spread.png"></a>
				</td>
				<td width="50%" align="right"><a href="http://spreadthequote.com" target="_blank" style="text-decoration: none;">				
				</td>
			</tr>
			<tr>
				<td colspan="3">
					<p><a href="javascript:void(0);" style="font:bold 12px arial; color:#333; text-decoration:none;"><strong>Dear</strong>&nbsp;&nbsp;<FULLNAME>,</a></p>
					<p>Thanks for joining Spread the Quote.</p>
					<p>Thanks for signing up at Spread the Quote. Please click on the following link to verify your email address:</p>
					<center><a href="<REGLINK>" style="text-decoration: none; color:#428bca" ><p style="color:428bca"><span style="color:#fff;font-family:Trebuchet MS;font:normal 12px arial;background:rgba(0, 142, 214, 0.9) none repeat scroll 0 0;padding: 6px 17px 6px 10px;  border-radius: 20px;text-align:center;">Confirm your Email </span></p></a></center>					
					<p>Or copy and paste the following into your browser:</p>
					<p><a style="text-decoration: none; color:#428bca" href="<REGLINK>"><REGLINK></a></p>
				</td>
			</tr>
			<tr style="border:1px solid #E4E4E4;background-color:#e4e4e4;">
				<td colspan="3">  
				Regards,<br/>
				Spread the Quotes Team
				</td>
			</tr>
			<tr style="background-color:#000; text-align:center;">
				<td colspan="3">
					<a style="text-decoration: none; font-size:11px;color:#fff" href="http://spreadthequote.com" target="_blank">
					<strong>&copy; 2017 <span style="color:#fff">Spread the Quote</span>.  All Rights Reserved</strong>.
					</a>
				</td>
			</tr>
		</table>
	</div>
</body>';
/*End*/

/*forgetPassword*/
global $ForgotPassowrdSubject;
global $ForgotPasswordMessage;
$ForgotPassowrdSubject= "Password reset link from Spread the Quote";
$ForgotPasswordMessage='<body>
	<div style="width:600px; font-family: Arial,sans-serif;font-size: 12px !important;line-height: 1.5;">
		<table  border="0" style="border-collapse: collapse; border:1px solid #E4E4E4;" cellpadding="10">
			<tr bgcolor="#03a9f4">
				<td width="50%"><a href="http://spreadthequote.com" alt="Spread the Quote" target="_blank" style="text-decoration: none;">
					<img src="http://spreadthequote.com/public/images/spread.png"></a>
				</td>
				<td width="50%" align="right"><a href="http://spreadthequote.com" target="_blank" style="text-decoration: none;">				
				</td>
			</tr>
			<tr>
				<td colspan="3">
					<p><a href="javascript:void(0);" style="font:bold 12px arial; color:#333; text-decoration:none;"><strong>Dear</strong>&nbsp;&nbsp;<FULLNAME>,</a></p>
					<p>We have received a password reset request for your Spread The Quote account.</p>
					<p style="color:#333" align="center">Click below to reset your password.</p>
					<center><a href="<PASSWORDLINK>" style="text-decoration: none; color:#428bca" ><p style="color:428bca"><span style="color:#fff;font-family:Trebuchet MS;font:normal 12px arial;background:rgba(0, 142, 214, 0.9) none repeat scroll 0 0;padding: 6px 17px 6px 10px;  border-radius: 20px;text-align:center;">Reset Password </span></p></a></center>					
					<p>Or copy and paste the following into your browser:</p>
					<p><a style="text-decoration: none; color:#428bca" href="<PASSWORDLINK>"><PASSWORDLINK></a></p>
				</td>
			</tr>
			<tr style="border:1px solid #E4E4E4;background-color:#e4e4e4;">
				<td colspan="3">  
				Regards,<br/>
				Spread the Quotes Team
				</td>
			</tr>
			<tr style="background-color:#000; text-align:center;">
				<td colspan="3">
					<a style="text-decoration: none; font-size:11px;color:#fff" 
					href="http://spreadthequote.com" target="_blank"><strong>&copy; 2017 <span style="color:#fff">Spread the Quote</span>.  All Rights Reserved</strong>.</a>
				</td>
			</tr>
		</table>
	</div>
</body>';

/*forgetPassword*/
global $subscriptionSubject;
global $subscriptionMessage;
$subscriptionSubject= "Quote of the day";
$subscriptionMessage='<body>
	<div style="width:600px; font-family: Arial,sans-serif;font-size: 12px !important;line-height: 1.5;">
		<table  border="0" style="border-collapse: collapse; border:1px solid #E4E4E4;" cellpadding="10">
			<tr bgcolor="#03a9f4">
				<td width="50%"><a href="http://spreadthequote.com" alt="Spread the Quote" target="_blank" style="text-decoration: none;">
					<img src="http://spreadthequote.com/public/images/spread.png"></a>
				</td>
				<td width="50%" align="right"><a href="http://spreadthequote.com" target="_blank" style="text-decoration: none;">				
				</td>
			</tr>
			<tr>
				<td colspan="3">
					<p><a href="javascript:void(0);" style="font:bold 12px arial; color:#333; text-decoration:none;"><strong>Dear</strong>&nbsp;&nbsp;<USERNAME>,</a></p>
					<p>We have received a password reset request for your Spread The Quote account.</p>
					<p style="color:#333" align="center">Click below to Unsubscribe.</p>
					<center><a href="<UNSUBSCRIBELINK>" style="text-decoration: none; color:#428bca" ><p style="color:428bca"><span style="color:#fff;font-family:Trebuchet MS;font:normal 12px arial;background:rgba(0, 142, 214, 0.9) none repeat scroll 0 0;padding: 6px 17px 6px 10px;  border-radius: 20px;text-align:center;">UnSubscribe </span></p></a></center>				
				</td>
			</tr>
			<tr style="border:1px solid #E4E4E4;background-color:#e4e4e4;">
				<td colspan="3">  
				Regards,<br/>
				Spread the Quotes Team
				</td>
			</tr>
			<tr style="background-color:#000; text-align:center;">
				<td colspan="3">
					<a style="text-decoration: none; font-size:11px;color:#fff" 
					href="http://spreadthequote.com" target="_blank"><strong>&copy; 2017 <span style="color:#fff">Spread the Quote</span>.  All Rights Reserved</strong>.</a>
				</td>
			</tr>
		</table>
	</div>
</body>';

/*User Quote Confirmation*/
global $userAcceptQuoteSubject;
global $userAcceptQuoteMessage;
$userAcceptQuoteSubject = "Quote accepted";
$userAcceptQuoteMessage ='<body>
	<div style="width:600px; font-family: Arial,sans-serif;font-size: 12px !important;line-height: 1.5;">
		<table  border="0" style="border-collapse: collapse; border:1px solid #E4E4E4;" cellpadding="10">
			<tr bgcolor="#03a9f4">
				<td width="50%"><a href="http://spreadthequote.com" alt="Spread the Quote" target="_blank" style="text-decoration: none;">
					<img src="http://spreadthequote.com/public/images/spread.png"></a>
				</td>
				<td width="50%" align="right"><a href="http://spreadthequote.com" target="_blank" style="text-decoration: none;">				
				</td>
			</tr>
			<tr>
				<td colspan="3">
					<p style="color:#333" align="center">Your posted quote on spreadthequote is approved, You can the quote under user quotes section.</p>			
				</td>
			</tr>
			<tr style="border:1px solid #E4E4E4;background-color:#e4e4e4;">
				<td colspan="3">  
				Regards,<br/>
				Spread the Quotes Team
				</td>
			</tr>
			<tr style="background-color:#000; text-align:center;">
				<td colspan="3">
					<a style="text-decoration: none; font-size:11px;color:#fff" 
					href="http://spreadthequote.com" target="_blank"><strong>&copy; 2017 <span style="color:#fff">Spread the Quote</span>.  All Rights Reserved</strong>.</a>
				</td>
			</tr>
		</table>
	</div>
</body>';
/*User Quote Confirmation*/
global $userRejectQuoteSubject;
global $userRejectQuoteMessage;
$userRejectQuoteSubject = "Quote rejected";
$userRejectQuoteMessage ='<body>
	<div style="width:600px; font-family: Arial,sans-serif;font-size: 12px !important;line-height: 1.5;">
		<table  border="0" style="border-collapse: collapse; border:1px solid #E4E4E4;" cellpadding="10">
			<tr bgcolor="#03a9f4">
				<td width="50%"><a href="http://spreadthequote.com" alt="Spread the Quote" target="_blank" style="text-decoration: none;">
					<img src="http://spreadthequote.com/public/images/spread.png"></a>
				</td>
				<td width="50%" align="right"><a href="http://spreadthequote.com" target="_blank" style="text-decoration: none;">				
				</td>
			</tr>
			<tr>
				<td colspan="3">
					<p style="color:#333" >Your quote is rejected, Please contact at <a href="mailto:info@aapthitech.com" style="text-decoration:none;color:#fff">info@aapthitech.com</a> for details.</p>				
				</td>
			</tr>
			<tr style="border:1px solid #E4E4E4;background-color:#e4e4e4;">
				<td colspan="3">  
				Regards,<br/>
				Spread the Quotes Team
				</td>
			</tr>
			<tr style="background-color:#000; text-align:center;">
				<td colspan="3">
					<a style="text-decoration: none; font-size:11px;color:#fff" 
					href="http://spreadthequote.com" target="_blank"><strong>&copy; 2017 <span style="color:#fff">Spread the Quote</span>.  All Rights Reserved</strong>.</a>
				</td>
			</tr>
		</table>
	</div>
</body>';
?>