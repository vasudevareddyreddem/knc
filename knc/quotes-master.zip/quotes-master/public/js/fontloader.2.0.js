var loadedFonts = {};
var deferred = $.Deferred();

fontload = function()
{
    var _isInitialized = false;
    var _types = ['serif', 'sans-serif', 'monospace', 'cursive', 'fantasy'];
    var _text = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    function _init ()
    {
        if (_isInitialized){ return; }

        _isInitialized = true;

        $('body > :first-child').before(
            '<div id="fontdetectHelper"><span></span></div>'
        );
        $('#fontdetectHelper').css({
                'position': 'absolute',
                'visibility': 'hidden',
                'top': '-200px',
                'left': '-100000px',
                'width': '100000px',
                'height': '200px',
                'font-size': '100px',
        });
    }

    return {
        load: function(){
            var totalFonts = $.map(fonts, function(n, i) {
                return i;
            }).length;
            var processed = 0;
            var outerThis = this;
            console.log("Total: " + totalFonts);
            $.each(fonts, function(i, font) {
                console.log(font);
                var utStart = new Date().getTime();
                var idInterval = setInterval(
                    function() {
                        console.log(font);
                        if (outerThis.isLoaded(font)) {
                            if(font.indexOf(' Bold Italic') >=0){
                                var ifont = font.replace(' Bold Italic', '');
                                var style = 'i7';
                            } 
                            else if(font.indexOf(' Bold') >=0){
                                var ifont = font.replace(' Bold', '');
                                var style = 'n7';
                            }
                            else if(font.indexOf(' Italic') >=0){
                                var ifont = font.replace(' Italic', '');
                                var style = 'i4';
                            }
                            else {
                                var ifont = font;
                                var style = 'n4';
                            }
                            
                            if($.isArray(loadedFonts[ifont]) === false){
                                loadedFonts[ifont] = [];
                            }
                            loadedFonts[ifont][style] = true;

                            clearInterval(idInterval);

                            if (++processed === totalFonts) {
                                console.log('done');
                                deferred.resolve();
                            }
                            console.log(processed);
                            return;
                        }
                        else {
                            console.log("Trying to load font: " + font);

                            var utNow = new Date().getTime();
                            if ((utNow - utStart) > 20000) {
                                clearInterval(idInterval);
                                console.log('failed to load: ' + font );
                                if (++processed === totalFonts) {
                                    console.log('done');
                                    deferred.resolve();
                                }
                                return;
                            }
                            console.log(processed);
                            console.log("Still trying to load font: " + font);
                        }
                    },
                    1000
                );
            });
        },

        isLoaded: function (font){
            console.log("processing: " + font);    
            var wThisFont = 0;
            var wPrevFont = 0;

            if (!_isInitialized){	
                _init();
            }

            if(font.indexOf(' Bold Italic') >=0){
                $('#fontdetectHelper > SPAN').html('<b><i>' + _text + '</b></i>');
                font = font.replace(' Bold Italic', '');
            } else if(font.indexOf(' Italic') >=0){
                $('#fontdetectHelper > SPAN').html('<i>' + _text + '</i>');
                font = font.replace(' Italic', '');
            } else if(font.indexOf(' Bold') >=0){
                $('#fontdetectHelper > SPAN').html('<b>' + _text + '</b>');
                font = font.replace(' Bold', '');
            } else {
                $('#fontdetectHelper > SPAN').html(_text);
            }
            console.log($('#fontdetectHelper > SPAN').html());
            for(var ix = 0; ix < _types.length; ++ix)
            {
                var $helperSpan = $('#fontdetectHelper > SPAN');
                $helperSpan.css('font-family', font + ',' + _types[ix]);
                wThisFont = $helperSpan.width();
                if (ix > 0 && wThisFont != wPrevFont){
                    return false;
                }

                wPrevFont = wThisFont;
            }
            return true;
        },
                    
        onFontLoaded: function (font, onLoad, onFail, options){
            if (!font) { return; }

            var msInterval = (options && options.msInterval) ? options.msInterval : 100;
            var msTimeout  = (options && options.msTimeout) ? options.msTimeout : 2000;

            if (!onLoad && !onFail){ return; }

            if (!_isInitialized){ _init (); }

            if (this.isFontLoaded(font)){	
                if (onLoad){ onLoad(font); }
                return;
            }

            var outerThis = this;
            var utStart = new Date().getTime();
            var idInterval = setInterval (
                function(){

                    if (outerThis.isFontLoaded(font)){	
                        clearInterval(idInterval);
                        onLoad(font);
                        return;
                    }
                    else {	
                        var utNow = new Date().getTime();
                        if ((utNow - utStart) > msTimeout){
                            clearInterval (idInterval);
                            if (onFail){ onFail(font); }
                        }
                    }
                },
                msInterval
            );
        }
    };
}();

fontload.load(); 
