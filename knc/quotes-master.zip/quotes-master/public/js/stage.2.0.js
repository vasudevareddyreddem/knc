var stage = new Kinetic.Stage({
    container: 'container',
    width: 465,
    height: 360
});

var layer = new Kinetic.Layer();

var qtext = new Kinetic.Text({
    x: 15,
    y: 10,
    fontFamily: 'Arial',
    fontSize: 24,
    fontStyle: 'bold italic',
    text: '',
    fill: 'black',
    align: 'left',
    draggable: true,
});

var atext = new Kinetic.Text({
    x: 15,
    y: 30,
    fontFamily: 'Arial',
    fontSize: 24,
    fontStyle: 'bold italic',
    text: '',
    fill: 'black',
    align: 'left',
    draggable: true,
});

atext.on('dragend', function() {
    if (atext.x() < 0) {
        atext.x(0);
    }
    if (atext.y() < 0) {
        atext.y(0);
    }
    
    if((atext.x() + atext.width()) > 465) {
        atext.x(465 - atext.width());
    }

    if ((atext.y() + atext.height()) > 360 && atext.height() < 360) {
        atext.y(360 - atext.height());
    }

    layer.draw();
});

qtext.on('dragend', function() {
    if (qtext.x() < 0) {
        qtext.x(0);
    }
    if (qtext.y() < 0) {
        qtext.y(0);
    }

    if ((qtext.x() + qtext.width()) > 465) {
        qtext.x(465 - qtext.width());
    }

    if ((qtext.y() + qtext.height()) > 360 && qtext.height() < 360) {
        qtext.y(360 - qtext.height());
    }

    layer.draw();
});

var background = new Kinetic.Rect({
    x: 0,
    y: 0,
    width: 465,
    height: 360,
});

layer.add(background);
layer.add(qtext);
layer.add(atext);
stage.add(layer);

var images = {};
var preset = {"picture":"","bgcolor":"#0055aa","qfont":"Oswald","afont":"Oswald","qcolor":"ffffff","acolor":"ffffff","qfontsize":32,"afontsize":20,"qalign":"left","qx":15,"qy":10,"ax":60,"ay":210,"qwidth":440,"qfontstyle":"normal","afontstyle":"normal", "qmaxheight":128};
var preset = {"acolor":"f7c80a","afont":"Oswald","afontsize":"20","afontstyle":"normal","ax":"318","ay":"299","bgcolor":"","picture":"","qalign":"left","qcolor":"ecfae6","qfont":"Satisfy","qfontsize":"32","qfontstyle":"normal","qmaxheight":"224","qwidth":"400","qx":"33","qy":"66"}
function onFontLoaded(font){
    console.log('loaded: ' + font);
    reset(preset);
}

function onFailedLoad(font){
    console.log('not loaded: ' + font);
}

function reset(preset) {
    $('.upper').show();
    if (preset.qfont) {
        if(!fontload.isLoaded(preset.qfont)){
            fontload.onFontLoaded(preset.qfont, onFontLoaded, onFailedLoad, {msTimeout: 4000});
            return;
        }
        qtext.fontFamily("'" + preset.qfont + "'");

        var f = preset.qfont.charAt(0).toUpperCase();
        $('#qselected').text(f + preset.qfont.substr(1));
        $('#qselected').css("font-family", preset.qfont);
        
        qtext.fontStyle('italic bold');
        layer.draw();
    }

    if (preset.afont) {
        if(!fontload.isLoaded(preset.afont)){
            fontload.onFontLoaded(preset.afont, onFontLoaded, onFailedLoad, {msTimeout: 4000});
            return;
        }
        
        atext.fontFamily("'" + preset.afont + "'");

        var f = preset.afont.charAt(0).toUpperCase();
        $('#aselected').text(f + preset.afont.substr(1));
        $('#aselected').css("font-family", preset.afont);
        
        atext.fontStyle('italic bold');
        layer.draw();
    }
    console.log('cp');
    
    if (preset.qfontsize) {
        var qfz = parseInt(preset.qfontsize) || 20;
        qtext.fontSize(qfz);

        var qfontsizeselected = $('#qfontsize');
        var qfontsizelist = $('.qfontsizelist');

        qfontsizeselected.removeClass('active');
        qfontsizelist.removeClass('active');

        qfontsizeselected.text(qfz + 'px');
        $('.qfontsizelist > li').each(function() {
            $(this).removeClass('active');
            if ($(this).attr('data-value') == qfz) {
                $(this).addClass('active');
            }
        });
    }

    if (preset.afontsize) {
        var afz = parseInt(preset.afontsize) || 20;
        atext.fontSize(afz);

        var afontsizeselected = $('#afontsize');
        var afontsizelist = $('.afontsizelist');

        afontsizeselected.removeClass('active');
        afontsizelist.removeClass('active');

        afontsizeselected.text(afz + 'px');
        $('.afontsizelist > li').each(function() {
            $(this).removeClass('active');
            if ($(this).attr('data-value') == afz) {
                $(this).addClass('active');
            }
        });
    }

    if (preset.qx) {
        var x = parseInt(preset.qx);
        qtext.x(x);
    }

    if (preset.qy) {
        var y = parseInt(preset.qy);
        qtext.y(y);
    }

    if (preset.ax) {
        var x = parseInt(preset.ax);
        atext.x(x);
    }

    if (preset.ay) {
        var y = parseInt(preset.ay);
        atext.y(y);
    }

    if (preset.qwidth) {
        var qwidth = parseInt(preset.qwidth) || 0;
        if (qwidth > 0) {
            qtext.width(qwidth);
            $('#qwidth').text(qwidth);
        } else {
            qtext.width("auto");
        }
    } else {
        qtext.width(440);
        qtext.x(15);
    }

    if (preset.qalign) {
        $('#qleft, #qright, #qcenter').removeClass('activeAlign');
        qtext.align(preset.qalign);
        $('#q' + preset.qalign).addClass('activeAlign');
    }

    if (preset.qcolor) {
        qtext.fill('#' + preset.qcolor);
        $('.qcolor-box').css('background-color', '#' + preset.qcolor);
        $('.qcolor-box').colpickSetColor('#' + preset.qcolor);
    }

    if (preset.acolor) {
        atext.fill('#' + preset.acolor);
        $('.acolor-box').css('background-color', '#' + preset.acolor);
        $('.acolor-box').colpickSetColor('#' + preset.acolor);
    }

    checkQFontStyle(preset.qfont, preset.qfontstyle);
    checkAFontStyle(preset.afont, preset.afontstyle);
    
    if (preset.qmaxheight) {
        var qmaxheight = parseInt(preset.qmaxheight) || 128;
        resizeFont(qmaxheight);
    }
    
    checkAText();
    checkQText();

    if (preset.picture && preset.picture !== '' ) {
		$('#upload_original_image').val(preset.picture);
        images['presetpic'] = new Image();
        images['presetpic'].src = preset.picture;

        images['presetpic'].onload = function() {
            background.fill(null);
            background.fillPatternImage(images['presetpic']);
            background.fillPatternOffset({x: 0, y: 0});
            layer.draw();
            $('.upper').hide();
        };
    } else if(preset.bgcolor) {
        background.fill(preset.bgcolor);
        layer.draw();
        $('.upper').hide();
    }
}

function checkQText() {
    var width = parseInt($('#qwidth').text()) || 0;
    if (width === 0) {
        qtext.width('auto');

        var qtextwidth = qtext.width();

        if (qtextwidth > 465) {
            qtext.x(0);
            qtext.width(465);
        }
    }
    
    if((qtext.x() + qtext.width()) > 465) {
        qtext.x(460 - qtext.width());
    }

    if((qtext.y() + qtext.height()) > 360 && qtext.height() < 360) {
        qtext.y(355 - qtext.height());
    }
}

function checkAText() {
    var atextwidth = atext.width();
    
    atext.width('auto');
    
    if (atextwidth > 465) {
        atext.x(15);
        atext.width(440);
    }

    if((atext.x() + atext.width()) >= 465) {
        atext.x(460 - atext.width());
    }
}

function checkQFontStyle(fontName, style){
    $('#qbold, #qitalic').removeClass('mix').removeClass('disable').removeClass('activeAlign');
    
    qtext.fontStyle('italic bold');
    layer.draw();
    
    if ($.browser.mozilla === true) {
        var font = loadedFonts[fontName];
        if(font !== undefined && font['i7'] !== undefined){
            $('#qbold, #qitalic').addClass('mix');
        }

        if(font === undefined || font['i4'] === undefined){
            $('#qitalic').addClass('disable');
        }

        if(font === undefined || font['n7'] === undefined){
            $('#qbold').addClass('disable');
        }

        if(style === undefined || style === ''){
            qtext.fontStyle('normal normal');
            return;
        }
        
        if(style.indexOf('italic') >=0 && style.indexOf('bold') >=0 && font['i7'] !== undefined){
            qtext.fontStyle('italic bold');
            $('#qitalic, #qbold').addClass('activeAlign');
        } else if(style.indexOf('italic') >=0  && font['i4'] !== undefined){
            qtext.fontStyle('italic normal');
            $('#qitalic').addClass('activeAlign');
        } else if(style.indexOf('bold') >=0 && font['n7'] !== undefined){
            qtext.fontStyle('normal bold');
            $('#qbold').addClass('activeAlign');
        } else {
            qtext.fontStyle('normal normal');
        }
    } else {
        $('#qbold, #qitalic').addClass('mix');
        
        if(style === undefined || style === ''){
            qtext.fontStyle('normal normal');
            return;
        }
        
        if(style.indexOf('italic') >=0 && style.indexOf('bold') >=0){
            qtext.fontStyle('italic bold');
            $('#qitalic, #qbold').addClass('activeAlign');
        } else if(style.indexOf('italic') >=0) {
            qtext.fontStyle('italic normal');
            $('#qitalic').addClass('activeAlign');
        } else if (style.indexOf('bold') >=0) {
            qtext.fontStyle('normal bold');
            $('#qbold').addClass('activeAlign');
        } else {
            qtext.fontStyle('normal normal');
            return;
        }
    }
}

function checkAFontStyle(fontName, style){
    $('#abold, #aitalic').removeClass('mix').removeClass('disable').removeClass('activeAlign');
    
    atext.fontStyle('italic bold');
    layer.draw();
    
    if ($.browser.mozilla === true) {
        var font = loadedFonts[fontName];
        if(font !== undefined && font['i7'] !== undefined){
            $('#abold, #aitalic').addClass('mix');
        }

        if(font === undefined || font['i4'] === undefined){
            $('#aitalic').addClass('disable');
        }

        if(font === undefined || font['n7'] === undefined){
            $('#abold').addClass('disable');
        }

        if(style === undefined || style === ''){
            atext.fontStyle('normal normal');
            return;
        }
        
        if(style.indexOf('italic') >=0 && style.indexOf('bold') >=0 && font['i7'] !== undefined){
            atext.fontStyle('italic bold');
            $('#aitalic, #abold').addClass('activeAlign');
        } else if(style.indexOf('italic') >=0  && font['i4'] !== undefined){
            atext.fontStyle('italic normal');
            $('#aitalic').addClass('activeAlign');
        } else if(style.indexOf('bold') >=0 && font['n7'] !== undefined){
            atext.fontStyle('normal bold');
            $('#abold').addClass('activeAlign');
        } else {
            atext.fontStyle('normal normal');
        }
    } else {
        $('#abold, #aitalic').addClass('mix');
        
        if(style === undefined || style === ''){
            atext.fontStyle('normal normal');
            return;
        }
       
        if(style.indexOf('italic') >=0 && style.indexOf('bold') >=0){
            atext.fontStyle('italic bold');
            $('#aitalic, #abold').addClass('activeAlign');
        } else if(style.indexOf('italic') >=0) {
            atext.fontStyle('italic normal');
            $('#aitalic').addClass('activeAlign');
        } else if (style.indexOf('bold') >=0) {
            atext.fontStyle('normal bold');
            $('#abold').addClass('activeAlign');
        } else {
            atext.fontStyle('normal normal');
        }
    }
}

function resizeFont(maxheight){
    var height = qtext.height();
    var fontSize = qtext.fontSize();

    if(height > maxheight){
        for (var i = fontSize; i > 10; i -= 2)
        { 
            qtext.fontSize(i);
            if(qtext.height() <= maxheight) break;
        }
        
        var qfontsizeselected = $('#qfontsize');
        var qfontsizelist = $('.qfontsizelist');

        qfontsizeselected.removeClass('active');
        qfontsizelist.removeClass('active');

        qfontsizeselected.text(i + 'px');
        $('.qfontsizelist > li').each(function() {
            if ($(this).attr('data-value') == i) {
                $(this).addClass('active');
            }
        });
    }
}

$(document).ready(function(){
    $('#upload').click(function() {
        var form = new FormData($('#uploadform')[0]);
		if($('#uploadFileImage').val() != ""){
			switch($('#uploadFileImage').val().substring($('#uploadFileImage').val().lastIndexOf('.') + 1).toLowerCase()){
				case 'png': case 'jpg': case 'jpeg':case 'jpe':
					$('.upper').show();
					$.ajax({
						url: baseUrl+"upload-make-picture",
						type: "POST",
						xhr: function() {
							var myXhr = $.ajaxSettings.xhr();
							if(myXhr.upload){
								$('.progress').show();
								myXhr.upload.addEventListener('progress',progressHandlingFunction, false);
							}
							return myXhr;
						},
						data: form,
						contentType: false,
						processData: false,
						dataType: "json",
						cache: false,
						success: function(ohtml) {
							var html = ohtml.output;
							if (typeof html.error !== 'undefined') {
								alert(html.error);
								$('.upper').hide();
								return;
							}

							if (typeof html.url !== 'undefined') {
								$('#uploadFileImage').val('');
								$('#upload_original_image').val(html.original);
								images['uploaded'] = new Image();
								images['uploaded'].src = html.url;

								images['uploaded'].onload = function() {
									background.fill(null);
									background.fillPatternImage(images['uploaded']);
									background.fillPatternOffset({x: 0, y: 0});

									$('.upper').hide();
									$('.progress').text('').hide();
									
									qtext.text($("#qtext").val());
									checkQText();
									atext.text($("#atext").val());
									checkAText();
									
									layer.draw();
								};
							} else {
								$('.upper').hide();
								$('.progress').text('').hide();
							}
						}
					});
				break;
				default:
				$('#uploadFileImage').val('');
				alert('Please upload JPG,JPEG,JPE and PNG formats');
				break;
			}
		}else{
			$('.upper').hide();
			alert('Please select image.');
		}
    });
    
    function progressHandlingFunction(e) {
        if (e.lengthComputable) {
            var percentComplete = Math.round((e.loaded / e.total) * 100);
            $('.progress').text(percentComplete + '%');
        }
    }

    $('#save-preset').click(function() {
        $('.upper').show();
        
        var image = background.fillPatternImage();
        
        if(image !== undefined && image.src !== undefined){
            var picture = image.src;
            var bgcolor = '';
        } else {
            var picture = '';
            var bgcolor = background.fill();
        }

        var qx = qtext.x();
        var qy = qtext.y();
        var ax = atext.x();
        var ay = atext.y();

        var qcolor = qtext.fill();
        var acolor = atext.fill();

        var qfontsize = qtext.fontSize();
        var afontsize = atext.fontSize();

        var qfont = qtext.fontFamily();
        var afont = atext.fontFamily();

        var qalign = qtext.align();
        var qwidth = parseInt($("#qwidth").text()) || 'auto';
        
        var qfontstyle = qtext.fontStyle();
        var afontstyle = atext.fontStyle();
        
        var qmaxheight = parseInt(qtext.height()) + parseInt(qtext.fontSize());

        var presetToSave = {"picture": picture, "bgcolor": bgcolor, "qfont": qfont, "afont": afont, "qcolor": qcolor, "acolor": acolor, "qfontsize": qfontsize, "afontsize": afontsize, "qalign": qalign, "qx": qx, "qy": qy, "ax": ax, "ay": ay, "qwidth": qwidth, "qfontstyle":qfontstyle, "afontstyle":afontstyle,"qmaxheight":qmaxheight};

        stage.toDataURL({
            callback: function(dataUrl) {
                $.ajax({
                    url: "/ajax/pq/save_preset/",
                    type: "POST",
                    data: {
                        base64data: dataUrl,
                        preset: presetToSave
                    },
                    dataType: "json",
                    cache: false,
                    success: function(html) {
                        if (typeof html.error !== 'undefined') {
                            alert(html.error);
                            $('.upper').hide();
                            return;
                        }

                        if (typeof html.status !== 'undefined') {
                            alert('saved!');
                            $('.upper').hide();
                        } else {
                            $('.upper').hide();
                        }
                    }
                });
            }
        });
    });

    $("#qtext").keyup(function() {
        qtext.text($("#qtext").val());
        checkQText();
        layer.draw();
    });

    $("#atext").keyup(function() {
        atext.text($("#atext").val());
        checkAText();
        layer.draw();
    });

    $("#qleft").click(function() {
        $("#qcenter, #qright").removeClass('activeAlign');
        $("#qleft").addClass('activeAlign');
        qtext.align("left");
        layer.draw();
    });

    $("#qcenter").click(function() {
        $("#qleft, #qright").removeClass('activeAlign');
        $("#qcenter").addClass('activeAlign');
        qtext.align("center");
        layer.draw();
    });

    $("#qright").click(function() {
        $("#qleft, #qcenter").removeClass('activeAlign');
        $("#qright").addClass('activeAlign');
        qtext.align("right");
        layer.draw();
    });

    $("#qfontsize").change(function() {
        qtext.fontSize($("#qfontsize option:selected").val());
        checkQText();
        layer.draw();
    });

    $("#aleft").click(function() {
        $("#acenter, #aright").removeClass('activeAlign');
        $("#aleft").addClass('activeAlign');
        atext.align("left");
        layer.draw();
    });

    $("#acenter").click(function() {
        $("#aleft, #aright").removeClass('activeAlign');
        $("#acenter").addClass('activeAlign');
        atext.align("center");
        layer.draw();
    });

    $("#aright").click(function() {
        $("#aleft, #acenter").removeClass('activeAlign');
        $("#aright").addClass('activeAlign');
        atext.align("right");
        layer.draw();
    });

    $("#afontsize").change(function() {
        atext.fontSize($("#afontsize option:selected").val());
        checkAText();
        layer.draw();
    });

    $('.qcolor-box').colpick({
        layout: 'hex',
        color: preset.qcolor || '000000',
        submit: 0,
        onChange: function(hsb, hex, rgb, el) {
            $(el).css('background-color', '#' + hex);
            qtext.fill('#' + hex);
            layer.draw();
        }
    });

    $('.acolor-box').colpick({
        layout: 'hex',
        color: preset.acolor || '000000',
        submit: 0,
        onChange: function(hsb, hex, rgb, el) {
            $(el).css('background-color', '#' + hex);
            atext.fill('#' + hex);
            layer.draw();
        }
    });

    $('.bgcolor-box').colpick({
        layout: 'hex',
        submit: 0,
        onChange: function(hsb, hex, rgb, el) {
            $(el).css('background-color', '#' + hex);
            background.fill('#' + hex);
            layer.draw();
        }
    });
    
    $("#qwidth").keypress(function(event) {
        var code = event.keyCode || event.which;
        if (code === 13) {
            var width = parseInt($(this).text());

            if (width > 0 && width <= 465) {
                qtext.width(width);
            } else if (width > 465) {
                qtext.x(0);
                qtext.width(465);
                $("#qwidth").text(465);
            } else {
                qtext.width('auto');
            }
            checkQText();
            layer.draw();

            $(this).blur();
            event.preventDefault();
        }
    });
   
    var nav = $('#qselected');
    var selection = $('.qselect');
    var select = selection.find('li');

    nav.click(function(event) {
        if (nav.hasClass('active')) {
            nav.removeClass('active');
            selection.stop().slideUp(120);
        } else {
            nav.addClass('active');
            selection.stop().slideDown(200);
        }
        event.preventDefault();
    });

    select.click(function(event) {
        select.removeClass('active');
        $(this).addClass('active');
        qtext.fontFamily($(this).attr('data-value'));

        nav.text($(this).text());
        nav.css("font-family", $(this).attr('data-value'));

        selection.stop().slideUp(120);
        
        var fontData = loadedFonts[$(this).attr('data-value')];
        
        $('#qbold, #qitalic').removeClass('disable').removeClass('mix').removeClass('activeAlign');
        
        qtext.fontStyle('bold italic');
        layer.draw();
        
        if($.browser.mozilla){
            if(fontData === undefined || fontData['i4'] === undefined){
                $('#qitalic').addClass('disable');
            }
            if(fontData === undefined || fontData['n7'] === undefined){
                $('#qbold').addClass('disable');
            }
            if(fontData !== undefined && fontData['i7'] !== undefined){
                $('#qbold, #qitalic').addClass('mix');
            }
        } else {
            $('#qbold, #qitalic').addClass('mix');
        }

        $('#qselected').removeClass('active');
        
        qtext.fontStyle('normal normal');
        checkQText();
        
        layer.draw();
        event.preventDefault();
    });


    var anav = $('#aselected');
    var aselection = $('.aselect');
    var aselect = aselection.find('li');

    anav.click(function(event) {
        if (anav.hasClass('active')) {
            anav.removeClass('active');
            aselection.stop().slideUp(120);
        } else {
            anav.addClass('active');
            aselection.stop().slideDown(200);
        }

        event.preventDefault();
    });

    aselect.click(function(event) {
        aselect.removeClass('active');
        $(this).addClass('active');
        atext.fontFamily($(this).attr('data-value'));

        anav.text($(this).text());
        anav.css("font-family", $(this).attr('data-value'));

        aselection.stop().slideUp(120);
        
        var fontData = loadedFonts[$(this).attr('data-value')];
        
        $('#abold, #aitalic').removeClass('disable').removeClass('mix').removeClass('activeAlign');
        
        atext.fontStyle('bold italic');
        layer.draw();
        
        if($.browser.mozilla){
            if(fontData === undefined || fontData['i4'] === undefined){
                $('#aitalic').addClass('disable');
            }
            if(fontData === undefined || fontData['n7'] === undefined){
                $('#abold').addClass('disable');
            }
            if(fontData !== undefined && fontData['i7'] !== undefined){
                $('#abold, #aitalic').addClass('mix');
            }
        } else {
            $('#abold, #aitalic').addClass('mix');
        }
        
        $('#aselected').removeClass('active');

        atext.fontStyle('normal normal');
        checkAText();
        
        layer.draw();
        event.preventDefault();
    });

    var qfsnav = $('#qfontsize');
    var qfsselection = $('.qfontsizelist');
    var qfsselect = qfsselection.find('li');

    qfsnav.click(function(event) {
        if (qfsnav.hasClass('active')) {
            qfsnav.removeClass('active');
            qfsselection.stop().slideUp(120);
        } else {
            qfsnav.addClass('active');
            qfsselection.stop().slideDown(200);
        }

        event.preventDefault();
    });

    qfsselect.click(function(event) {
        qfsselect.removeClass('active');
        $(this).addClass('active');

        qtext.fontSize($(this).attr('data-value'));

        qfsnav.text($(this).text());
        layer.draw();

        qfsselection.stop().slideUp(120);
        $('#qfontsize').removeClass('active');
        event.preventDefault();
    });


    var afsnav = $('#afontsize');
    var afsselection = $('.afontsizelist');
    var afsselect = afsselection.find('li');

    afsnav.click(function(event) {
        if (afsnav.hasClass('active')) {
            afsnav.removeClass('active');
            afsselection.stop().slideUp(120);
        } else {
            afsnav.addClass('active');
            afsselection.stop().slideDown(200);
        }

        event.preventDefault();
    });

    afsselect.click(function(event) {
        afsselect.removeClass('active');
        $(this).addClass('active');

        atext.fontSize($(this).attr('data-value'));

        afsnav.text($(this).text());
        layer.draw();

        afsselection.stop().slideUp(120);
        $('#afontsize').removeClass('active');
        event.preventDefault();
    });

    $("#qbold").click(function() {
        if($(this).hasClass('disable')) return;
        
        if ($(this).hasClass('activeAlign')) {
            if ($("#qitalic").hasClass('activeAlign')) {
                qtext.setFontStyle('italic normal');
            } else {
                qtext.setFontStyle('normal');
            }
            $(this).removeClass('activeAlign');
        } else {
            if ($("#qitalic").hasClass('activeAlign') && $(this).hasClass('mix')) {
                qtext.setFontStyle('italic bold');
            } else {
                $("#qitalic").removeClass('activeAlign'); 
                qtext.setFontStyle('normal bold');
            }
            $(this).addClass('activeAlign');
        }
        layer.draw();
        console.log(qtext);
    });

    $("#qitalic").click(function() {
        if($(this).hasClass('disable')) return;
        
        if ($(this).hasClass('activeAlign')) {
            if ($("#qbold").hasClass('activeAlign')) {
                qtext.setFontStyle('normal bold');
            } else {
                qtext.setFontStyle('normal');
            }
            $(this).removeClass('activeAlign');

        } else {
            if ($("#qbold").hasClass('activeAlign') && $(this).hasClass('mix')) {
                qtext.setFontStyle('italic bold');
            } else {
                $("#qbold").removeClass('activeAlign'); 
                qtext.setFontStyle('italic normal');
            }
            $(this).addClass('activeAlign');
        }
        layer.draw();
    });
    
    $("#abold").click(function() {
        if($(this).hasClass('disable')) return;
        
        if ($(this).hasClass('activeAlign')) {
            if ($("#aitalic").hasClass('activeAlign')) {
                atext.setFontStyle('italic');
            } else {
                atext.setFontStyle('normal');
            }
            $(this).removeClass('activeAlign');
        } else {
            if ($("#aitalic").hasClass('activeAlign')) {
                atext.setFontStyle('italic bold');
            } else {
                atext.setFontStyle('bold');
            }
            $(this).addClass('activeAlign');
        }
        layer.draw();
    });

    $("#aitalic").click(function() {
        if($(this).hasClass('disable')) return;
        
        if ($(this).hasClass('activeAlign')) {
            if ($("#abold").hasClass('activeAlign')) {
                atext.setFontStyle('bold');
            } else {
                atext.setFontStyle('normal');
            }
            $(this).removeClass('activeAlign');

        } else {
            if ($("#abold").hasClass('activeAlign')) {
                atext.setFontStyle('italic bold');
            } else {
                atext.setFontStyle('italic');
            }
            $(this).addClass('activeAlign');
        }
        layer.draw();
    });
    
    $('.qdefaultwidth a').click( function (event){
        qtext.width(440);
        qtext.x(15);
        layer.draw();
        
        $('#qwidth').text(440);
        event.preventDefault();
    });
    
    $('#to-preset').click(function (){
        reset(preset);
        return false;
    });
    
    $('.params .wrap').hover(
        function () {
           $('.upperhover', this).show();
        }, 
        function () {
           $('.upperhover', this).hide();
        }
    );
     
    $('#line-height').click(function (){
        var height = qtext.height();
        var fontSize = qtext.fontSize();

        var maxheight = 128;
        var maxlines = 4;

        if((height > maxheight) || (height / fontSize) > maxlines){
            for (var i = fontSize; i > 10; i -= 2)
            { 
                qtext.fontSize(i);
                if(qtext.height() <= maxheight) break;
            }
            layer.draw();
        }
    });
});

$(document).mouseup(function(e) {
    var container = $('.qselect, .aselect, .qfontsizelist, .afontsizelist, #qselected, #aselected, #qfontsize, #afontsize ');

    if (!container.is(e.target)
            && container.has(e.target).length === 0)
    {
        $('#qselected, #aselected, #qfontsize, #afontsize').removeClass('active');
        $('.qselect, .aselect, .qfontsizelist, .afontsizelist').stop().slideUp(120);
    }
});