
  $(function () {
    $.material.init();
  });
//$('.content-wrapper').css('padding-top','260px')


$(".top_seaarch").focus(function(){
    $('.tform_group_w').width('300');
});

$(document).ready(function()
	{
		var $container = $('div#products').has('div.list_items');
		$container.isotope({
	});
		
	});
function openPopup(url) {
   var left = Number((screen.width/2)-(500/2));
   var top = Number((screen.height/2)-(500/2));
	var windowFeatures = 'channelmode=0,directories=0,fullscreen=0,location=0,menubar=0,resizable=0,scrollbars=0,status=0,width=500,height=450,top=' + top + ',left=' + left;
   var newWindow = window.open(url, 'popWindow', windowFeatures);
}