var hexDigits = new Array
        ("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"); 

//Function to convert rgb color to hex format
function rgb2hex(rgb) {
 rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
 return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
}

function hex(x) {
  return isNaN(x) ? "00" : hexDigits[(x - x % 16) / 16] + hexDigits[x % 16];
}

$('body').on('click', '.icons a.fb', function(){
    console.log(1);
    var share_url = $(this).closest('.icons').attr('data-url');
    var url = 'https://www.facebook.com/sharer.php?app_id=289311574796505&sdk=joey&u=' + encodeURIComponent(share_url); 
    window.open(url,"","width=600,height=300");
    return false;
});

$('body').on('click', '.big-share a.f', function(){
    var share_url = $(this).closest('.big-share').attr('data-url');
    var url = 'https://www.facebook.com/sharer.php?app_id=289311574796505&sdk=joey&u=' + encodeURIComponent(share_url); 
    window.open(url,"","width=600,height=300");
    return false;
});

$('body').on('click', '.icons a.tw', function(){
    var share_url = $(this).closest('.icons').attr('data-url');
    var text = $(this).closest('.icons').attr('data-twitter-text');
    
    if(typeof text == 'undefined'){
        text = '';
    } else {
        text = text.replace(/@@/g, '"');
    }
    
    var url = 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(share_url) + '&text=' + encodeURIComponent(text);
    window.open(url,"","width=600,height=300");
    return false;
});

$('body').on('click', '.big-share a.t', function(){
    var share_url = $(this).closest('.big-share').attr('data-url');
    var text = $(this).closest('.big-share').attr('data-twitter-text');
    
    if(typeof text == 'undefined'){
        text = '';
    } else {
        text = text.replace(/@@/g, '"');
    }
    
    var url = 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(share_url) + '&text=' + encodeURIComponent(text);
    window.open(url,"","width=600,height=300");
    return false;
});



