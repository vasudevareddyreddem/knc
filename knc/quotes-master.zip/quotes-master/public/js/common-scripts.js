function adminLogout(){
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/admin-logout',
		data:{logout:'adminsession'},
		success: function(data){
			$('#hidden_logout').modal('hide');
			if(data.output=='1'){				
				window.location = adminBaseUrl;
			}
		}
	});
}
function loginChecking(jForm){ 
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loginForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		var u_email    = $("#u_email").val();
		var u_password = $("#u_password").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/checking-login?sRch='+time,
			data:{u_email:u_email,u_password:u_password},
			success: function(data){
				$("#errorLogin").html('');
				if(data.output == "emailnotinrecord"){
					$("#errorLogin").html('Entered email is not in records');
				}else if(data.output == "fail"){	
					$("#errorLogin").html('Please email is requried');						
				}else if(data.output == "wrongdeatils"){
					$("#errorLogin").html('Entered email or password are wrong');	
				}else if(data.output == "success"){
					window.location = adminBaseUrl+'/user-management';
				}
			}
		});
		e.preventDefault();	
	});
}
function logoutUser(usermode){
	if(usermode=='admin'){
		$('#hidden_logout').modal('show');	
	}
}

function addCategory(catname){
	var d 		= new Date();
	var time 	= d.getTime();
	$("#catForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#catLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var qc_cat_name  = $("#qc_cat_name").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-category?sRch='+time,
			data:{qc_cat_name:qc_cat_name},
			success: function(data){
				$("#catLoader").hide();
				if(data.output=='alreadyexists'){
					$("#title-message").html("Category Confirmation");
					$("#alert-message").html("The Category is already added.");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/category-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function loadCategories(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#catloadingdata").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/category-lists?sRch='+time,
		success		: function(data){			
			$('#catloadingdata').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Category Name</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "qc_cat_id" },
					{ "mData": "qc_cat_name" },
					{ "mData": "qc_status" },
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function editCategory(catid,catname){
	$("#view_category").modal('hide');
	$("#qc_cat_id").val(catid);
	$("#qc_cat_name").val(catname);
	$("#update_category").modal('show');	
}
function viewCategory(catid,catname){
	$("#update_category").modal('hide');	
	$("#qc_cat_namee").val(catname);
	$("#view_category").modal('show');	
}
function updateCategory(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#updateCate").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
			$("#catLoader").show();
			$("#title-message").html("");
			$("#alert-message").html("");
			var qc_cat_id   = $("#qc_cat_id").val();
			var qc_cat_name = $("#qc_cat_name").val();
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'/update-category?sRch='+time,
				data:{qc_cat_name:qc_cat_name,qc_cat_id:qc_cat_id},
				success: function(data){
					$("#catLoader").hide();
					if(data.output=='alreadyexists'){
						$("#title-message").html("Category Confirmation");
						$("#alert-message").html("The Category is already added.");
						$("#hidden_common").modal('show');	
					}else if(data.output=='success'){
						$("#hidden_common").modal('hide');	
						window.location=adminBaseUrl+"/category-management";
					}				
				}
			});
		e.preventDefault();	
	});
}
function hideCategory(catid,statusMode){
	$("#status-alert-message").html("");
	$("#hid_catid").val(catid);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function deleteCategory(catid,statusMode){
	$("#hid_d_catid").val(catid);		
	$("#status_del").modal('show');
}
function deleCategory(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_cat_id = $("#hid_d_catid").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-category-status?sRch='+time,
		data:{status:'2',qc_cat_id:qc_cat_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/category-management";
			}				
		}
	});
}
function hideCategoryMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_cat_id = $("#hid_catid").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-category-status?sRch='+time,
		data:{status:status,qc_cat_id:qc_cat_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/category-management";
			}				
		}
	});
}
function addLanguage(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	$("#langForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#lanLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var lang_name  = $("#lang_name").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-language?sRch='+time,
			data:{lang_name:lang_name},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='alreadyexists'){
					$("#title-message").html("Language Confirmation");
					$("#alert-message").html("The language is already added.");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/language-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function langloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loadLanguages").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/language-lists?sRch='+time,
		success		: function(data){			
			$('#loadLanguages').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Language Name</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "lang_id" },
					{ "mData": "lang_name" },
					{ "mData": "lang_status" },
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function editLanguage(langid,langname){
	$("#view_category").modal('hide');
	$("#lang_id").val(langid);
	$("#lang_name").val(langname);
	$("#update_language").modal('show');	
}
function viewLanguage(langid,langname){
	$("#update_language").modal('hide');	
	$("#lang_namee").val(langname);
	$("#view_language").modal('show');	
}
function updateLanguage(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#updateLang").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
			$("#langLoader").show();
			$("#title-message").html("");
			$("#alert-message").html("");
			var lang_id   = $("#lang_id").val();
			var lang_name = $("#lang_name").val();
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'/update-language?sRch='+time,
				data:{lang_name:lang_name,lang_id:lang_id},
				success: function(data){
					$("#langLoader").hide();
					if(data.output=='alreadyexists'){
						$("#title-message").html("Language Confirmation");
						$("#alert-message").html("The language is already added.");
						$("#hidden_common").modal('show');	
					}else if(data.output=='success'){
						$("#hidden_common").modal('hide');	
						window.location=adminBaseUrl+"/language-management";
					}				
				}
			});
		e.preventDefault();	
	});
}
function hideLanguage(langid,statusMode){
	$("#status-alert-message").html("");
	$("#hid_langid").val(langid);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function deleteLanguage(langid,statusMode){
	$("#hid_d_langid").val(langid);		
	$("#status_del").modal('show');
}
function deleLanguage(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var lang_id = $("#hid_d_langid").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-language-status?sRch='+time,
		data:{status:'2',lang_id:lang_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/language-management";
			}				
		}
	});
}
function hideLanguageMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var lang_id = $("#hid_langid").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-language-status?sRch='+time,
		data:{status:status,lang_id:lang_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/language-management";
			}				
		}
	});
}
//Upload Author Pic
function uploadAuthorPic(fieldID){
	var _URL = window.URL || window.webkitURL;
	var image;
	var fd = new FormData();
	var fileSize = $('#'+fieldID)[0].files[0].size;
	$('#imageLoader').show();
	if(fieldID == 'authorPic'){
	if(fileSize <= 5242880){
		switch($('#'+fieldID).val().substring($('#'+fieldID).val().lastIndexOf('.') + 1).toLowerCase()){
			case 'png': case 'jpg': case 'jpeg': case 'jpe': case 'gif':			
			image = new Image();
			image.src = _URL.createObjectURL($('#'+fieldID)[0].files[0]);
			image.onload = function() {
				if(this.width == 250 && this.height == 250){
					fd.append( fieldID, $('#'+fieldID)[0].files[0]);
					$.ajax({
						url: adminBaseUrl+'/author-upload-pic?type='+fieldID+'1',
						data: fd,
						processData: false,
						contentType: false,
						type: 'POST',
						success: function(returned){
							
							if(fieldID == 'authorPic'){
								alert(returned);
								$('#au_pic').val(returned.imageName);
								var newCatImageFullPath = adminBasePath+'/authorpics/'+returned.imageName;
								$('#auth_pic').val(returned.imageName);
							}
						}
					});
				}else{
					 $('#'+fieldID).val('');
					 $('#dimentionsAuthor').html('Upload image is 250 X 250.');
					 $('#imageDimentions').modal('show');
				}
			}
			break;
			default:
			 $('#'+fieldID).val('');
			 $('#dimentionsAuthor').html('Upload image is 250 X 250.');
			 $('#imageDimentions').modal('show');
			break;
		}}else{
			 $('#'+fieldID).val('');
			 $('#dimentionsAuthor').html('Upload image size less than 5Mb');
			 $('#imageDimentions').modal('show');
		 }
	}
}
function addAuthor(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#authorForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#authorLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var au_fname       = $("#au_fname").val();
		var au_lname       = $("#au_lname").val();
		var au_pic         = $("#au_pic").val();
		var au_birth_year  = $("#au_birth_year").val();
		var au_deadth_year = $("#au_death_year").val();
		var au_descrpt     = $("#au_descrpt").val();
		var au_wiki_link   = $("#au_wiki_link").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-author?sRch='+time,
			data:{au_fname:au_fname,au_lname:au_lname,au_pic:au_pic,au_birth_year:au_birth_year,au_deadth_year:au_deadth_year,au_descrpt:au_descrpt,au_wiki_link:au_wiki_link},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Author Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#au_fname").val('');
					$("#au_lname").val('');
					$("#au_pic").val('');
					$("#au_birth_year").val('');
					$("#au_death_year").val('');
					$("#au_descrpt").val('');
					$("#au_wiki_link").val('');
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/author-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function updateAuthor(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#authorUpdateForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#authorLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var au_fname       = $("#au_fname").val();
		var au_lname       = $("#au_lname").val();
		var au_pic         = $("#au_pic").val();
		var au_birth_year  = $("#au_birth_year").val();
		var au_deadth_year = $("#au_deadth_year").val();
		var au_descrpt     = $("#au_descrpt").val();
		var au_wiki_link   = $("#au_wiki_link").val();
		var au_id 		   = $("#au_id").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/update-author?sRch='+time,
			data:{au_fname:au_fname,au_lname:au_lname,au_pic:au_pic,au_birth_year:au_birth_year,au_deadth_year:au_deadth_year,au_descrpt:au_descrpt,au_wiki_link:au_wiki_link,au_id:au_id},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Author Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){					
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/author-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function authorloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loadAuthorData").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/author-lists?sRch='+time,
		success		: function(data){	
			$('#loadAuthorData').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Author pic</th>'+
			'<th>First Name</th>'+
			'<th>Last Name</th>'+
			'<th>Birth Year</th>'+
			'<th>Deadth Year</th>'+
			'<th>Description</th>'+
			'<th>Wiki Link</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "au_id" },
					{ "mData": "au_pic" },
					{ "mData": "au_fname"},
					{ "mData": "au_lname"},
					{ "mData": "au_birth_year"},					
					{ "mData": "au_deadth_year"},
					{ "mData": "au_descrpt"},
					{ "mData": "au_wiki_link"},
					{ "mData": "au_status"},
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function viewAuthor(au_id){
	$("#au_fname").val('');
	$("#au_lname").val('');
	$("#au_birth_year").val('');
	$("#au_deadth_year").val('');
	$("#au_descrpt").val('');
	$("#au_wiki_link").val('');
	var d 		= new Date();
	var time 	= d.getTime();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/view-author?sRch='+time,
		data:{au_id:au_id},
		success: function(data){
			if(data.output=="success"){	
				var au_name = data.getAuthor.au_fname;
				var au_pic  = au_name.replace(' ', '_');
				var authpic = au_pic+".jpg";
				var imageUrl = baseUrl+'/author_imgs/'+authpic;
				$("#view_image").html('<img src="'+imageUrl+'"class="img-thumbnail" style="width:250px;height:100px;">');
				$("#au_fname").val(data.getAuthor.au_fname);
				$("#au_lname").val(data.getAuthor.au_lname);
				$("#au_birth_year").val(data.getAuthor.au_birth_year);
				$("#au_deadth_year").val(data.getAuthor.au_deadth_year);
				$("#au_descrpt").val(data.getAuthor.au_descrpt);
				$("#au_wiki_link").val(data.getAuthor.au_wiki_link);
				$("#view_author").modal('show');
			}			
		}
	});
}

function hideAuthor(au_id,statusMode){
	$("#status-alert-message").html("");
	$("#hid_au_id").val(au_id);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function deleteAuthor(au_id,statusMode){
	$("#hid_d_au_id").val(au_id);		
	$("#status_del").modal('show');
}
function deleAuthor(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var au_id = $("#hid_d_au_id").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-author-status?sRch='+time,
		data:{status:'2',au_id:au_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/author-management";
			}				
		}
	});
}
function hideAuthorMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var au_id = $("#hid_au_id").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-author-status?sRch='+time,
		data:{status:status,au_id:au_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/author-management";
			}				
		}
	});
}

function addQuote(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#qouteForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#quoteLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var qc_au_id       = $("#qc_au_id").val();
		var qc_qc_cat_id   = $("#qc_qc_cat_id").val();
		var qc_lang_id     = $("#qc_lang_id").val();
		var qc_name        = $("#qc_name").val();
		var qc_image       = $("#qc_image").val();
		//var quotePic       = $("#quotePic").val();
		
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-quote?sRch='+time,
			data:{qc_au_id:qc_au_id,qc_qc_cat_id:qc_qc_cat_id,qc_lang_id:qc_lang_id,qc_name:qc_name,qc_image:qc_image},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Quote Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){					
					$("#qc_au_id").val('');
					$("#qc_qc_cat_id").val('');
					$("#qc_name").val('');
					$("#qc_image").val('');
					$("#qc_lang_id").val('');
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/quotes-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function updateQuote(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#qouteForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#authorLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var qc_au_id       = $("#qc_au_id").val();
		var qc_qc_cat_id   = $("#qc_qc_cat_id").val();
		var qc_lang_id     = $("#qc_lang_id").val();
		var qc_name        = $("#qc_name").val();
		var qc_image       = $("#qc_image").val();
		var qc_id 		   = $("#qc_id").val();
		var add_quote_hid  = $("#add_quote_hid").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/update-quote?sRch='+time,
			data:{qc_au_id:qc_au_id,qc_qc_cat_id:qc_qc_cat_id,qc_lang_id:qc_lang_id,qc_name:qc_name,qc_image:qc_image,qc_id:qc_id,add_quote_hid:add_quote_hid},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Quote Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){					
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/quotes-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function quoteloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#quoteloaddata").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/quotes-lists?sRch='+time,
		success		: function(data){			
			$('#quoteloaddata').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Quote Image</th>'+
			'<th>Author Name</th>'+
			'<th>Categorty Name</th>'+
			'<th>Language Name</th>'+
			'<th>Quote Name</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "qc_id" },
					{ "mData": "qc_image" },
					{ "mData": "qc_au_id"},
					{ "mData": "qc_qc_cat_id"},
					{ "mData": "qc_lang_id"},					
					{ "mData": "qc_name"},				
					{ "mData": "qc_status"},
					{ "mData": "action" },
				] 
			});	
		}
	});
}

function viewQuote(qc_id){
	$("#qc_au_id").html('');
	$("#qc_qc_cat_id").html('');
	$("#qc_lang_id").html('');
	$("#qc_name").html('');
	$("#qc_image").html('');
	var d 		= new Date();
	var time 	= d.getTime();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/view-quote?sRch='+time,
		data:{qc_id:qc_id},
		success: function(data){
			if(data.output=="success"){		
				if(data.getQuote.qc_image!=null && data.getQuote.qc_image!=""){
					var imageUrl = baseUrl+'quotes/'+data.getQuote.qc_image;
				}else{
					var imageUrl = baseUrl+'images/category.png';
				}
				$("#view_image").html('<img src="'+imageUrl+'"class="img-thumbnail" style="width:250px;height:100px;">');				
				$("#qc_au_id").html(data.getQuote.au_fname);
				$("#qc_qc_cat_id").html(data.categories);
				$("#qc_lang_id").html(data.getQuote.lang_name);
				$("#qc_name").html(data.getQuote.qc_name);
				$("#view_quote").modal('show');
			}			
		}
	});
}

function hideQuote(qc_id,statusMode,type){
	$("#status-alert-message").html("");
	$("#hid_qc_id").val(qc_id);
	$("#hid_status").val(statusMode);
	$("#hid_type").val(type);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure you want to the status to active?");
	}	
	$("#status_common").modal('show');
}



function deleteQuote(qc_id,statusMode,type){
	$("#hid_d_qc_id").val(qc_id);		
	$("#status_del").modal('show');
	$("#hid_del_type").val(type);
}
function deleQuote(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_id 	= $("#hid_d_qc_id").val();
	var deltype = $("#hid_del_type").val(type);
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-quote-status?sRch='+time,
		data:{status:'2',qc_id:qc_id,type:'dele'},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				if(deltype == 1){
					window.location=adminBaseUrl+"/user-quotes";
				}else{
					window.location=adminBaseUrl+"/quotes-management";
				}
			}				
		}
	});
}



function hideQuoteMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_id 	= $("#hid_qc_id").val();
	var status  = $("#hid_status").val();
	var type 	= $("#hid_type").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-quote-status?sRch='+time,
		data:{status:status,qc_id:qc_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				if(type == 1){
					window.location=adminBaseUrl+"/user-quotes";
				}else{
					window.location=adminBaseUrl+"/quotes-management";
				}
			}				
		}
	});
}

// sign up 
function signUpUser()
{
	$('#registerForm').formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$('#sgnupRefresh').show();
		$('#sgnupRefresh').addClass('fa-spin');
		var d 		= new Date();
		var time 	= d.getTime();		
		var u_flname    = $("#inputFullName").val();
		var u_email    = $("#inputEmail").val();
		var u_password = $("#inputPassword").val();
		var u_textArea = $("#textArea").val();
		if($("#subscribe").is(':checked')){
			var checkValue = 1;
		}else{
			var checkValue = 0;
		}
		// var inputFile = $("#inputFile").val();			
		// var file_data = $('#inputFile').prop('files')[0];
		var form_data = new FormData();
		form_data.append('file_data', '');
		form_data.append('u_flname', u_flname);
		form_data.append('u_email', u_email);
		form_data.append('u_password', u_password);
		form_data.append('u_textArea', u_textArea);			
		form_data.append('u_subscribe', checkValue);			
		$.ajax({
			type:'POST',
			cache: false,
			contentType: false,
			processData: false,
			data: form_data, 
			url:  adminBaseUrl+'user-signup',			
			success: function(data){
				$("#errorLogin").html('');
				$("#emailChecking").html('');
				$('#sgnupRefresh').hide();
				if(data.output == "success"){					
					$('#sgnupRefresh').removeClass('fa-spin');
					$('#myModalLabelw').html('Registeration Confirmation');
					$('#alert-message').html('Thanks for registering with us. Your account verification link has been sent to your email.');
					$('#hidden_common').modal('show');					
					$('#myModal').on('hidden.bs.modal', function () {
						$(this).find("input,textarea,select,text").val('').end();
					});
					$('#myModal').modal('hide');
				}else if(data.output=="emailexists"){
					$("#errorLogin").html('');
					$('#emailChecking').html('Email already exists.');	
				}
			}	
		});
		e.preventDefault();return false;
	});	
}
	function userLogin()
	{
		$('#login-nav').formValidation().on('success.form.fv', function(e) {
				e.stopImmediatePropagation();
		$('#signRefresh').show();
		$('#signRefresh').addClass('fa-spin');
		var u_email    = $("#exampleInputEmail2").val();
		var u_password = $("#exampleInputPassword2").val();	
		var hidvalue   = $("#hidvalue").val();	
		if(hidvalue==0){
			var redirectUrl='view-userprofile/quote';
		}else{
			var redirectUrl='post-a-quote';
		}
		$.ajax({
			type	:'POST',
			url		: adminBaseUrl+'login-user',
			data	:{u_email:u_email,u_password:u_password},
			success	: function(data){
				$('#signRefresh').hide();
				$('#signRefresh').removeClass('fa-spin');
				console.log(data.output);
				$("#hidvalue").val(0);
				
				if(data.output == "sucess")
				{					
					window.location = adminBaseUrl+redirectUrl;
				}
				else{
					$('#errorMsg').html('Invalid Credentials');
				}				
			}
		});
		e.preventDefault();return false;
	}); 
				
	}
	$('#userSignInBtn').click(function (){
		setTimeout(function(){ 
			$("#login-nav").trigger('reset');
			$('#login-nav').formValidation('resetForm', true);
			$('#login-nav').data('formValidation').resetForm();
		},10);
		$('#errorMsg').html('');
		$('#exampleInputEmail2').val('');
		$('#exampleInputPassword2').val('');
	});
	// logout call
	$('#userLogoutButn').click(function (){
		$('#user_logout').modal('show');
				
	});
	function userLogouttt(){
		fbLogoutt();
		$("#scoial_hidden_common_fb").hide();
		$.ajax({
			type	:'POST',
			url		: adminBaseUrl+'user-logout',			
			success	: function(data){
				console.log(data.output);
				if(data.output == 1)
				{
					window.location = adminBaseUrl;
				}
				else{
					alert('There is an error');
					return false;
				}
			}
		});
	}
	function userLogout()
	{
		if($("#userloginwith").val()=="ge"){
			$.ajax({
				type 		: 	"GET",
				jsonp		: 	"callback",
				dataType 	: 	"jsonp",
				url			:	"https://www.google.com/accounts/Logout",
				success		: 	function( response ){
					console.log(response);
				}
			});
		}
		if($("#userloginwith").val()=="fb"){
			fbLogoutt();
		}
		$('#user_logout').modal('hide');
		$.ajax({
			type	:'POST',
			url		: adminBaseUrl+'user-logout',			
			success	: function(data){
				console.log(data.output);
				if(data.output == 1)
				{
					window.location = adminBaseUrl;
				}
				else{
					alert('There is an error');
					return false;
				}
			}
		});
	}
	
	// favourite adding
	/* $('#quoteFav').click(function(){
		var userSessId = $('#userSessId').val();
		var quoteId = $('#quoteId').val();
		if(userSessId == "")
		{
			alert('Plase login');
			return false;
		}
		else{
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'user-fav',
				data:{userSessId:userSessId,quoteId:quoteId},
				success: function(data){
						console.log(data.output);
						if(data.output == 'success')
						{
							alert('This Quote is added as your Favourite!');
						}
						else if(data.output == 'fail')
						{
							alert('Plase try Again!');
						}
						else if(data.output == 'already exists')
						{
							alert('This Quote is already added as your favourite!');
						}
						
					}
			});
				
		}
		
	}); */
	function topShortQuotesFav(quoteId){
		$('#hid_fav').val(quoteId);
		var favorat = $('#hidUserFavorate_'+quoteId).val();	
		var userSessId = $('#userSessId').val();
		
		if(favorat!=0  ){
			if(userSessId!=0){
				$('#user_Favourite').modal('show');	
			}else{
				userFavourite();
			}
			
		}else{
			userFavourite();
		}
	}
	function headerQuotefav(quoteId,uid){
		$('#hid_fav').val(quoteId);
		var favorat = $('#hidUserFavorate_'+quoteId).val();	
		var userSessId = uid;
		if(favorat!=0){
			if(userSessId!=0){
				$('#user_Favourite').modal('show');	
			}else{
				userFavourite();
				// if(userSessId!=0){
					// window.location = adminBaseUrl+'view-userprofile/fav';
				// }
			}			
		}else{
			userFavourite();
			// if(userSessId!=0){
				// window.location = adminBaseUrl+'view-userprofile/fav';
			// }
		}
	}
	function quoteOfTheDayFavorate(quoteId){
		$('#hid_fav').val(quoteId);
		var favorat = $('#hidUserFavorate_'+quoteId).val();	
		var userSessId = $('#userSessId').val();
		
		if(favorat!=""){
			if(userSessId!=0){
				$('#user_Favourite').modal('show');	
			}else{
				userFavourite();
			}
			
		}else{
			userFavourite();
		}
	}
	
	function fileName()
	 {
		var fileName = $('#inputFile').val();		
		var quotePic = $('#image').val();		
		$('#userProfilePic').val(fileName);
		$('#quotePic').val(quotePic);
	 }
	function userFavourite()
	{
		var userSessId = $('#userSessId').val();		
			 var quoteId = $('#hid_fav').val();
			if(userSessId == 0)
			{
				$('#user_Favourite').modal('hide');	
				$('#hidden_common').modal('show');
				$('#myModalLabelw').html('Please login');				
				$('#alert-message').html('Please login to add this quote as your favourite');				
				return false;
			}
			else{
				$.ajax({
					type:'POST',
					url:  adminBaseUrl+'user-fav',
					data:{userSessId:userSessId,quoteId:quoteId},
					success: function(data){
							console.log(data.output);
							console.log(data.favCount);
							$('#user_Favourite').modal('hide');
							if(data.output == 'success')
							{
								
								/* $('#hidden_common').modal('show');
								$('#cnfrmOk').hide();
								$('#myModalLabel').html('');	
								$('#myModalLabel').html('Favourite Confirmation');	
								$('#alert-message').html('This Quote is added as your Favourite!'); */	
								$('#favCountIdValue_'+quoteId).html('');	
								$('#favCountIdValue_'+quoteId).html(data.favCount);	
								$('#hidUserFavorate_'+quoteId).val(1);	
								$('#favSymbal_'+quoteId).removeClass('fa-heart-o');	
								$('#favSymbal_'+quoteId).addClass('fa-heart');	
								var favId = $("#favmodefrom").val();
								if(typeof(favId)!="undefined" && favId=="favorite"){
									location.reload();
								}
							}
							else if(data.output == 'fail')
							{
								$('#hidden_common').modal('show');
								$('#myModalLabelw').html('Please Login');								
								$('#alert-message').html('Please try Again!');								
							}
							else if(data.output == 'unfav')
							{
								
								/* $('#hidden_common').modal('show');
								$('#cnfrmOk').hide();
								$('#myModalLabel').html('');	
								$('#myModalLabel').html('UnFavourite Confirmation');	
								$('#alert-message').html('This Quote is added as your unfavourite!'); */
								$('#favCountIdValue_'+quoteId).html('');	
								$('#favCountIdValue_'+quoteId).html(data.favCount);	
								$('#hidUserFavorate_'+quoteId).val(0);	
								$('#favSymbal_'+quoteId).removeClass('fa-heart');	
								$('#favSymbal_'+quoteId).addClass('fa-heart-o');	
								if($('#favSymbal_'+quoteId).length > 0 ){
								}else{
									// location.reload();
								}
								var favId = $("#favmodefrom").val();
								if(typeof(favId)!="undefined" && favId=="favorite"){
									location.reload();
								}
							}							
					}
				});
					
			}
	}
	
	$('#nextClickTogetQuote').click(function()
	{
		var hid_offset = $('#hid_offset').val();		
		var hid_params = $('#hid_params').val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'quote-views',
			data:{hid_offset:hid_offset,hid_params:hid_params},
			success: function(data){					
				offsetVal = parseInt(data.hid_offset)+1;
				$('#hid_offset').val(offsetVal);
				console.log(data.viewsList.qc_name);
				$('#quote_name').html(data.viewsList.qc_name);
			}
		});
	});
	
	$('#refreshBtn').click(function()
	{
		$(this).toggleClass('rotate').promise().done(function(){
			$(this).toggleClass('rotate');   
		});
		$(this).addClass('fa-spin');
		var refresh = 1;
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'refresh',
			data:{refresh:refresh},
			success: function(data){
				$("#AuthName").html('');
				$("#AuthName").html(data.output);			
				$('#refreshBtn').removeClass('fa-spin');
			}
		});
	});
	// search quotes
	$('#QtSearch').keypress(function (e) {
	 var key = e.which;
	 if(key == 13)  // the enter key code
	  {
		 $('#srchBt').click();
	  }
	});

	$('#srchBt').click(function()
	{		
		var searchTerm = $('#QtSearch').val();
		if(searchTerm==""){
			$('#hidden_common_serach').modal('show');
			$('#cnfrmOk').show();
			$('#myModalLabell').html('');	
			$('#myModalLabell').html('Search Warning');	
			$('#QtSearch').focus();	
			$('#alert-messagee').html("Oops! You didn't enter anything to search.");return false;	
		}else{
			searchTerm = searchTerm.replace(/\s/g, "+");
			searchTerm = searchTerm.replace("'","%20");
			$("form").attr('action', adminBaseUrl+'search-quote/'+searchTerm);
			$('#QtSearchForm').submit();
		}
	});
	$('#srchBt_mob').click(function()
	{		
		var searchTerm = $('#QtSearch_mob').val();
		if(searchTerm==""){
			$('#hidden_common_serach').modal('show');
			$('#cnfrmOk').show();
			$('#myModalLabell').html('');	
			$('#myModalLabell').html('Search Quotations');	
			$('#QtSearch_mob').focus();
			$('#login-dp').hide();			
			$('#alert-messagee').html('Please enter any word to search quotations.');return false;	
		}else{
			searchTerm = searchTerm.replace(/\s/g, "+");
			searchTerm = searchTerm.replace("'","%20");
			$("form").attr('action', adminBaseUrl+'search-quote/'+searchTerm);
			$('#QtSearchForm_mob').submit();
		}
	});
	
	$('#update_profile').click(function()
	{	
		var userId = $('#user_id').val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'update-profile',
			data:{userId:userId},
			success: function(data){									
					console.log(data);	
					if(data.getUserDetails.uf_pic!="" && data.getUserDetails.uf_pic!=null){
						var userPic = data.getUserDetails.uf_pic;
						var pic = adminBasePath+'/uploads/'+userPic;
					}else if(data.getUserDetails.social_pic!="" && data.getUserDetails.social_pic!=null){
						var userPic = data.getUserDetails.social_pic;
						var pic = userPic;
					}else{
						var pic = adminBasePath+'/uploads/icon-user.png';
					}
					$('#inputFullName').val(data.getUserDetails.u_display_name);
					$('#inputEmail').val(data.getUserDetails.u_email);
					$('#textArea').val(data.getUserDetails.uf_about_me);
					$('#userPic').attr('src',pic);
					$('#updateProfileModal').modal('show');	
			}
		});
		
	});
	
	$('#UpdateBotun').click(function()
	{	
	$('#updateProfileForm').formValidation().on('success.form.fv', function(e) {
		$('#profileRefresh').show();
		$('#profileRefresh').addClass('fa-spin');
		var u_flname    	= $("#inputFullName").val();
		var u_email    		= $("#inputEmail").val();		
		var u_textArea 		= $("#textArea").val();		
		var inputFile 		= $("#userProfilePic").val();			
		var hiddenUid		= $("#hiddenUId").val();			
		var userImg 		= $("#userImg").val();	
		var picchangeflag 	= $("#picchangeflag").val();	
		// var file_data 		= $('#inputFile').prop('files')[0];
		var form_data = new FormData();
		form_data.append('file_data', '');
		form_data.append('u_flname', u_flname);
		form_data.append('u_email', u_email);			
		form_data.append('u_textArea', u_textArea);
		form_data.append('hiddenUid', hiddenUid);
		form_data.append('userImg', userImg);			
		form_data.append('picchangeflag', picchangeflag);			
		$.ajax({
			type:'POST',
			cache: false,
			contentType: false,
			processData: false,
			data: form_data,
			url:  adminBaseUrl+'update-profile-ajax',
			data:form_data,
			success: function(data){
				console.log(data);
				$('#errorupdate').html('Profile updated Sucessfully');
				$('#name').html(data.details.u_display_name);
				$('#email').html(data.details.u_email);
				$('#about_me').html(data.details.uf_about_me);
				var userPic = data.details.uf_pic;
				if(typeof(userPic!="undefined") && userPic!="" && userPic!=null){
					var pic = adminBasePath+'/uploads/'+userPic;
				}else if(data.details.social_pic!=""){
					var pic = data.details.social_pic;
				}else{
					var userPic = "icon-user.png";
					var pic = adminBasePath+'/uploads/'+userPic;
				}
				
				$('#userProfPic').attr('src',pic);
				$('#profileRefresh').hide();
				$('#profileRefresh').removeClass('fa-spin');
				setTimeout(function(){
					$('#errorupdate').html('');					
					$('#updateProfileModal').modal('hide');
				}, 3000);					
			}
		});
		e.preventDefault();
	});
		
	});
	
	// checking password
	function CheckPass()
	{
		$('#errorPass').html('');
		$('#changePasswordForm').formValidation().on('success.form.fv', function(e) {
			
		$('#changeRefresh').show();
		$('#changeRefresh').addClass('fa-spin');
		var uid = $('#hidUser_id').val();
		var currentPassword = $('#currentPassword').val();
		if(typeof(currentPassword)!="undefined" && currentPassword!=""){
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'check-password',
				data:{uid:uid,currentPassword:currentPassword},
				success: function(data){									
					console.log(data.user_id);	
					$('#changeRefresh').hide();
					$('#changeRefresh').removeClass('fa-spin');
					if(data.user_id != 0 && data.user_id != "")
					{
						var uid = data.user_id;
						updatePass(uid);
					}
					else if(data.user_id == 0){
						$('#errorPass').html('Entered current password is wrong.');
					}
						
				}
			});
		}else{
			updatePass(uid);
		}
		e.preventDefault();return false;
	});	
		
	}
	
	function updatePass(uid)
	{
		$('#errorPass').html('');
		var userid = uid;
		var currentPass = $('#currentPassword').val();
		var newPass = $('#newPassword').val();
		var confirmPass = $('#confirmPassword').val();
		if(typeof(currentPass)!="undefined" && currentPass!=""){
			if(currentPass == newPass)
			{
				$('#errorPass').html('Current and new passwords are same');
				return false;
			}		
			if(newPass != confirmPass)
			{
				$('#errorPass').html('The new password and it confirm password are not same');
				return false;
			}
		}
		$('#changeRefresh').show();
		$('#changeRefresh').addClass('fa-spin');
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'update-password',
			data:{userid:userid,newPass:newPass},
			success: function(data){									
				console.log(data);
				$('#changeRefresh').hide();
				$('#changeRefresh').removeClass('fa-spin');
				if(data.output == 'sucess')
				{
					$("#changePasswordForm").trigger('reset');
					$('#changePasswordForm').formValidation('resetForm', true);
					$('#changePasswordForm').data('formValidation').resetForm(); 
					$('#errorPass').html('');
					$('#sucessPass').html('Password updated successfully');
					setTimeout(function(){					
					$('#myModal2').modal('hide');
					}, 3000);
				}					
			}
		});
		return false;
	}
	function openChangePwdpop(){		
		setTimeout(function(){ 
			$("#changePasswordForm").trigger('reset');
			$('#changePasswordForm').formValidation('resetForm', true);
			$('#changePasswordForm').data('formValidation').resetForm(); 
		},300);
		$('#sucessPass').html('');
		$('#errorPass').html('');
		$('#myModal2').modal('show');
	}
	function clearChangePwd(){
		$("#changePasswordForm").trigger('reset');
		$('#changePasswordForm').formValidation('resetForm', true);
		$('#changePasswordForm').data('formValidation').resetForm(); 
		$('#myModal2').modal('hide');
	}
	function fogotpopupopen(){
		$('#forgeterrorEmail').html('');
		setTimeout(function(){ 
			$("#forgetPasswordForm").trigger('reset');
			$('#forgetPasswordForm').formValidation('resetForm', true);
			$('#forgetPasswordForm').data('formValidation').resetForm();
		},300);
		$('#myModal1').modal('show');
	}
	function getUrlVars()
	{
		var vars = [], hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');		
		for(var i = 0; i < hashes.length; i++)
		{
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];			
		}
		return vars;		
	}
	
	function CheckForgetEmail()
	{
	$('#forgot_hidden_common').modal('hide');			
		$('#forgetPasswordForm').formValidation().on('success.form.fv', function(e) {	
			e.stopImmediatePropagation();
			var email = $('#ForgetEmail').val();
			$('#changeforgetRefresh').show();
			$('#changeforgetRefresh').addClass('fa-spin');
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'check-email',
				data:{email:email},
				success: function(data){
					$('#changeforgetRefresh').hide();
					$('#changeforgetRefresh').removeClass('fa-spin');
					$('#forgeterrorEmail').html('');
					console.log(data);
					if(data.output == 'check email')
					{
						$('#forgot_hidden_common').modal('hide');		
						$('#forgeterrorEmail').html('Email not exists.');
					}
					else if(data.output == 'success')
					{
						$('#myModal1').modal('hide');
						$('#f_message').html('Reset password instructions have been sent to the email address provided.');						
						$('#forgot_hidden_common').modal('show');						
					}
					else if(data.output == 'fail')
					{
						$('#forgot_hidden_common').modal('hide');	
						$('#forgeterrorEmail').html('some error');
					}
						
				}
			});
			e.preventDefault();return false;
		});	
		
	}
	function ResetPswd()
	{
		 $('#resetPasswordForm').formValidation().on('success.form.fv', function(e) {
		
		var f_newPass 		= $('#f_newPassword').val();
		var f_confirmPass 	= $('#f_confirmPassword').val();
		var f_UserId 		= $('#f_UserId').val();
		if(f_newPass == f_confirmPass)
		{
			$.ajax({
			type:'POST',
			url:  adminBaseUrl+'reset-password',
			data:{f_confirmPass:f_confirmPass,f_UserId:f_UserId},
			success: function(data){									
					console.log(data);
					if(data.output == 'sucess')
					{
						$('#f_sucessPass').html('Password changed sucessfully');
						setTimeout(function(){					
						$('#myModalReset').modal('hide');
						}, 3000);
						window.location = adminBaseUrl;
					}
				}
			});
		}
		else
		{
			$('#f_errorPass').html('The new password and confirm password are not same');
			
		}
		e.preventDefault();return false;
		}); 
		
	}
	
	// post a quote
	function postAQuote()
	{
		$('#postAQuoteForm').formValidation().on('success.form.fv', function(e) {
			
					e.stopImmediatePropagation();
			$('#changeRefresh').show();
			$('#changeRefresh').addClass('fa-spin');
			var sessionId = $('#postaQtUid').val();
			if(sessionId == 0 ||  sessionId == "")
			{
				$('#hidden_common').modal('show');
				$('#myModalLabelw').html('Please Login');				
				$('#alert-message').html('Please login to post your quote');				
				return false;
			}
			//var username    	 = $("#username").val();
			//var email    		 = $("#email").val();		
			var qc_qc_cat_id 	 = $("#qc_qc_cat_id").val();					
			var QuoteId 	     = $("#postaQuoteId").val();					
			var postaQuoteEditId = $("#postaQuoteEditId").val();					
			var quoteText 		 = $("#quoteText").val();					
			var qc_lang_id 		 = $("#qc_lang_id").val();					
			var Keywords 		 = $("#Keywords").val();					
			var file_data 		 = $('#image').val();		
			var form_data = new FormData();
			form_data.append('file_data', file_data);
			//form_data.append('username', username);
			//form_data.append('email', email);			
			form_data.append('quoteText', quoteText);
			form_data.append('sessionId', sessionId);	
			form_data.append('qc_qc_cat_id', qc_qc_cat_id);	
			form_data.append('qc_id', postaQuoteEditId);	
			form_data.append('qc_lang_id', qc_lang_id);	
			form_data.append('qc_tags', Keywords);	
			if(postaQuoteEditId!=""){
				var url=adminBaseUrl+'post-a-quote/'+QuoteId;
			}else{
				var url=adminBaseUrl+'post-a-quote'
			}
			$.ajax({
				type:'POST',
				cache: false,
				contentType: false,
				processData: false,			
				url:  url,
				data:form_data,
				success: function(data){
						console.log(data.output);
						if(data.output == 'sucess')
						{
							$('#changeRefresh').hide();
							$('#sucessQuote').html('Quote submitted for review, once approved it will be shown under user quotes section.');
							setTimeout(function(){											
								window.location=adminBaseUrl+'post-a-quote';								
							}, 3000);
							
						}
						else if(data.output == 'updated')
						{
							$('#changeRefresh').hide();
							$('#sucessQuote').html('Quote updated sucessfully');
							setTimeout(function(){											
								window.location=adminBaseUrl+'post-a-quote';							
							}, 3000);
							
						}
				}
			});
			e.preventDefault();
		});	
	}
	
	// user search
	function MyQts(name)
	{
		alert(name);
	}
	
	function deleteUserQuote(qc_id){
		$("#hid_d_qc_id").val(qc_id);		
		$("#user_delete_quote_model").modal('show');
	}
	function quoteDeleteUser(){	
		var d 		= new Date();
		var time 	= d.getTime();
		var qc_id = $("#hid_d_qc_id").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'delete-user-quote?sRch='+time,
			data:{qc_id:qc_id},
			success: function(data){
				$("#user_delete_quote_model").modal('hide');
				if(data.output=='fail'){
					
					$("#myModalLabelw").html("Delete Confirmation");
					$("#alert-message").html("Server problem.");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					
					$("#myModalLabelw").html("Delete Confirmation");
					$("#alert-message").html("Sucessfully deleted the quote.");
					$("#cnfrmOk").hide();
					$("#hidden_common").modal('show');	
					setTimeout(function(){											
						window.location=adminBaseUrl+'view-userprofile/quote';
					}, 3000);
				}				
			}
		});
	}
	