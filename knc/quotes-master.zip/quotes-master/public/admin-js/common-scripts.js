// User Management
function viewUserMode(u_id){
	$("#ut_name").val('');
	$("#uf_fname").val('');
	$("#uf_lname").val('');
	$("#u_email").val('');
	$("#u_mobile").val('');
	$("#uf_about_me").val('');
	var d 		= new Date();
	var time 	= d.getTime();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/view-user-admin?sRch='+time,
		data:{u_id:u_id},
		success: function(data){
			if(data.output=="success"){				
				var imageUrl = adminBasePath+'/uploads/'+data.getUser.uf_pic;
				$("#view_image").html('<img src="'+imageUrl+'"class="img-thumbnail" style="width:250px;height:100px;">');
				$("#ut_name").val(data.getUser.ut_name);
				$("#uf_fname").val(data.getUser.uf_fname);
				$("#uf_lname").val(data.getUser.uf_lname);
				$("#u_email").val(data.getUser.u_email);
				$("#u_mobile").val(data.getUser.u_mobile);
				$("#uf_about_me").val(data.getUser.uf_about_me);
				$("#view_user").modal('show');
			}			
		}
	});
}
function hideUserhide(uid,statusMode){
	$("#status-alert-message").html("");
	$("#hid_uid").val(uid);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function hideUserMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var u_id = $("#hid_uid").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-user-status?sRch='+time,
		data:{status:status,u_id:u_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/user-management";
			}				
		}
	});
}
function deleteUserDelete(user_id,statusMode){
	$("#hid_u_id").val(user_id);		
	$("#status_del").modal('show');
}
function deleteUseradmin(){
	var d 		= new Date();
	var time 	= d.getTime();
	var u_id = $("#hid_u_id").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-user-status?sRch='+time,
		data:{status:'2',u_id:u_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				if(data.userexists==0){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/user-management";
				}else{
					console.log(data.userexists);
					$("#title-message").html("User Deletion");
					$("#alert-message").html("This User has assoicated quotes. If you want delete category, please delete category quotes first.");	
					$("#hidden_common").modal('show');					
				}
			}				
		}
	});
}
function addUserMode(user){
	var d 		= new Date();
	var time 	= d.getTime();
	$("#userForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		var u_email = $("#u_email").val();
		var uf_name = $("#uf_name").val();
		var u_ut_id = $("#u_ut_id").val();
		$("#title-message").html('');
		$("#alert-message").html('');	
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/admin-add-user?sRch='+time,
			data:{u_email:u_email,uf_name:uf_name,u_ut_id:u_ut_id},
			success: function(data){
				if(data.emailExists == "emailinrecord"){
					$("#title-message").html("Email Error");
					$("#alert-message").html("Entered email is already with us.");
					$("#hidden_common").modal('show');	
				}else{
					window.location = adminBaseUrl+'/user-management';
				}
			}
		});
		e.preventDefault();	
	});
}
function usersloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loadUserData").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/users-list?sRch='+time,
		success		: function(data){			
			$('#loadUserData').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>User Pic</th>'+
			'<th>Name</th>'+
			'<th>Email</th>'+
			'<th>Phone</th>'+
			'<th>Join Date</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "u_id" },
					{ "mData": "uf_pic" },
					{ "mData": "u_display_name"},
					{ "mData": "u_email"},
					{ "mData": "u_mobile"},					
					{ "mData": "joindate"},					
					{ "mData": "u_status"},
					{ "mData": "action" },
				] 
			});	
		}
	});
}

function adminLogout(){
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/admin-logout',
		data:{logout:'adminsession'},
		success: function(data){
			$('#hidden_logout').modal('hide');
			if(data.output=='1'){				
				window.location = adminBaseUrl;
			}
		}
	});
}
function loginChecking(jForm){ 
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loginForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		var u_email    = $("#u_email").val();
		var u_password = $("#u_password").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/checking-login?sRch='+time,
			data:{u_email:u_email,u_password:u_password},
			success: function(data){
				$("#errorLogin").html('');
				if(data.output == "emailnotinrecord"){
					$("#errorLogin").html('Entered email is not in records');
				}else if(data.output == "fail"){	
					$("#errorLogin").html('Please email is requried');						
				}else if(data.output == "wrongdeatils"){
					$("#errorLogin").html('Entered email or password are wrong');	
				}else if(data.output == "success"){
					window.location = adminBaseUrl+'/user-management';
				}
			}
		});
		e.preventDefault();	
	});
}
function logoutUser(usermode){
	if(usermode=='admin'){
		$('#hidden_logout').modal('show');	
	}
}
//Upload Author Pic
function uploadCategoryPic(fieldID,actionMode){
	var _URL = window.URL || window.webkitURL;
	var image;
	var fd = new FormData();
	var fileSize = $('#'+fieldID)[0].files[0].size;
	if(fieldID == 'catePic'){
	$("#hideLoad").show();
	if(fileSize <= 5242880){
		switch($('#'+fieldID).val().substring($('#'+fieldID).val().lastIndexOf('.') + 1).toLowerCase()){
			case 'png': case 'jpg': case 'jpeg': case 'jpe': case 'gif':			
			image = new Image();
			image.src = _URL.createObjectURL($('#'+fieldID)[0].files[0]);
			image.onload = function() {
				if(this.width == 250 && this.height == 250){
					fd.append( fieldID, $('#'+fieldID)[0].files[0]);
					$.ajax({
						url: adminBaseUrl+'/category-upload-pic?type='+fieldID,
						data: fd,
						processData: false,
						contentType: false,
						type: 'POST',
						success: function(returned){
							if(fieldID == 'catePic'){
								$('#qc_cat_pic').val(returned.imageName);
								$('#catgPic').attr('src', returned.Pic);
								$("#hideLoad").hide();
							}
						}
					});
				}else{
					$("#hideLoad").hide();
					 $('#'+fieldID).val('');
					  if(actionMode!="addMode"){
						$('#errorMes').html('Upload image size less than 5Mb');
						$('#imageDimentions').modal('hide');
					 }else{
						$('#dimentionsAuthor').html('Upload image size less than 5Mb');
						$('#imageDimentions').modal('show');
					 }
				}
			}
			break;
			default:
				$("#hideLoad").hide();	
			 $('#'+fieldID).val('');
			  if(actionMode!="addMode"){
				$('#errorMes').html('Upload image size less than 5Mb');
				$('#imageDimentions').modal('hide');
			 }else{
				$('#errorMes').html('');
				$('#dimentionsAuthor').html('Upload image size less than 5Mb');
				$('#imageDimentions').modal('show');
			 }
			break;
		}}else{
			$("#hideLoad").hide();
			 $('#'+fieldID).val('');
			 if(actionMode!="addMode"){
				$('#errorMes').html('Upload image size less than 5Mb');
				$('#imageDimentions').modal('hide');
			 }else{
				$('#errorMes').html('');
				$('#dimentionsAuthor').html('Upload image size less than 5Mb');
				$('#imageDimentions').modal('show');
			 }
		 }
	}
}
function addCategory(catname){
	var d 		= new Date();
	var time 	= d.getTime();
	$("#catForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#catLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var qc_cat_name  = $("#qc_cat_name").val();
		var qc_cat_pic  = $("#qc_cat_pic").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-category?sRch='+time,
			data:{qc_cat_name:qc_cat_name,qc_cat_pic:qc_cat_pic},
			success: function(data){
				$("#catLoader").hide();
				if(data.output=='alreadyexists'){
					$("#title-message").html("Category Confirmation");
					$("#alert-message").html("The Category is already added.");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/category-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function loadCategories(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#catloadingdata").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/category-lists?sRch='+time,
		success		: function(data){			
			$('#catloadingdata').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Category pic</th>'+
			'<th>Category Name</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "qc_cat_id" },
					{ "mData": "qc_cat_pic" },
					{ "mData": "qc_cat_name" },
					{ "mData": "qc_status" },
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function editCategory(catid,catname,imageName){
	$("#view_category").modal('hide');
	$("#qc_cat_id").val(catid);
	$("#qc_cat_name").val(catname);
	if(imageName!="" && imageName!=null){
		var imageUrl = adminBasePath+'/categorypics/'+imageName;
	}else{
		var imageUrl = adminBasePath+'/images/category.png';
	}
	$('#catgPic').attr('src', imageUrl);
	$('#qc_cat_pic').val(imageName);
	$("#update_category").modal('show');	
}
function viewCategory(catid,catname,imageName){
	$("#update_category").modal('hide');	
	$("#qc_cat_namee").val(catname);
	if(imageName!="" && imageName!=null){
		var imageUrl = adminBasePath+'/categorypics/'+imageName;
	}else{
		var imageUrl = adminBasePath+'/images/category.png';
	}
	$("#view_image").html('<img src="'+imageUrl+'"class="img-thumbnail" style="width:100%;height:30%;">');
	$("#view_category").modal('show');	
}
function updateCategory(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#updateCate").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
			$("#catLoader").show();
			$("#title-message").html("");
			$("#alert-message").html("");
			var qc_cat_id   = $("#qc_cat_id").val();
			var qc_cat_name = $("#qc_cat_name").val();
			var qc_cat_pic  = $("#qc_cat_pic").val();
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'/update-category?sRch='+time,
				data:{qc_cat_name:qc_cat_name,qc_cat_id:qc_cat_id,qc_cat_pic:qc_cat_pic},
				success: function(data){
					$("#catLoader").hide();
					if(data.output=='alreadyexists'){
						$("#title-message").html("Category Confirmation");
						$("#alert-message").html("The Category is already added.");
						$("#hidden_common").modal('show');	
					}else if(data.output=='success'){
						$("#hidden_common").modal('hide');	
						window.location=adminBaseUrl+"/category-management";
					}				
				}
			});
		e.preventDefault();	
	});
}
function hideCategory(catid,statusMode){
	$("#status-alert-message").html("");
	$("#hid_catid").val(catid);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function deleteCategory(catid,statusMode){
	$("#hid_d_catid").val(catid);		
	$("#status_del").modal('show');
}
function deleCategory(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_cat_id = $("#hid_d_catid").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-category-status?sRch='+time,
		data:{status:'2',qc_cat_id:qc_cat_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				if(data.catQuotesCnt==0){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/category-management";
				}else{
					console.log(data.catQuotesCnt);
					$("#title-message").html("Category Deletion");
					$("#alert-message").html("This Category has assoicated quotes. If you want delete category, please delete category quotes first.");	
					$("#hidden_common").modal('show');					
				}
			}				
		}
	});
}
function hideCategoryMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_cat_id = $("#hid_catid").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-category-status?sRch='+time,
		data:{status:status,qc_cat_id:qc_cat_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/category-management";
			}				
		}
	});
}
function addLanguage(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	$("#langForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#lanLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var lang_name  = $("#lang_name").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-language?sRch='+time,
			data:{lang_name:lang_name},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='alreadyexists'){
					$("#title-message").html("Language Confirmation");
					$("#alert-message").html("The language is already added.");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/language-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function langloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loadLanguages").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/language-lists?sRch='+time,
		success		: function(data){			
			$('#loadLanguages').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Language Name</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "lang_id" },
					{ "mData": "lang_name" },
					{ "mData": "lang_status" },
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function editLanguage(langid,langname){
	$("#view_category").modal('hide');
	$("#lang_id").val(langid);
	$("#lang_name").val(langname);
	$("#update_language").modal('show');	
}
function viewLanguage(langid,langname){
	$("#update_language").modal('hide');	
	$("#lang_namee").val(langname);
	$("#view_language").modal('show');	
}
function updateLanguage(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#updateLang").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
			$("#langLoader").show();
			$("#title-message").html("");
			$("#alert-message").html("");
			var lang_id   = $("#lang_id").val();
			var lang_name = $("#lang_name").val();
			$.ajax({
				type:'POST',
				url:  adminBaseUrl+'/update-language?sRch='+time,
				data:{lang_name:lang_name,lang_id:lang_id},
				success: function(data){
					$("#langLoader").hide();
					if(data.output=='alreadyexists'){
						$("#title-message").html("Language Confirmation");
						$("#alert-message").html("The language is already added.");
						$("#hidden_common").modal('show');	
					}else if(data.output=='success'){
						$("#hidden_common").modal('hide');	
						window.location=adminBaseUrl+"/language-management";
					}				
				}
			});
		e.preventDefault();	
	});
}
function hideLanguage(langid,statusMode){
	$("#status-alert-message").html("");
	$("#hid_langid").val(langid);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function deleteLanguage(langid,statusMode){
	$("#hid_d_langid").val(langid);		
	$("#status_del").modal('show');
}
function deleLanguage(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var lang_id = $("#hid_d_langid").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-language-status?sRch='+time,
		data:{status:'2',lang_id:lang_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				if(data.langQuotesCnt==0){
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/language-management";
				}else{
					console.log(data.langQuotesCnt);
					$("#title-message").html("Language Deletion");
					$("#alert-message").html("This Language has assoicated quotes. If you want delete language, please delete language quotes first.");	
					$("#hidden_common").modal('show');				
				}				
			}				
		}
	});
}
function hideLanguageMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var lang_id = $("#hid_langid").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-language-status?sRch='+time,
		data:{status:status,lang_id:lang_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/language-management";
			}				
		}
	});
}
//Upload Author Pic
function uploadAuthorPic(fieldID){	
	var _URL = window.URL || window.webkitURL;
	var image;
	var fd = new FormData();
	var fileSize = $('#'+fieldID)[0].files[0].size;
	$('#imageLoader').show();
	if(fieldID == 'authorPic'){
	$("#hideLoad").show();
	if(fileSize <= 5242880){
		switch($('#'+fieldID).val().substring($('#'+fieldID).val().lastIndexOf('.') + 1).toLowerCase()){
			case 'png': case 'jpg': case 'jpeg': case 'jpe': case 'gif':			
			image = new Image();
			image.src = _URL.createObjectURL($('#'+fieldID)[0].files[0]);
			image.onload = function() {
				if(this.width == 250 && this.height == 250){
					fd.append( fieldID, $('#'+fieldID)[0].files[0]);
					$.ajax({
						url: adminBaseUrl+'/author-upload-pic?type='+fieldID,
						data: fd,
						processData: false,
						contentType: false,
						type: 'POST',
						success: function(returned){
							if(fieldID == 'authorPic'){
								$('#au_pic').val(returned.imageName);
								$('#authPic').attr('src', returned.Pic);
								$("#hideLoad").hide();
							}
						}
					});
				}else{
					$("#hideLoad").hide();
					 $('#'+fieldID).val('');
					 $('#dimentionsAuthor').html('Upload image is 250 X 250.');
					 $('#imageDimentions').modal('show');
				}
			}
			break;
			default:
				$("#hideLoad").hide();	
			 $('#'+fieldID).val('');
			 $('#dimentionsAuthor').html('Upload image is 250 X 250.');
			 $('#imageDimentions').modal('show');
			break;
		}}else{
				$("#hideLoad").hide();
			 $('#'+fieldID).val('');
			 $('#dimentionsAuthor').html('Upload image size less than 5Mb');
			 $('#imageDimentions').modal('show');
		 }
	}
}
function addAuthor(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#authorForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#authorLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var au_fname       = $("#au_fname").val();
		var au_lname       = $("#au_lname").val();
		var au_pic         = $("#au_pic").val();
		var au_birth_year  = $("#au_birth_year").val();
		var au_deadth_year = $("#au_death_year").val();
		var au_descrpt     = $("#au_descrpt").val();
		var au_wiki_link   = $("#au_wiki_link").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-author?sRch='+time,
			data:{au_fname:au_fname,au_lname:au_lname,au_pic:au_pic,au_birth_year:au_birth_year,au_deadth_year:au_deadth_year,au_descrpt:au_descrpt,au_wiki_link:au_wiki_link},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Author Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#au_fname").val('');
					$("#au_lname").val('');
					$("#au_pic").val('');
					$("#au_birth_year").val('');
					$("#au_death_year").val('');
					$("#au_descrpt").val('');
					$("#au_wiki_link").val('');
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/author-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function updateAuthor(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#authorUpdateForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#authorLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var au_fname       = $("#au_fname").val();
		var au_lname       = $("#au_lname").val();
		var au_pic         = $("#au_pic").val();
		var au_birth_year  = $("#au_birth_year").val();
		var au_deadth_year = $("#au_deadth_year").val();
		var au_descrpt     = $("#au_descrpt").val();
		var au_wiki_link   = $("#au_wiki_link").val();
		var au_id 		   = $("#au_id").val();
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/update-author?sRch='+time,
			data:{au_fname:au_fname,au_lname:au_lname,au_pic:au_pic,au_birth_year:au_birth_year,au_deadth_year:au_deadth_year,au_descrpt:au_descrpt,au_wiki_link:au_wiki_link,au_id:au_id},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Author Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){					
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/author-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function authorloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#loadAuthorData").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/author-lists?sRch='+time,
		success		: function(data){			
			$('#loadAuthorData').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Author pic</th>'+
			'<th>First Name</th>'+
			'<th>Last Name</th>'+
			'<th>Birth Year</th>'+
			'<th>Deadth Year</th>'+
			'<th>Description</th>'+
			'<th>Wiki Link</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "au_id" },
					{ "mData": "au_pic" },
					{ "mData": "au_fname"},
					{ "mData": "au_lname"},
					{ "mData": "au_birth_year"},					
					{ "mData": "au_deadth_year"},
					{ "mData": "au_descrpt"},
					{ "mData": "au_wiki_link"},
					{ "mData": "au_status"},
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function viewAuthor(au_id){
	$("#au_fname").val('');
	$("#au_lname").val('');
	$("#au_birth_year").val('');
	$("#au_deadth_year").val('');
	$("#au_descrpt").val('');
	$("#au_wiki_link").val('');
	var d 		= new Date();
	var time 	= d.getTime();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/view-author?sRch='+time,
		data:{au_id:au_id},
		success: function(data){
			if(data.output=="success"){	
				if(data.getAuthor.au_pic!="" && data.getAuthor.au_pic!=null){
					var au_name = data.getAuthor.au_fname;
					var au_name = au_name.toLowerCase();
					var au_pic  = au_name.replace(' ', '_');
					var authpic = au_pic+".jpg";
					var imageUrl = adminBasePath+'/author_imgs/'+authpic;
				}else{
					var imageUrl = adminBasePath+'/images/category.png';
				}				
				$("#view_image").html('<img src="'+imageUrl+'"class="img-thumbnail" style="width:250px;height:100px;">');
				$("#au_fname").val(data.getAuthor.au_fname);
				$("#au_lname").val(data.getAuthor.au_lname);
				$("#au_birth_year").val(data.getAuthor.au_birth_year);
				$("#au_deadth_year").val(data.getAuthor.au_deadth_year);
				$("#au_descrpt").val(data.getAuthor.au_descrpt);
				$("#au_wiki_link").val(data.getAuthor.au_wiki_link);
				$("#view_author").modal('show');
			}			
		}
	});
}

function hideAuthor(au_id,statusMode){
	$("#status-alert-message").html("");
	$("#hid_au_id").val(au_id);
	$("#hid_status").val(statusMode);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure, you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure, you want to the status to active?");
	}	
	$("#status_common").modal('show');
}
function deleteAuthor(au_id,statusMode){
	$("#hid_d_au_id").val(au_id);		
	$("#status_del").modal('show');
}
function deleAuthor(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var au_id = $("#hid_d_au_id").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-author-status?sRch='+time,
		data:{status:'2',au_id:au_id},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				if(data.authorQCnt==0){
					$("#hidden_common").modal('hide');
					window.location=adminBaseUrl+"/author-management";		
				}else{
					console.log(data.authorQCnt);
					$("#title-message").html("Author Deletion");
					$("#alert-message").html("This author has assoicated quotes. If you want delete author, please delete author quotes first.");	
					$("#hidden_common").modal('show');	
				}							
			}				
		}
	});
}
function hideAuthorMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var au_id = $("#hid_au_id").val();
	var status = $("#hid_status").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-author-status?sRch='+time,
		data:{status:status,au_id:au_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				window.location=adminBaseUrl+"/author-management";
			}				
		}
	});
}

function addQuote(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	$("#qouteForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#quoteLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var qc_au_id       = $("#qc_au_id").val();
		var qc_qc_cat_id   = $("#qc_qc_cat_id").val();
		var qc_lang_id     = $("#qc_lang_id").val();
		var qc_name        = $("#qc_name").val();
		var qc_image       = $("#qc_image").val();
		var qc_tags        = $("#qc_tags").val();
		var qc_quote_short_flag  ="";
		if($("#qc_quote_short_flag").is(':checked')){
			var qc_quote_short_flag  = 1;
		}
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/add-quote?sRch='+time,
			data:{qc_au_id:qc_au_id,qc_qc_cat_id:qc_qc_cat_id,qc_lang_id:qc_lang_id,qc_name:qc_name,qc_image:qc_image,qc_tags:qc_tags,qc_quote_short_flag:qc_quote_short_flag},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Quote Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){
					$("#qc_au_id").val('');
					$("#qc_qc_cat_id").val('');
					$("#qc_name").val('');
					$("#qc_image").val('');
					$("#qc_lang_id").val('');
					$("#qc_tags").val('');
					$("#hidden_common").modal('hide');	
					window.location=adminBaseUrl+"/quotes-management";
				}				
			}
		});
		e.preventDefault();	
	});
}
function updateQuote(formid){
	var d 		= new Date();
	var time 	= d.getTime();
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_redirect_url = $('#qc_redirect_url').val();
	$("#qouteForm").formValidation().on('success.form.fv', function(e) {
		e.stopImmediatePropagation();
		$("#authorLoader").show();
		$("#title-message").html("");
		$("#alert-message").html("");
		var qc_au_id       = $("#qc_au_id").val();
		var qc_qc_cat_id   = $("#qc_qc_cat_id").val();
		var qc_lang_id     = $("#qc_lang_id").val();
		var qc_name        = $("#qc_name").val();
		var qc_image       = $("#qc_image").val();
		var qc_id 		   = $("#qc_id").val();
		var qc_tags       = $("#qc_tags").val();
		var qc_quote_short_flag  ="";
		if($("#qc_quote_short_flag").is(':checked')){
			var qc_quote_short_flag  = 1;
		}
		$.ajax({
			type:'POST',
			url:  adminBaseUrl+'/update-quote?sRch='+time,
			data:{qc_au_id:qc_au_id,qc_qc_cat_id:qc_qc_cat_id,qc_lang_id:qc_lang_id,qc_name:qc_name,qc_image:qc_image,qc_id:qc_id,qc_tags:qc_tags,qc_quote_short_flag:qc_quote_short_flag},
			success: function(data){
				$("#lanLoader").hide();
				if(data.output=='fail'){
					$("#title-message").html("Quote Confirmation");
					$("#alert-message").html("Server problem");
					$("#hidden_common").modal('show');	
				}else if(data.output=='success'){					
					$("#hidden_common").modal('hide');	
					if(qc_redirect_url == 1){
						window.location = adminBaseUrl+"/user-quotes";
					}else{
						window.location = adminBaseUrl+"/quotes-management";
					}
				}				
			}
		});
		e.preventDefault();	
	});
}
function quoteloadingdata(){	
	var d 		= new Date();
	var time 	= d.getTime();
	$("#quoteloaddata").html("Please wait loading.....");
	$.ajax({
		type		:	'GET',
		dataType	:	'json',
		url			: 	adminBaseUrl+'/quotes-lists?sRch='+time,
		success		: function(data){			
			$('#quoteloaddata').html('<table id="resource" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">'+
			'<thead>'+
			'<tr>'+
			'<th>S.No</th>'+
			'<th>Quote Image</th>'+
			'<th>Author Name</th>'+
			'<th>Categorty Name</th>'+
			'<th>Language Name</th>'+
			'<th>Quote Name</th>'+
			'<th>Status</th>'+
			'<th>Actions</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody></tbody></table>');				
			var oTable = $('#resource').dataTable({
				"aLengthMenu"		: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "All"]],
				"iDisplayLength"	: 25,
				"paging"		: true,
				"lengthChange"	: true,
				"searching"		: true,
				"ordering"		: true,
				"info"			: true,
				"autoWidth"		: true,
				"deferRender"   : true,
				"aaData"		: data.aaData,
				"aoColumns"		: [
					{ "mData": "qc_id" },
					{ "mData": "qc_image" },
					{ "mData": "qc_au_id"},
					{ "mData": "qc_qc_cat_id"},
					{ "mData": "qc_lang_id"},					
					{ "mData": "qc_name"},				
					{ "mData": "qc_status"},
					{ "mData": "action" },
				] 
			});	
		}
	});
}
function viewQuote(qc_id){
	$("#qc_au_id").html('');
	$("#qc_qc_cat_id").html('');
	$("#qc_lang_id").html('');
	$("#qc_name").html('');
	$("#qc_image").html('');
	var d 		= new Date();
	var time 	= d.getTime();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/view-quote?sRch='+time,
		data:{qc_id:qc_id},
		success: function(data){
			if(data.output=="success"){				
				var imageUrl = baseUrl+'/quotes/'+data.getQuote.qc_image;
				$("#view_image").html('<img src="'+imageUrl+'"class="img-thumbnail" style="width:250px;height:100px;">');				
				$("#qc_au_id").html(data.getQuote.au_fname);
				$("#qc_qc_cat_id").html(data.getQuote.qc_cat_name);
				$("#qc_lang_id").html(data.getQuote.lang_name);
				$("#qc_name").html(data.getQuote.qc_name);
				$("#view_quote").modal('show');
			}			
		}
	});
}

function approveQuote(qc_id,statusMode,type,email){
	$("#status-approve-alert-message").html("");
	$("#hid_qc_id").val(qc_id);
	$("#hid_status").val(statusMode);
	$("#hid_app_type").val(type);
	$("#hid_u_email").val(email);
	if(statusMode == 4){
		$("#status-approve-alert-message").html("Are you sure you want to deny?");
	}else{
		$("#status-approve-alert-message").html("Are you sure you want to approve?");
	}	
	$("#status_approve_common").modal('show');
}


function approveQuoteMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_id = $("#hid_qc_id").val();
	var status = $("#hid_status").val();
	var appType = $("#hid_app_type").val();
	var userEmail = $("#hid_u_email").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/approve-quote-status?sRch='+time,
		data:{status:status,qc_id:qc_id,userEmail:userEmail},
		success: function(data){
			$("#status_approve_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				if(appType == 1){
					window.location=adminBaseUrl+"/user-quotes";
				}else{
					window.location=adminBaseUrl+"/quotes-management";
				}
			}				
		}
	});
}

function hideQuote(qc_id,statusMode,type){
	$("#status-alert-message").html("");
	$("#hid_qc_id").val(qc_id);
	$("#hid_status").val(statusMode);
	$("#hid_type").val(type);
	if(statusMode==0){
		$("#status-alert-message").html("Are you sure you want to the status to deactive?");
	}else{
		$("#status-alert-message").html("Are you sure you want to the status to active?");
	}	
	$("#status_common").modal('show');
}

function deleteQuote(qc_id,statusMode,type){
	$("#hid_d_qc_id").val(qc_id);		
	$("#status_del").modal('show');
	$("#hid_del_type").val(type);
}
function deleQuote(){	
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_id 	= $("#hid_d_qc_id").val();
	var deltype = $("#hid_del_type").val(type);
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-quote-status?sRch='+time,
		data:{status:'2',qc_id:qc_id,type:'dele'},
		success: function(data){
			$("#status_del").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				if(deltype == 1){
					window.location=adminBaseUrl+"/user-quotes";
				}else{
					window.location=adminBaseUrl+"/quotes-management";
				}
			}				
		}
	});
}

function hideQuoteMode(){
	var d 		= new Date();
	var time 	= d.getTime();
	var qc_id 	= $("#hid_qc_id").val();
	var status  = $("#hid_status").val();
	var type 	= $("#hid_type").val();
	$.ajax({
		type:'POST',
		url:  adminBaseUrl+'/update-quote-status?sRch='+time,
		data:{status:status,qc_id:qc_id},
		success: function(data){
			$("#status_common").modal('hide');
			if(data.output=='fail'){
				$("#title-message").html("Status Confirmation");
				$("#alert-message").html("Server problem.");
				$("#hidden_common").modal('show');	
			}else if(data.output=='success'){
				$("#hidden_common").modal('hide');	
				if(type == 1){
					window.location=adminBaseUrl+"/user-quotes";
				}else{
					window.location=adminBaseUrl+"/quotes-management";
				}
			}				
		}
	});
}