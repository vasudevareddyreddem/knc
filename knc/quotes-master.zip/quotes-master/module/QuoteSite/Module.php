<?php
namespace QuoteSite;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\ModuleManager\Feature;
use Zend\Loader;
use Zend\EventManager\EventInterface;
use Zend\Mvc\Router\RouteMatch;
use Zend\ModuleManager\ModuleManager;
use Zend\Stdlib\Hydrator\ClassMethods;
use QuoteSite\Model\User;
use QuoteSite\Model\UserTable;
/* Helpers Method */
use Zend\ModuleManager\Feature\ViewHelperProviderInterface; 

class Module implements 
	Feature\AutoloaderProviderInterface,
    Feature\ConfigProviderInterface,
    Feature\ServiceProviderInterface,
	/* Helper Implements Method */
    Feature\ViewHelperProviderInterface
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
			),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }    
    public function getServiceConfig()
    {
		return array(
			'factories' => array(
				'QuoteSite\Model\UserFactory'=>'QuoteSite\Factory\Model\UserTableFactory',			
			),			
		);
    }
	/* Set View HelperConfig */
	public function getViewHelperConfig()
	{
		return array(
			'factories' => array(
				'favviewscnt_helper' => function($sl) {
					$sm = $sl->getServiceLocator(); 
					$helper = new View\Helper\Quotesviewshelper($sm);
					return $helper;
				}
			)
		);   
   }
   /* End */
}