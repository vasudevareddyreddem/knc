<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'QuoteSite\Controller\Authors'		 			=> 'QuoteSite\Controller\AuthorsController',
            'QuoteSite\Controller\Users'		 			=> 'QuoteSite\Controller\UsersController',
            'QuoteSite\Controller\Categories'		 			=> 'QuoteSite\Controller\CategoriesController',
            'QuoteSite\Controller\Quotes'		 			=> 'QuoteSite\Controller\QuotesController',
        ),
    ),
    // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
			'authors' => array(
				'type' => 'Literal',
				'options' => array(
					'route' => '/authors',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Authors',
						'action'     => 'index',
					),
				),
			),
			'author-ajax' => array(
				'type' => 'Literal',
				'options' => array(
					'route' => '/author-ajax',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Authors',
						'action'     => 'authorAjax',
					),
				),
			),	
			'user-login' => array(
				'type' => 'Literal',
				'options' => array(
					'route' => '/user-login',
					'defaults' => array(
						'controller' => 'Users\Controller\Users',
						'action'     => 'userLogin',
					),
				),
			),
			'reg-authentication' => array(
				'type' => 'Literal',
				'options' => array(
					'route' => '/reg-authentication',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'regAuthentication',
					),
				),
			),
			'categories-list' => array(
				'type' => 'Literal',
				'options' => array(
					'route' => '/categories',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Categories',
						'action'     => 'categoriesList',
					),
				),
			),		
			'logout' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/logout',
					'defaults' => array(
						'controller' => 'Users\Controller\Users',
						'action'     => 'logout',
					),
				),
			),
			'change-password' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/change-password',
					'defaults' => array(
						'controller' => 'Users\Controller\Users',
						'action'     => 'changePassword',
					),
				),
			),
			'view-profile' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/view-profile[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'Users\Controller\Users',
						'action'     => 'viewProfile',
					),
				),
			),
			'login-user' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/login-user[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'userLogin',
					),
				),
			),
			'top-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/top-quotes[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'topQuotes',
					),
				),
			),
			'short-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/short-quotes[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'shortQuotes',
					),
				),
			),
			
			'view-userprofile' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/view-userprofile[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'viewUserprofile',
					),
				),
			),
			'serach-quote-ajax' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/serach-quote-ajax[/:id]',
					'constraints' => array(
						   'id' => '[%&.;%&,;a-zA-Z0-9][%&.+;%&,+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'serachQuoteAjax',
					),
				),
			),
			'user-signup' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/user-signup[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'userSignup',
					),
				),
			),
			'subscribe-mail' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/subscribe-mail[/:id]',
					'constraints' => array(
						   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
						),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'subscribeMail',
					),
				),
			),
			'user-logout' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/user-logout',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'userLogout',
					),
				),
			),
			'all-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/all-quotes',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'allQuotes',
					),
				),
			),
			'quote-of-the-day' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/quote-of-the-day',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'quoteOfTheDay',
					),
				),
			),
			'user-fav' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/user-fav',
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'userFavourite',
					),
				),
			),
			'viewers' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/viewers[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&.;%&,;a-zA-Z0-9][%&.+;%&,+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'userViews',
					),
				),
			),
			'quote-views' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/quote-views[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'quoteViews',
					),
				),
			),
			'all-cat-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/all-cat-quotes[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'allcategoryQuotes',
					),
				),
			),
			'category' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/category[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'category',
					),
				),
			),
			'all-auth-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/all-auth-quotes[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&.;%&,;a-zA-Z0-9][%&.+;%&,+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'allauthorQuotes',
					),
				),
			),
			'author' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/author[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&.;%&,;a-zA-Z0-9][%&.+;%&,+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'author',
					),
				),
			),
			'author-quotes-ajax' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/author-quotes-ajax[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&.;%&,;a-zA-Z0-9][%&.+;%&,+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'authorQuotesAjax',
					),
				),
			),
			'all-quotes-list' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/all-quotes-list[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'allQuotesList',
					),
				),
			),
			'short-quotes-list' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/short-quotes-list[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'shortQuotesList',
					),
				),
			),
			'home-refresh' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/home-refresh[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'shortQuotesList',
					),
				),
			),
			'search-quote' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/search-quote[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&.;%&,;a-zA-Z0-9][%&.+;%&,+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'searchQuote',
					),
				),
			),
			'search' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/search[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'viewSearch',
					),
				),
			),
			'update-profile' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/update-profile[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'updateUserProfile',
					),
				),
			),
			
			'update-profile-ajax' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/update-profile-ajax[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'updateUserProfileAjax',
					),
				),
			),
			'delete-user-quote' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/delete-user-quote[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'deleteUserQuote',
					),
				),
			),
			'check-password' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/check-password[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'checkPassword',
					),
				),
			),
			'update-password' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/update-password[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'updatePassword',
					),
				),
			),
			'check-email' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/check-email[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'checkForgotEmail',
					),
				),
			),
			'reset-password' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/reset-password[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'resetPassword',
					),
				),
			),
			'check-fuid' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/check-fuid[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'checkFgtUid',
					),
				),
			),
			'all-empty-picure-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/all-empty-picure-quotes[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'allEmptyPicureQuotes',
					),
				),
			),
			'all-picure-quotes' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/all-picure-quotes[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'allPicureQuotes',
					),
				),
			),
			'make-picture-quote' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/make-picture-quote[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'makePictureQuote',
					),
				),
			),
			'save-picture-quote' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/save-picture-quote[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'savePictureQuote',
					),
				),
			),
			'upload-cam-picture' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/upload-cam-picture[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'uploadCamPicture',
					),
				),
			),
			'upload-make-picture' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/upload-make-picture[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'uploadMakePicture',
					),
				),
			),
			'post-a-quote' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/post-a-quote[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'postAQuote',
					),
				),
			),
			'create-a-quote' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/create-a-quote[/:id]',
					'constraints' => array(
					   'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Quotes',
						'action'     => 'createAQuote',
					),
				),
			),
			'upload-profile-image' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/upload-profile-image[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'uploadProfileImage',
					),
				),
			),
			'upload-quote-image' => array(
				'type' => 'segment',
				'options' => array(
					'route'    => '/upload-quote-image[/:id][/:userid]',
					'constraints' => array(
					   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
					),
					'defaults' => array(
						'controller' => 'QuoteSite\Controller\Users',
						'action'     => 'uploadQuoteImage',
					),
				),
			),
			
        ),
	),     
    'view_manager' => array(
        'template_path_stack' => array(
            'QuoteSite' => __DIR__ . '/../view',
        ),
		'strategies' => array(
            'ViewJsonStrategy',
        ),
    ),
);
?>