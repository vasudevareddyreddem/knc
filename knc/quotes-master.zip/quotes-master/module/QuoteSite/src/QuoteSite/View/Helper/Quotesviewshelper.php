<?php
	namespace QuoteSite\View\Helper;
	use Zend\View\Helper\AbstractHelper;
	use Zend\ServiceManager\ServiceLocatorAwareInterface;
	use Zend\ServiceManager\ServiceLocatorInterface;
    use Zend\View\Exception;
	 
	class Quotesviewshelper extends \Zend\View\Helper\AbstractHelper implements ServiceLocatorAwareInterface
	{
	    
		
		/**
		* @var ServiceLocatorInterface
		*/
		protected $serviceLocator;
		protected $quotesTable;
		protected $favoritesTable;
		protected $quoteViewsTable;
		protected $quoteCategoriesTable;
		/**
		* Set the service locator.
		*
		* @param ServiceLocatorInterface $serviceLocator
		* @return AbstractHelper
		*/
		public function setServiceLocator(ServiceLocatorInterface $serviceLocator)
		{
			$this->serviceLocator = $serviceLocator;
			return $this;
		}

		/**
		 * Get the service locator.
		 *
		 * @return \Zend\ServiceManager\ServiceLocatorInterface
		 */
		public function getServiceLocator()
		{
			return $this->serviceLocator;
		}
		
		public function __invoke($str, $find)
		{
			if (! is_string($str)){
				return 'must be string';
			}
	 
			if (strpos($str, $find) === false){
				return 'not found';
			}
	 
			return 'found';
		}
		public function userInformation($qc_id){
			$favCnt = 0;
			$quotesFavVIews = $this->getQuotesTable()->subquerywithhelper($qc_id);
			if(isset($quotesFavVIews['fav']) && $quotesFavVIews['fav']!=""){
				$favCnt = $quotesFavVIews['fav'];				
			}else{
				$favCnt = 0;
			}
			return $quotesFavVIews;
		}
		// Get Quote Views
		public function getQuotesViewCount($qc_id){
			$countofviewss  = $this->getQuoteViewsTable()->countviewQuote($qc_id);
			$countofviews  = 0;		
			if(count($countofviewss)!=0){
				foreach($countofviewss as $countofviewsss){
					if(isset($countofviewsss['view_id']) && $countofviewsss['view_id']!=""){
						$countofviews  += $countofviewsss['view_count'];
					}else{
						$countofviews  = 0;
					}
				}
			}else{
				$countofviews  = 0;
			}
			return $countofviews;
		}
		
		public function getUserFavorate($uid,$qc_id){
			$userIsfav = 0;
			$countfavorites    = $this->getUserFavTable()->checkFav($uid,$qc_id);
			$countofviews     = 0;
			if($countfavorites>0){
				$userIsfav =1;
			}else{
				$userIsfav =0;
			}
			return $userIsfav;
		}
		public function getQuoteCategories($qc_id){
			$countfavorites    = $this->getQuoteCategoriesTable()->getQuoteCategory($qc_id);
			
		}		
		public function getQuotesTable()
		{
			if (null == $this->quotesTable) {
								   
			  $this->quotesTable = $this->getServiceLocator()->getServiceLocator()->get('Models\Model\QuotesFactory');
			}
			return $this->quotesTable;
		}
		
		public function getQuoteCategoriesTable()
		{
			if (null == $this->quoteCategoriesTable) {
								   
			  $this->quoteCategoriesTable = $this->getServiceLocator()->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
			}
			return $this->quoteCategoriesTable;
		}
		
		public function getQuoteViewsTable()
		{
			if (null == $this->quotesTable) {
								   
			  $this->quoteViewsTable = $this->getServiceLocator()->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
			}
			return $this->quoteViewsTable;
		}
		public function getUserFavTable()
		{
			if (null == $this->favoritesTable) {								   
			  $this->favoritesTable = $this->getServiceLocator()->getServiceLocator()->get('Models\Model\FavoritesFactory');
			}
			return $this->favoritesTable;
		}	
	}
?>