<?php
namespace QuoteSite\Controller;

use Zend\View\Model\ModelInterface;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\Session\Container;

class UsersController extends AbstractActionController
{
    public function indexAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];		
		return new ViewModel(array(					
			'baseUrl' 				=>  $baseUrl,
			'basePath'  			=>  $basePath,
			
		));		
	}
		
	public function userLoginAction()
	{
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$userTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userType 						= 2;
		$checkUser						= $userTable->checkUserType($_POST,$userType);		
		if($checkUser != ""){			
			$user_session->userId		=	$checkUser['u_id'];
			$user_session->email		=	$checkUser['u_email'];
			$user_session->displayName	=	ucwords(strtolower($checkUser['u_display_name']));
			$user_session->userType	    =	$checkUser['u_ut_id'];
			return new JsonModel(array(					
				'output'    			=>  'sucess'
			));
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}		
	}
	public function getQuotesViewCount($qc_id){
		$quotesviewsTable = $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$countofviewss  = $quotesviewsTable->countviewQuote($qc_id);
		$countofviews  = 0;		
		if(count($countofviewss)!=0){
			foreach($countofviewss as $countofviewsss){
				if(isset($countofviewsss['view_id']) && $countofviewsss['view_id']!=""){
					$countofviews  += $countofviewsss['view_count'];
				}else{
					$countofviews  = 0;
				}
			}
		}else{
			$countofviews  = 0;
		}
		return $countofviews;
	}
	public function viewUserprofileAction()
	{
		
		$routes = $this->params()->fromRoute('id');
		//echo 'hello';print_r($routes);exit;
		$user_session 			= new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$loggedInId 			= $user_session->userId;
		$userTable              = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$authorsTable     	    = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$CategoriesTable    	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$quotesTable 			    = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$favsTable 			    = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');		
		$catList 				= $CategoriesTable->famousCategories($flag=1);
		$AuthList               = $authorsTable->famousAuthors($flag=1);
		if(isset($routes) && $routes != "" && $routes == 'fav')
		{
			$favQuoteList           = $quotesTable->favQuotes( $loggedInId,$flag='fav' );
		}
		else if(isset($routes) && $routes != "" && $routes == 'quote')
		{
			$favQuoteList           = $quotesTable->favQuotes( $loggedInId,$flag='quote' );
		}
		else if(isset($routes) && $routes != "" && $routes == 'msg')
		{
			$favQuoteList           = $quotesTable->favQuotes( $loggedInId,$flag='quote' );
		}
		else if($routes == ""){
			$favQuoteList           = $quotesTable->favQuotes( $loggedInId,$flag='quote' );
		}
		$favQuotesCnt           = $favsTable->favQuotesCount( $loggedInId );		
		$userType = 2;		
		$getUserData			= $userTable->userData($loggedInId,$userType);		
		$pageCount  = 10;		
		$favQuoteList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$favQuoteList->setItemCountPerPage($pageCount);	
		$favQuoteList->setPageRange(5);
		$QuoteCount = $favQuoteList->getTotalItemCount();
		$favQt = array();
		$countofviews = 0;
		$countoffav = 0;
		
		if(count($favQuoteList))
		{
			foreach($favQuoteList as $q=>$qDay)
			{
				$qc_id = $qDay->qc_id;
				$countofviews  = $this->getQuotesViewCount($qc_id);
				$countoffav    = $favsTable->countEachQuote($qc_id);
				
				$favQt[$q]['qc_id'] 		= $qDay->qc_id;
				$favQt[$q]['qc_name'] 		= $qDay->qc_name;
				$favQt[$q]['qc_image']		= $qDay->qc_image;
				$favQt[$q]['qc_tags']		= $qDay->qc_tags;
				$favQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$favQt[$q]['fav']			= $qDay->fav;
				$favQt[$q]['au_id']			= $qDay->au_id;
				$favQt[$q]['au_fname']		= $qDay->au_fname;
				$favQt[$q]['au_lname']		= $qDay->au_lname;
				$favQt[$q]['au_pic']		= $qDay->au_pic;
				$favQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$favQt[$q]['qc_cat_name']	= $qDay->qc_cat_name;
				$favQt[$q]['viewCounnt']    = $countofviews;
				$favQt[$q]['favCount']		= $countoffav;
			}
			
		}
		
		return new ViewModel(array(					
			'baseUrl' 						=>  $baseUrl,
			'basePath'  					=>  $basePath,
			'getUserData'  					=>  $getUserData,
			'catList'  						=>  $catList,
			'AuthList'  					=>  $AuthList,
			'favQuoteList'  				=>  $favQt,
			'favQuotesCnt'  				=>  $favQuotesCnt,
			'paginationuserprofile' 		=>  $favQuoteList,
			'pageCount' 					=>  $pageCount,
			'QuoteCount' 					=>  $QuoteCount,
		));
	}
	
	public function userSignupAction()
    {
		$user_session 	=   new Container('user');
		$admin_session 	= 	new Container('admin');		
		$baseUrls 		= $this->getServiceLocator()->get('config');
		$baseUrlArr 	= $baseUrls['urls'];
		$baseUrl 		= $baseUrlArr['baseUrl'];
		$basePath 		= $baseUrlArr['basePath'];
		$userTable  	= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userInfoTable  = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		if(isset($_POST['u_email']) && $_POST['u_email']!=""){
			$email = $_POST['u_email'];
			$checkEmail = $userTable->checkEmail($email,'2');
			if($checkEmail > 0){
				return new JsonModel(array(					
					'output' 	=> 'emailexists',
				));
			}else{
				$Imgname = "";
				// if(isset($_FILES["file_data"]["name"]) && $_FILES["file_data"]["name"] != "")
				// {
					// $tmp = $_FILES["file_data"]["name"];
					// $Imgname = date('Ymd') ."_". date("His") .'.' . $tmp;
					// $newfilenamePath = "./public/uploads/".$Imgname;
					// if (move_uploaded_file($_FILES['file_data']["tmp_name"], $newfilenamePath)){
						// $Imgname = date('Ymd') ."_". date("His") .'.' . $tmp;
					// }
				// }			
				$addUserId	= $userTable->userReg($_POST);			
				if(isset($addUserId) && $addUserId != "")
				{
					$addUserInfo	= $userInfoTable->userRegInfo($_POST,$addUserId,$Imgname);
					
					global $regSubject;				
					global $regMessage;
					$u_name = $_POST['u_flname'];
					$to = $_POST['u_email'];
					$u_id  = base64_encode($addUserId);
					$url = $baseUrl.'/email-verified?uid='.$u_id;
					$regMessage = str_replace("<FULLNAME>","$u_name", $regMessage);
					$regMessage = str_replace("<REGLINK>",$baseUrl."email-verified?ev=emailverify-".$u_id, $regMessage);	
					sendMail($to,$regSubject,$regMessage);
					return new JsonModel(array(					
							'output'    	=>  'success'
					));
				}
				else
				{
					return new JsonModel(array(					
						'output' 	=> 'fail',
					));
				}
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'Server fail',
			));
		}
		
	}
	public function regAuthenticationAction(){
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$userTable  	= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userInfoTable  = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		if(isset($_GET['activeid']) && $_GET['activeid']!=""){
			$u_id = $_GET['activeid'];
			$getUDetails= $userTable->getDeactiveUserDetails($u_id);
			if(isset($getUDetails->u_id) && $getUDetails->u_id!=""){
				$activeu_id = $getUDetails->u_id;
				$updated = $userTable->updateuseraccount($u_id);
				if($updated){
					$updateduserinfo = $userInfoTable->updateUserRegAuth($u_id);
					return new JsonModel(array(					
						'output' => "activated"
					));
				}				
			}else{
				return new JsonModel(array(					
					'output' => "alreadyactivated"
				));
			}
		}else{
			return new JsonModel(array(					
				'output' => "server fail"
			));
		}
	}
	public function userLogoutAction(){
		$user_session 	= 	new Container('user');
		$baseUrls 		= $this->getServiceLocator()->get('config');
		$baseUrlArr 	= $baseUrls['urls'];
		$baseUrl 		= $baseUrlArr['baseUrl'];
		$basePath 		= $baseUrlArr['basePath'];
		session_destroy();
		return new JsonModel(array(					
			'output' => 1
		));
	}
	
	public function userFavouriteAction(){
				
		$user_session 	= new Container('user');
		$baseUrls 		= $this->getServiceLocator()->get('config');
		$baseUrlArr 	= $baseUrls['urls'];
		$baseUrl 		= $baseUrlArr['baseUrl'];
		$basePath 		= $baseUrlArr['basePath'];
		
		$userId 		= $_POST['userSessId'];
		$quoteId		= $_POST['quoteId'];
		$userTable 		= $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$quotesTable = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		if(isset($_POST) && $_POST != "")
		{
			$checkUserFav	= $userTable->checkFav($userId,$quoteId);			
			if($checkUserFav == 0){
				$addUserFav	    = $userTable->addFavorite($userId,$quoteId);				
				$countoffav     = $userTable->countEachQuote($quoteId);
				if($addUserFav != "")
				{
					$addQuoteData	= $quotesTable->quoteFavCount($countoffav,$quoteId);
					return new JsonModel(array(					
						'output' 	=> 'success',
						'favCount' 	=> $countoffav,
					));
				}
				else{
					return new JsonModel(array(					
						'output' 	=> 'fail',
					));
				}
			}
			else{
				$delUserFav	= $userTable->delFavorite($userId,$quoteId);
				$countoffav    = $userTable->countEachQuote($quoteId);
				if($delUserFav == 1)
				{
					$addQuoteData	= $quotesTable->quoteFavCount($countoffav,$quoteId);
					return new JsonModel(array(					
						'output' 	=> 'unfav',
						'favCount' 	=> $countoffav,
					));
				}
				else
				{
					return new JsonModel(array(					
						'output' 	=> 'error in unfav',
					));
				}
				
			}
		}
		else{
			return new JsonModel(array(					
				'output' 	=> 'server fail',
			));
		}
	}
	// views of quote
	public function userViewsAction(){
		$user_session 			= new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		
		$routes = $this->params()->fromRoute('id');		
		$idss = explode("category-",$routes);
		$ids = explode("-",$idss[1]);
		$categoriesTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$authorsTable = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$viewsTable   = $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$relatedTopics    = $categoriesTable->famousTopics();
		// Top Quotes View
		if((isset($ids['2']) && $ids['2'] == 'top') || (isset($ids['3']) && $ids['3'] == 'top')){
			
			$viewsList	= $quotesTable->quoteViewsList($ids,$hid_offset=null);				
			$ViewsListCount	= $quotesTable->quoteViewListCount();					
			if(isset($viewsList) && !is_null( $viewsList )){
				if(isset($ids['3']) && $ids['3'] == 'top'){
					$offset = $ids['2'];
					$route_offset = $offset;
				}else{
					$route_offset = $ids['3'];
				}
				$au_id = $viewsList['au_id'];	
				$qc_id = $viewsList['qc_id'];	
				$checkUserViews	= $viewsTable->checkQuoteViewsCount($ids,$qc_id);		
				if($checkUserViews['view_count'] > 0){
					$view_count = $checkUserViews['view_count']+1;
				}else{
					$view_count = 1;
				}
				$quoteViews	= $viewsTable->addQuoteViews($ids,$view_count,$qc_id);
				$getAuthorInfo    = $authorsTable->getAuthorData($au_id);
				$authorProfession = $getAuthorInfo->au_profession;
				$relatedAuthors   = $authorsTable->getRelatedAuthors($authorProfession);
				return new ViewModel(array(					
					'baseUrl' 			=>  $baseUrl,
					'basePath'  		=>  $basePath,
					'viewsList'  		=>  $viewsList,
					'routes'  		    =>  $ids,
					'ViewsListCount'  	=>  $ViewsListCount,
					'route_offset'      =>  $route_offset,
					'getAuthorInfo'  	=>  $getAuthorInfo,
					'relatedAuthors'  	=>  $relatedAuthors,
					'relatedTopics'  	=>  $relatedTopics,
				));
			}else{
				return new JsonModel(array(					
					'output' => 0
				));
			}			
		}else if((isset($ids['2']) && $ids['2'] == 'userquote') || (isset($ids['3']) && $ids['3'] == 'userquote')){
			$viewsList1	= $quotesTable->quoteViewOrderList($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$viewsList1['qc_id'];
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			$viewsList	= $quotesTable->quoteViewOrderList($ids);			
			$viewsListCount	= $quotesTable->quoteViewListCount($ids);
			$au_id = $viewsList['au_id'];	
			$qc_id = $viewsList['qc_id'];	
			$checkUserViews	= $viewsTable->checkQuoteViewsCount($addViewIds,$qc_id);		
			if($checkUserViews['view_count'] > 0){
				$view_count = $checkUserViews['view_count']+1;
			}else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addQuoteViews($addViewIds,$view_count,$qc_id);
			if(isset($ids['3']) && $ids['3'] == 'userquote'){
				$offset       = $ids['2'];
				$route_offset = $offset;
			}else{
				$route_offset = $ids['3'];
			}	
			$getAuthorInfo    = $authorsTable->getAuthorData($au_id);
			if(isset($getAuthorInfo->au_profession)){
				$authorProfession = $getAuthorInfo->au_profession;
				$relatedAuthors   = $authorsTable->getRelatedAuthors($authorProfession);	
			}else{
				$relatedAuthors = array();
			}
			return new ViewModel(array(					
				'baseUrl' 			=>  $baseUrl,
				'basePath'  		=>  $basePath,
				'viewsList'  	    =>  $viewsList,
				'route_offset'  	=>  $route_offset,				
				'routes'  			=>  $ids,				
				'ViewsListCount'  	=>  $viewsListCount,
				'getAuthorInfo'  	=>  $getAuthorInfo,
				'relatedAuthors'  	=>  $relatedAuthors,
				'relatedTopics'  	=>  $relatedTopics,
			));		
		}else if((isset($ids['2']) && $ids['2'] == 'short') || (isset($ids['3']) && $ids['3'] == 'short')){
			$viewsList1	= $quotesTable->quoteViewOrderList($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$viewsList1['qc_id'];
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			$limit = 1;
			if(isset($ids['3']) && $ids['3'] == 'short'){
				$offset = $ids['2'];
			}else{
				$offset = $ids['3'];
			}
			$qc_id = $ids['1'];
			$viewsList	= $quotesTable->shortOffQuotesSerach($ids,$qc_id,$offset);
			$ViewsListCount	= $quotesTable->quoteViewListCount($ids);
			$au_id = $viewsList['au_id'];	
			$qc_id = $viewsList['qc_id'];	
			$checkUserViews	= $viewsTable->checkQuoteViewsCount($addViewIds,$qc_id);		
			if($checkUserViews['view_count'] > 0){
				$view_count = $checkUserViews['view_count']+1;
			}else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addQuoteViews($addViewIds,$view_count,$qc_id);
			if(isset($ids['3']) && $ids['3'] == 'short'){
				$offset = $ids['2'];
				$route_offset = $offset;
			}else{
				$route_offset = $ids['3'];
			}	
			$getAuthorInfo    = $authorsTable->getAuthorData($au_id);
			$authorProfession = $getAuthorInfo->au_profession;
			$relatedAuthors   = $authorsTable->getRelatedAuthors($authorProfession);
			return new ViewModel(array(					
				'baseUrl' 						=>  $baseUrl,
				'basePath'  					=>  $basePath,
				'viewsList'  					=>  $viewsList,
				'route_offset'  				=>  $route_offset,				
				'routes'  						=>  $ids,				
				'ViewsListCount'  				=>  $ViewsListCount,
				'getAuthorInfo'  	=>  $getAuthorInfo,
				'relatedAuthors'  	=>  $relatedAuthors,
				'relatedTopics'  	=>  $relatedTopics,
			));
		}else if((isset($ids['2']) && $ids['2'] == 'auth') || (isset($ids['3']) && $ids['3'] == 'auth')){
			$viewsList1	= $quotesTable->quoteViewOrderList($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$viewsList1['qc_id'];
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			$viewsList	= $quotesTable->quoteViewOrderList($ids);			
			$viewsListCount	= $quotesTable->quoteViewListCount($ids);
			$au_id = $viewsList['au_id'];	
			$qc_id = $viewsList['qc_id'];	
			$checkUserViews	= $viewsTable->checkQuoteViewsCount($addViewIds,$qc_id);		
			if($checkUserViews['view_count'] > 0){
				$view_count = $checkUserViews['view_count']+1;
			}else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addQuoteViews($addViewIds,$view_count,$qc_id);
			if(isset($ids['3']) && $ids['3'] == 'auth'){
				$offset       = $ids['2'];
				$route_offset = $offset;
			}else{
				$route_offset = $ids['3'];
			}	
			$getAuthorInfo    = $authorsTable->getAuthorData($au_id);
			$authorProfession = $getAuthorInfo->au_profession;
			$relatedAuthors   = $authorsTable->getRelatedAuthors($authorProfession);	
			return new ViewModel(array(					
				'baseUrl' 			=>  $baseUrl,
				'basePath'  		=>  $basePath,
				'viewsList'  	    =>  $viewsList,
				'route_offset'  	=>  $route_offset,				
				'routes'  			=>  $ids,				
				'ViewsListCount'  	=>  $viewsListCount,
				'getAuthorInfo'  	=>  $getAuthorInfo,
				'relatedAuthors'  	=>  $relatedAuthors,
				'relatedTopics'  	=>  $relatedTopics,
			));
		}else if((isset($ids['2']) && $ids['2'] == 'cat') || (isset($ids['3']) && $ids['3'] == 'cat')){
			$viewsList1	= $quotesTable->quoteViewOrderList($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$viewsList1['qc_id'];
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			$viewsList	    = $quotesTable->categoryQuotesPre($ids);	
			$au_id = $viewsList['au_id'];
			$qc_id = $viewsList['qc_id'];	
			$viewsListCount	= $quotesTable->quoteViewListCount($ids);
			$checkUserViews	= $viewsTable->checkQuoteViewsCount($addViewIds,$qc_id);			
			if($checkUserViews['view_count'] > 0){
				$view_count = $checkUserViews['view_count']+1;
			}else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addQuoteViews($addViewIds,$view_count,$qc_id);
			if(isset($ids['3']) && $ids['3'] == 'cat'){
				$offset       = $ids['2'];
				$route_offset = $offset;
			}else{
				$route_offset =$ids['3'];
			}	
			// authors 
			$getAuthorInfo    = $authorsTable->getAuthorData($au_id);
			$authorProfession = $getAuthorInfo->au_profession;
			$relatedAuthors   = $authorsTable->getRelatedAuthors($authorProfession);			
			return new ViewModel(array(					
				'baseUrl' 			=>  $baseUrl,
				'basePath'  		=>  $basePath,
				'viewsList'  	    =>  $viewsList,
				'route_offset'  	=>  $route_offset,				
				'routes'  			=>  $ids,				
				'ViewsListCount'  	=>  $viewsListCount,
				'getAuthorInfo'  	=>  $getAuthorInfo,
				'relatedAuthors'  	=>  $relatedAuthors,
				'relatedTopics'  	=>  $relatedTopics,
			));
		}else if((isset($ids['2']) && $ids['2'] == 'fav') || (isset($ids['3']) && $ids['3'] == 'fav')){
			$viewsList1	= $quotesTable->quoteViewOrderList($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$viewsList1['qc_id'];
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			$viewsList	= $quotesTable->quoteViewOrderList($ids);
			$ViewsListCount	= $quotesTable->quoteViewListCount($ids);		
			if(isset($ids['3']) && $ids['3'] == 'fav'){
				$offset = $ids['2'];
				$route_offset = $offset;
			}else{
				$route_offset = $ids['3'];
			}	
			$au_id = $viewsList['au_id'];	
			$qc_id = $viewsList['qc_id'];	
			$viewsListCount	= $quotesTable->quoteViewListCount($ids);
			$checkUserViews	= $viewsTable->checkQuoteViewsCount($addViewIds,$qc_id);			
			if($checkUserViews['view_count'] > 0){
				$view_count = $checkUserViews['view_count']+1;
			}else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addQuoteViews($addViewIds,$view_count,$qc_id);
			$getAuthorInfo    = $authorsTable->getAuthorData($au_id);
			$authorProfession = $getAuthorInfo->au_profession;
			$relatedAuthors   = $authorsTable->getRelatedAuthors($authorProfession);
			return new ViewModel(array(					
				'baseUrl' 						=>  $baseUrl,
				'basePath'  					=>  $basePath,
				'viewsList'  					=>  $viewsList,
				'route_offset'  				=>  $route_offset,				
				'ViewsListCount'  				=>  $ViewsListCount,
				'routes'						=>  $ids,
				'getAuthorInfo'  	=>  $getAuthorInfo,
				'relatedAuthors'  	=>  $relatedAuthors,
				'relatedTopics'  	=>  $relatedTopics,
			));
		}
	}	
	public function allcategoryQuotesAction(){
		$ids = "";
		$user_session 			= 	new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$routes 				= $this->params()->fromRoute('id');		
		$ids 					= explode("-category",$routes);
		$viewsTable  			= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  			= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable  = $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   	= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		// $famousCategoriesList 	= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 		= $famousAuthorsTable->famousAuthors($flag=1);
		if(isset($ids[0]) && $ids[0]!=""){
			$catn = str_replace('-', ' ', $ids[0]);
			$catName = ucfirst($catn);
			$getCateDetails = $famousCategoriesTable->getCategoryId($catName);			
			if(isset($getCateDetails['qc_cat_id']) && $getCateDetails['qc_cat_id']!=""){
				$qc_cat_id = $getCateDetails['qc_cat_id'];
			}else{
				$qc_cat_id = 0;
			}			
		}else{
			$qc_cat_id = 0;
		}
		$ids[1] = "category"; 
		$categoryQtList			= $quotesTable->categoryWiseQtList($ids,$qc_cat_id);
		$pageCount  			= 10;		
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 			= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 			= $qDay->qc_name;
				$categoryQt[$q]['qc_image']			= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']			= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$categoryQt[$q]['fav']				= $qDay->fav;				
				$categoryQt[$q]['viewCounnt']		= $qDay->viewCounnt;
				$categoryQt[$q]['au_id']			= $qDay->au_id;
				$categoryQt[$q]['au_fname']			= $qDay->au_fname;
				$categoryQt[$q]['au_lname']			= $qDay->au_lname;
				$categoryQt[$q]['au_pic']			= $qDay->au_pic;
				$categoryQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$categoryQt[$q]['qc_au_id']			= $qDay->qc_au_id;
				$categoryQt[$q]['qc_cat_name']		= $qDay->qc_cat_name;
				
			}
		}		
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,
			'categoryQtList'  						=>  $categoryQtList,
			// 'famousCategoriesList'  				=>  $famousCategoriesList,
			// 'famousAuthorsList'  					=>  $famousAuthorsList,
			'categoryQt'  							=>  $categoryQt,
			'paginationcategory'  					=>  $categoryQtList,
			'pageCount' 							=>  $pageCount,
			'urlCateName' 							=>  $catName,
			'qc_cat_id' 							=>  $qc_cat_id,
		
		));
	}
	
	public function categoryAction(){
		$ids = "";
		$user_session 			= 	new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$routes 				= $this->params()->fromRoute('id');		
		$ids 					= explode("-category",$routes);
		$viewsTable  			= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  			= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable  = $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   	= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		// $famousCategoriesList 	= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 		= $famousAuthorsTable->famousAuthors($flag=1);
		if(isset($routes) && $routes!=""){
			$ids[0] = $routes;
			$catn = str_replace('-', ' ', $routes);
			$catName = ucfirst($catn);
			$getCateDetails = $famousCategoriesTable->getCategoryId($catName);			
			if(isset($getCateDetails['qc_cat_id']) && $getCateDetails['qc_cat_id']!=""){
				$qc_cat_id = $getCateDetails['qc_cat_id'];
			}else{
				$qc_cat_id = 0;
			}			
		}else{
			$qc_cat_id = 0;
		}
		$ids[1] = "category"; 
		$categoryQtList			= $quotesTable->categoryWiseQtList($ids,$qc_cat_id);
		$pageCount  			= 10;		
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$totalCount = $categoryQtList->getTotalItemCount();
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 			= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 			= $qDay->qc_name;
				$categoryQt[$q]['qc_image']			= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']			= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$categoryQt[$q]['fav']				= $qDay->qc_fav_count;	
				if(isset($qDay->viewCounnt) && $qDay->viewCounnt!=""){
					$viewCount = $qDay->viewCounnt;
				}else{
					$viewCount = '';
				}
				$categoryQt[$q]['viewCounnt']		= $viewCount;
				$categoryQt[$q]['au_id']			= $qDay->au_id;
				$categoryQt[$q]['au_fname']			= $qDay->au_fname;
				$categoryQt[$q]['au_lname']			= $qDay->au_lname;
				$categoryQt[$q]['au_pic']			= $qDay->au_pic;
				$categoryQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$categoryQt[$q]['qc_au_id']			= $qDay->qc_au_id;
				$categoryQt[$q]['qc_cat_name']		= $qDay->qc_cat_name;
				
			}
		}		
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,
			'categoryQtList'  						=>  $categoryQtList,
			// 'famousCategoriesList'  				=>  $famousCategoriesList,
			// 'famousAuthorsList'  					=>  $famousAuthorsList,
			'categoryQt'  							=>  $categoryQt,
			'paginationcategory'  					=>  $categoryQtList,
			'pageCount' 							=>  $pageCount,
			'urlCateName' 							=>  $catName,
			'id'                                    =>  $routes,
			'catQuotesCnt'                          =>  $totalCount
		));
	}
	
	public function allauthorQuotesAction(){
		$user_session 				= 	new Container('user');
		$ids = "";
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$routes 					= $this->params()->fromRoute('id');		
		$ids 						= explode("-author",$routes);
		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		
		if(isset($ids[0]) && $ids[0]!=""){
			$catn = str_replace('-', ' ', $ids[0]);
			$authorName = ucfirst($catn);
			$getAuthorDetails = $famousAuthorsTable->getAuthorId($authorName);		
			if(isset($getAuthorDetails['au_id']) && $getAuthorDetails['au_id']!=""){
				$au_id = $getAuthorDetails['au_id'];
			}else{
				$au_id = 0;
			}
			$ids[1] = 'author';
		}else{
			$au_id = 0;
		}
		$categoryQtList				= $quotesTable->categoryWiseQtList($ids,$au_id);
		// $famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);
		$pageCount  				= 10;		
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 			= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 			= $qDay->qc_name;
				$categoryQt[$q]['qc_image']			= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']			= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$categoryQt[$q]['fav']				= $qDay->fav;				
				$categoryQt[$q]['viewCounnt']		= $qDay->viewCounnt;
				$categoryQt[$q]['au_id']			= $qDay->au_id;
				$categoryQt[$q]['au_fname']			= $qDay->au_fname;
				$categoryQt[$q]['au_lname']			= $qDay->au_lname;
				$categoryQt[$q]['au_pic']			= $qDay->au_pic;
				$categoryQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$categoryQt[$q]['qc_au_id']			= $qDay->qc_au_id;
				$categoryQt[$q]['qc_cat_name']		= $qDay->qc_cat_name;
				
			}
		}
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,			
			// 'famousCategoriesList'  				=>  $famousCategoriesList,
			// 'famousAuthorsList'  					=>  $famousAuthorsList,
			'categoryQt'  							=>  $categoryQt,
			'paginationcategory'  					=>  $categoryQtList,
			'pageCount' 							=>  $pageCount,		
		));
	}
	
	public function authorAction(){
		$user_session 				= 	new Container('user');
		$ids = "";
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$ids ="";
		$routes 					= $this->params()->fromRoute('id');		
		 //$ids 						= explode("-author",$routes);
		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		
		if(isset($routes) && $routes!=""){
			$catn = str_replace('-', ' ', $routes);
			$authorName = ucfirst($catn);
			$getAuthorDetails = $famousAuthorsTable->getAuthorId($authorName);		
			if(isset($getAuthorDetails['au_id']) && $getAuthorDetails['au_id']!=""){
				$au_id = $getAuthorDetails['au_id'];
			}else{
				$au_id = 0;
			}
			$ids[0] = $routes;
			$ids[1] = 'author';
		}else{
			$au_id = 0;
		}
		$categoryQtList				= $quotesTable->categoryWiseQtList($ids,$au_id);
		// $famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);
		$pageCount  				= 10;		
		$categoryQtList->setCurrentPageNumber(1);
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$totalCount = $categoryQtList->getTotalItemCount();
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 			= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 			= $qDay->qc_name;
				$categoryQt[$q]['qc_image']			= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']			= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$categoryQt[$q]['fav']				= $qDay->qc_fav_count;				
				if(isset($qDay->viewCounnt) && $qDay->viewCounnt!=""){
					$viewCount = $qDay->viewCounnt;
				}else{
					$viewCount = '';
				}
				$categoryQt[$q]['viewCounnt']		= $viewCount;
				$categoryQt[$q]['au_id']			= $qDay->au_id;
				$categoryQt[$q]['au_fname']			= $qDay->au_fname;
				$categoryQt[$q]['au_lname']			= $qDay->au_lname;
				$categoryQt[$q]['au_pic']			= $qDay->au_pic;
				$categoryQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$categoryQt[$q]['qc_au_id']			= $qDay->qc_au_id;
				$categoryQt[$q]['qc_cat_name']		= $qDay->qc_cat_name;
				
			}
		}
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,			
			// 'famousCategoriesList'  				=>  $famousCategoriesList,
			// 'famousAuthorsList'  					=>  $famousAuthorsList,
			'categoryQt'  							=>  $categoryQt,
			'paginationcategory'  					=>  $categoryQtList,
			'pageCount' 							=>  $pageCount,	
			'id'                                    =>  $routes,
			'catQuotesCnt'                          =>  $totalCount
		));
	}
	public function authorQuotesAjaxAction(){
		$user_session 				= 	new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$page      = $_POST['publicBoxesOffset'];
		$pageCount = $_POST['publicBoxesPerPage'];
		if(isset($_POST['pageMode']) && $_POST['pageMode']=="author"){
			$au_id     = $_POST['hid_main_id'];
			$auotesList = $quotesTable->authorQuotesBypage($au_id,$pageCount,$page)->toArray();		
		}else if(isset($_POST['pageMode']) && $_POST['pageMode']=="category"){
			$cat_id    = $_POST['hid_main_id'];
			$auotesList = $quotesTable->categoryQuotesBypage($cat_id,$pageCount,$page)->toArray();		
		}else if(isset($_POST['pageMode']) && $_POST['pageMode']=="short"){
			$auotesList = $quotesTable->shortOffQuotes($pageCount,$page)->toArray();		
		}else if(isset($_POST['pageMode']) && $_POST['pageMode']=="topquotes"){
			$auotesList = $quotesTable->allQuotesDescFavLoad($pageCount,$page)->toArray();		
		}		
		$view = new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,			
			'categoryQt'  							=>  $auotesList,
			'cnt'  							=>  count($auotesList),
		));
		return $view->setTerminal(true);		
	}
	public function getUserFavorate($uid,$qc_id){
		$userIsfav = 0;
		$countfavorites    = $this->getUserFavTable()->checkFav($uid,$qc_id);
		$countofviews     = 0;
		if($countfavorites>0){
			$userIsfav =1;
		}else{
			$userIsfav =0;
		}
		return $userIsfav;
	}
	public function countEachQuote($qc_id){
		$userIsfav = 0;
		$favoritesTable    = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$favCount    = $favoritesTable->countEachQuote($qc_id);
		$eachQuoteCount      = 0;
		if($favCount>0){
			$eachQuoteCount =$favCount;
		}else{
			$eachQuoteCount =0;
		}
		return $eachQuoteCount;
	}
	
	public function allQuotesListAction(){
		$user_session 				= 	new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$routes 					= $this->params()->fromRoute('id');		
		$ids 						= explode("topquotes-",$routes);
		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		// $famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);
		$categoryQtList				= $quotesTable->allQuotesDescFav($ids,$resId='');		
		$pageCount 					= 10;		
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 			= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 			= $qDay->qc_name;
				$categoryQt[$q]['qc_image']			= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']			= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$categoryQt[$q]['fav']				= $qDay->fav;				
				$categoryQt[$q]['viewCounnt']		= $qDay->view_count;
				$categoryQt[$q]['au_id']			= $qDay->au_id;
				$categoryQt[$q]['au_fname']			= $qDay->au_fname;
				$categoryQt[$q]['au_lname']			= $qDay->au_lname;
				$categoryQt[$q]['au_pic']			= $qDay->au_pic;
				$categoryQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$categoryQt[$q]['qc_cat_name']		= $qDay->qc_cat_name;
				
			}
		}		
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,			
			// 'famousCategoriesList'  				=>  $famousCategoriesList,
			// 'famousAuthorsList'  					=>  $famousAuthorsList,
			'categoryQt'  							=>  $categoryQt,
			'paginationcategory'  					=>  $categoryQtList,
			'pageCount' 							=>  $pageCount,		
		));
	}
	public function topQuotesAction(){
		$user_session 				= 	new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];

		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		// $famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);
		$categoryQtList				= $quotesTable->allQuotesDescFav($ids='',$resId='');		
		$pageCount 					= 10;		
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$totalCount = $categoryQtList->getTotalItemCount();
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 			= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 			= $qDay->qc_name;
				$categoryQt[$q]['qc_image']			= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']			= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']	= $qDay->qc_created_at;
				$categoryQt[$q]['fav']				= $qDay->qc_fav_count;				
				$categoryQt[$q]['viewCounnt']		= $qDay->view_count;
				$categoryQt[$q]['au_id']			= $qDay->au_id;
				$categoryQt[$q]['au_fname']			= $qDay->au_fname;
				$categoryQt[$q]['au_lname']			= $qDay->au_lname;
				$categoryQt[$q]['au_pic']			= $qDay->au_pic;
				$categoryQt[$q]['qc_cat_id']		= $qDay->qc_cat_id;
				$categoryQt[$q]['qc_cat_name']		= $qDay->qc_cat_name;
				
			}
		}		
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,			
			// 'famousCategoriesList'  				=>  $famousCategoriesList,
			// 'famousAuthorsList'  					=>  $famousAuthorsList,
			'categoryQt'  							=>  $categoryQt,
			'paginationcategory'  					=>  $categoryQtList,
			'pageCount' 							=>  $pageCount,		
			'catQuotesCnt' 							=>  $totalCount,		
		));
	}
	
	public function shortQuotesListAction(){
		$user_session 				= 	new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr		 			= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$routes 					= $this->params()->fromRoute('id');		
		$ids 						= explode("-",$routes);
		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		// $famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		// $famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);
		$categoryQtList				= $quotesTable->shortFullQuotesList($ids,$regId=null);		
		$pageCount  				= 10;	
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$categoryQt[$q]['qc_id'] 				= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 				= $qDay->qc_name;
				$categoryQt[$q]['qc_image']				= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']				= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']		= $qDay->qc_created_at;
				$categoryQt[$q]['fav']					= $qDay->fav;				
				$categoryQt[$q]['viewCounnt']			= $qDay->viewCounnt;
				$categoryQt[$q]['au_id']				= $qDay->au_id;
				$categoryQt[$q]['au_fname']				= $qDay->au_fname;
				$categoryQt[$q]['au_lname']				= $qDay->au_lname;
				$categoryQt[$q]['au_pic']				= $qDay->au_pic;
				// $categoryQt[$q]['qc_cat_id']			= $qDay->qc_cat_id;
				// $categoryQt[$q]['qc_cat_name']			= $qDay->qc_cat_name;
				
			}
		}
		
		return new ViewModel(array(					
			'baseUrl' 									=>  $baseUrl,
			'basePath'  								=>  $basePath,			
			// 'famousCategoriesList'  					=>  $famousCategoriesList,
			// 'famousAuthorsList'  						=>  $famousAuthorsList,
			'categoryQt'  								=>  $categoryQt,
			'paginationcategory'  						=>  $categoryQtList,
			'pageCount' 								=>  $pageCount,	
		
		));
	}
	
	public function shortQuotesAction(){
		$user_session 				= 	new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr		 			= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$viewsTable  				= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');		
		$categoryQtList				= $quotesTable->shortFullQuotesList($ids=null,$regId=null);	
		$pageCount  				= 10;	
		$categoryQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$categoryQtList->setItemCountPerPage($pageCount);	
		$categoryQtList->setPageRange(5);
		$totalCount = $categoryQtList->getTotalItemCount();
		$categoryQt = array();		
		if(count($categoryQtList))
		{
			foreach($categoryQtList as $q=>$qDay)
			{
				$viewCount = $this->getQuotesViewCount($qDay->qc_id);
				$categoryQt[$q]['qc_id'] 				= $qDay->qc_id;
				$categoryQt[$q]['qc_name'] 				= $qDay->qc_name;
				$categoryQt[$q]['qc_image']				= $qDay->qc_image;
				$categoryQt[$q]['qc_tags']				= $qDay->qc_tags;
				$categoryQt[$q]['qc_created_at']		= $qDay->qc_created_at;
				$categoryQt[$q]['fav']					= $qDay->qc_fav_count;				
				$categoryQt[$q]['viewCounnt']			= $viewCount;
				$categoryQt[$q]['au_id']				= $qDay->au_id;
				$categoryQt[$q]['au_fname']				= $qDay->au_fname;
				$categoryQt[$q]['au_lname']				= $qDay->au_lname;
				$categoryQt[$q]['au_pic']				= $qDay->au_pic;
			}
		}
		
		return new ViewModel(array(					
			'baseUrl' 									=>  $baseUrl,
			'basePath'  								=>  $basePath,			
			//'famousCategoriesList'  					=>  $famousCategoriesList,
			//'famousAuthorsList'  						=>  $famousAuthorsList,
			'categoryQt'  								=>  $categoryQt,
			'paginationcategory'  						=>  $categoryQtList,
			'pageCount' 								=>  $pageCount,	
			'catQuotesCnt' 								=>  $totalCount,	
		
		));
	}
	public function serachQuoteAjaxAction(){
		$user_session 			= 	new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$searchedTerm 			= "";
		$searchedTerm = $_POST['hid_main_id'];
		$page      = $_POST['publicBoxesOffset'];
		$pageCount = $_POST['publicBoxesPerPage'];
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$quoteCategoriesTable       = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');		
		$searchedQtList	= $quotesTable->serachQuoteAjax($searchedTerm,$pageCount,$page)->toArray();
		$view = new ViewModel(array(					
			'baseUrl' 					=>  $baseUrl,
			'basePath'  				=>  $basePath,		
			'searchQtList'  			=>  $searchedQtList,
			'cnt'  					    =>  count($searchedQtList),
		));
		return $view->setTerminal(true);
	}
	
	public function searchQuoteAction()
	{
		$user_session 			= 	new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$searchedTerm 			= "";
		if(isset($_POST['QtSearch']) && $_POST['QtSearch'] != ""){
			$searchedTerm = $_POST['QtSearch'];
			$serachTerm    = str_replace('+', ' ', $searchedTerm);
			$serachTerm    = str_replace("'", '%20', $serachTerm);
			$searchedTerm  = $serachTerm;
		}else{
			$routes = $this->params()->fromRoute('id');
			$serachTerm    = str_replace('+', ' ', $routes);
			$serachTerm    = str_replace("'", '%20', $serachTerm);
			$searchedTerm  = $serachTerm;			
		}
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$quoteCategoriesTable       = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		//$famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		//$famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);		
		$searchedQtList				= $quotesTable->searchQtList($searchedTerm);
		$pageCount  				= 10;		
		$searchedQtList->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$searchedQtList->setItemCountPerPage($pageCount);	
		$searchedQtList->setPageRange(5);
		$totalCount = $searchedQtList->getTotalItemCount();
		$searchQtList = array();
		
		if(count($searchedQtList))
		{
			foreach($searchedQtList as $q=>$qDay)
			{
				$categoires  = $quoteCategoriesTable->getCategories($qDay->qc_id);
				$cat = "";
				$cat_names = ""; 				
				$searchQtList[$q]['qc_id'] 				= $qDay->qc_id;
				$searchQtList[$q]['qc_name'] 			= $qDay->qc_name;
				$searchQtList[$q]['qc_image']			= $qDay->qc_image;
				$searchQtList[$q]['qc_tags']			= $qDay->qc_tags;
				$searchQtList[$q]['qc_created_at']		= $qDay->qc_created_at;
				$searchQtList[$q]['fav']				= $qDay->fav;				
				$searchQtList[$q]['viewCounnt']			= $qDay->view_count;
				$searchQtList[$q]['au_id']				= $qDay->au_id;
				$searchQtList[$q]['au_fname']			= $qDay->au_fname;
				$searchQtList[$q]['au_lname']			= $qDay->au_lname;
				$searchQtList[$q]['au_pic']				= $qDay->au_pic;
				$searchQtList[$q]['qc_cat_id']			= $qDay->qc_cat_id;
				foreach($categoires as $key=>$cat){
					$cat_names .= ucfirst($cat['qc_cat_name'].', ');
					$cat = rtrim($cat_names, ', ');
					$searchQtList[$q]['keywords'] = $cat;
				}
			}
		}
		return new ViewModel(array(					
			'baseUrl' 									=>  $baseUrl,
			'basePath'  								=>  $basePath,		
			'searchQtList'  							=>  $searchQtList,
			'paginationqtList'  						=>  $searchedQtList,
			'searchedTerm'  							=>  $searchedTerm,
			'pageCount' 								=>  $pageCount,
			'catQuotesCnt' 								=>  $totalCount,
			//'famousCategoriesList'  					=>  $famousCategoriesList,
			//'famousAuthorsList'  						=>  $famousAuthorsList,
		
		));
	}
	
	public function viewSearchAction()
	{
		$ids ="";
		$routes = $this->params()->fromRoute('id');		
		$idss = explode("category-",$routes);
		$ids = explode("-",$idss[1]);
		$user_session 			= 	new Container('user');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$searchedQtList 		= array();
		
		$quotesTable  				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$quoteCategoriesTable       = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$viewsTable  			= $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		if(isset($ids['2']) && $ids['2']=="search"){
			$ids['2'] = "Search";
			$searchedQtList1			= $quotesTable->searchQuoteView($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$searchedQtList1->qc_id;
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			
			$checkUserViews	= $viewsTable->checkViews($addViewIds);		
			if($checkUserViews['view_count'] > 0)
			{
				$view_count = $checkUserViews['view_count']+1;
			}
			else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addViews($addViewIds,$view_count);		
			if($quoteViews != 0 || !is_null($quoteViews))
			{	
				$searchedQtList				 = $quotesTable->searchQuoteView($ids);
				$ViewsListCount	= $quotesTable->searchQtListCount($ids['1']);		
				$offset = $ids['3'];
				$route_offset = $offset;	
				return new ViewModel(array(					
					'baseUrl' 							=>  $baseUrl,
					'basePath'  						=>  $basePath,		
					'viewsList'  					    =>  $searchedQtList,
					'route_offset'  					=>  $route_offset,				
					'routes'  							=>  $ids,	
					'ViewsListCount'  					=>  $ViewsListCount,	
				));
			}else{
				return new JsonModel(array(					
				'output' => 0
				));
			}
		}else{
			$searchedQtList1	 = $quotesTable->searchQuoteViewList($ids);
			$addViewIds['0']=$ids['0'];
			$addViewIds['1']=$searchedQtList1->qc_id;
			$addViewIds['2']=$ids['2'];
			$addViewIds['3']=$ids['3'];
			
			$checkUserViews	= $viewsTable->checkViews($addViewIds);	
			if($checkUserViews['view_count'] > 0)
			{
				$view_count = $checkUserViews['view_count']+1;
			}
			else{
				$view_count = 1;
			}
			$quoteViews	= $viewsTable->addViews($addViewIds,$view_count);		
			if($quoteViews != 0 || !is_null($quoteViews))
			{	
				$searchedQtList				 = $quotesTable->searchQuoteViewList($ids);
				$ViewsListCount	             = $quotesTable->searchQtListCount($ids['1']);
				return new ViewModel(array(					
					'baseUrl' 							=>  $baseUrl,
					'basePath'  						=>  $basePath,		
					'viewsList'  					    =>  $searchedQtList,
					'ViewsListCount'  				    =>  $ViewsListCount,
					'route_offset'  					=>  0,	
					'routes'  		    			    =>  $ids,
				));
			}else{
				return new JsonModel(array(					
				'output' => 0
				));
			}
		}
	}
	// update profile
	public function updateUserProfileAction()
	{
		$userId = "";
		if(isset($_POST) && $_POST != "")
		{
			$userId = $_POST['userId'];
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$userTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userType 						= 2;		
		$getUserDetails					= $userTable->userData($userId,$userType);	
			
		if($getUserDetails != ""){			
			$user_session->userId		=	$getUserDetails->u_id;
			$user_session->email		=	$getUserDetails->u_email;
			$user_session->displayName	=	ucwords(strtolower($getUserDetails->u_display_name));
			$user_session->userType	    =	$getUserDetails->u_ut_id;
			return new JsonModel(array(					
				'output'    			=>  'sucess',
				'getUserDetails'    	=>  $getUserDetails
			));
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}		
	}
	
	public function updateUserProfileAjaxAction()
	{
		
		$loggedInId = "";
		$userType = 2;
		if(isset($_POST['hiddenUid']) && $_POST['hiddenUid'] != "")
		{
			$loggedInId = $_POST['hiddenUid'];
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$userTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userInfoTable  				= $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		$authorTable                    = $this->getServiceLocator()->get('Models\Model\AuthorFactory');

		$userType 						= 2;		
				
		if(isset($_POST) && $_POST !="")
		{
			$Imgname = "";
			// if(isset($_FILES["file_data"]["name"]) && $_FILES["file_data"]["name"] != "")
			// {
				// $tmp = $_FILES["file_data"]["name"];
				// $Imgname = date('Ymd') ."_". date("His") .'.' . $tmp;
				// $newfilenamePath = "./public/uploads/".$Imgname;
				// if (move_uploaded_file($_FILES['file_data']["tmp_name"], $newfilenamePath)){
					// $Imgname = date('Ymd') ."_". date("His") .'.' . $tmp;
				// }
			// }
			// else{
				$Imgname = $_POST['userImg'];
			// }
		
			$updatedId	= $userTable->userProfileUpdate($_POST);			
				if(isset($updatedId) && $updatedId != "")
				{
					$getUserData = "";
					$updateUserInfo	= $userInfoTable->userProfileInfo($_POST,$Imgname);
					if(isset($updateUserInfo) && $updateUserInfo != "")
					{
						$getUserData			= $userTable->userData($loggedInId,$userType);
						$checkAuthor            = $authorTable->checkAuthor($loggedInId);
						if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
							$qc_au_id = $checkAuthor->au_id;
							$addedAuthor = $authorTable->updateUserAuthorDescription($_POST['u_textArea'],$qc_au_id);
						}
					}
					return new JsonModel(array(					
							'output'    	=>  'success',
							'details'    	=>  $getUserData
					));
				}
				else
				{
					return new JsonModel(array(					
						'output' 	=> 'fail',
					));
				}		
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'Server fail',
			));
		}	
	}
	
	// check password
	public function checkPasswordAction()
	{
		
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$userTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userType 						= 2;		
		$checkPassword					= $userTable->checkUserPass($_POST);
		if(isset($checkPassword) &&  $checkPassword != "" )
		{
			$uid = $checkPassword['u_id'];
			return new JsonModel(array(					
			'output'    	=>  'sucess',
			'user_id'    	=>  $uid
			));
		}
		else
		{
			$uid = 0;
			return new JsonModel(array(					
				'output' 	=> 'fail',
				'user_id'    	=>  $uid
			));
		}	
			
	}
	// update password
	public function updatePasswordAction()
	{
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$userTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userType 						= 2;		
		$updatePassword					= $userTable->updateUserPass($_POST);
		
		if(isset($updatePassword) &&  $updatePassword != "" )
		{
			return new JsonModel(array(					
			'output'    	=>  'sucess'
			
			));
		}
		else
		{
			$uid = 0;
			return new JsonModel(array(					
				'output' 	=> 'fail',
				'user_id'    	=>  $uid
			));
		}	
			
	}
	function getUniqueCode($length = "")
	{
		$code = md5(uniqid(rand(), true));
		if ($length != "")
		return substr($code, 0, $length);
		else
		return $code;
	}
	public function checkForgotEmailAction()
	{
		$email = "";
		if(isset($_POST['email']) && $_POST['email']!= "")
		{
			$email = $_POST['email'];
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$forgotTable  					= $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');			
		$usersTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');			
		$forgotEmailArr					= $usersTable->checkForgotMail($email);	
		
		if($forgotEmailArr != "")
		{
			$token = getUniqueCode('10');
			$user_id = $forgotEmailArr['u_id'];
			$checkUserId				= $forgotTable->checkForgotMail($user_id);			
			if(isset($checkUserId['ft_u_id']) && $checkUserId['ft_u_id'] != "" && $checkUserId['ft_u_id'] != 0)
			{
				$uid 			= $checkUserId['ft_u_id'];				
				$updateToken	= $forgotTable->updateForgetpwd($uid,$token);
			}
			else
			{
				$updateToken 		= $forgotTable->addForgetpwd($user_id,$token);
			}
			if(isset($updateToken) && $updateToken != "")
			{
				$to=$forgotEmailArr['u_email'];
				$userName=ucfirst($forgotEmailArr['u_display_name']);
				$user_session = new Container('user');
				$user_session->username=$forgotEmailArr['u_display_name'];
				$user_session->email=$forgotEmailArr['u_email'];
				$user_session->user_id=$forgotEmailArr['u_id'];				
				global $ForgotPassowrdSubject;				
				global $ForgotPasswordMessage;				
				$ForgotPasswordMessage = str_replace("<FULLNAME>",$userName, $ForgotPasswordMessage);
				$ForgotPasswordMessage = str_replace("<PASSWORDLINK>",$baseUrl.'email-reset-pwd?uid='.$user_id.'&token='.$token.'&reset=1', $ForgotPasswordMessage);
				if(sendMail($to,$ForgotPassowrdSubject,$ForgotPasswordMessage)){
					return new JsonModel(array(					
						'output' 	=> 'success'
					));
				}
				else{
					return new JsonModel(array(					
						'output' 	=> 'fail'
					));
				}
				
			}
						
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'check email',				
			));
		}
			
	}
	// Update password for forget password
	public function resetPasswordAction()
	{
		$uid = "";$password = "";
		if(isset($_POST['f_UserId']) && $_POST['f_UserId']!= "")
		{
			$uid 						= $_POST['f_UserId'];
			$password 					= $_POST['f_confirmPass'];
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$forgotTable  					= $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');			
		$usersTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');			
		$delToken						= $forgotTable->deletetoken($uid);		
		if($delToken != 0)
		{
			$updateFgtPass				= $usersTable->updtFgtPass($uid,$password);			
			if($updateFgtPass != "")
			{
				return new JsonModel(array(					
				'output'    	=>  'sucess',				
				));
			}
			else
			{
				return new JsonModel(array(					
				'output'    	=>  'fail',				
				));
			}
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'fail deletion',				
			));
		}	
				
	}
	
	public function checkFgtUidAction()
	{
		$uid = "";$token = "";
		if(isset($_POST['uid']) && $_POST['uid']!= "")
		{
			$uid 						= $_POST['uid'];			
			$token 						= $_POST['token'];			
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$forgotTable  					= $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');			
		$usersTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');			
		$checkFuid						= $forgotTable->checktoken($uid,$token);		
		if(!empty($checkFuid) && !is_null($checkFuid))
		{
			return new JsonModel(array(					
				'output' 	=> 'sucess',				
			));
		}
		else{
			return new JsonModel(array(					
				'output' 	=> 'fail',				
			));
		}
	}
	
	public function deleteUserQuoteAction()
	{
		$qc_id = "";
		if(isset($_POST) && $_POST != "")
		{
			$qc_id 						= $_POST['qc_id'];			
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$quotesTable   				    = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable           = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');

		$delQuote						= $quotesTable->delQuote($qc_id);
		$quoteCategories			    = $quoteCategoriesTable->deleteQuoteCategories($qc_id);
		if($delQuote)
		{
			return new JsonModel(array(					
				'output' 	=> 'success',				
			));
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',				
			));
		}
		
			
	}
	
		public function uploadProfileImageAction(){
		
			$fileExtentios     = explode(".", $_FILES["fileCropInp"]["name"]);
			$extention         = strtolower(end($fileExtentios));
			switch($extention){
				case 'jpg' :case 'jpeg': case 'jpe': case 'png': case 'gif':
				if(isset($_FILES) && isset($_FILES['fileCropInp']['name'])){
					@unlink('./public/uploads/'.$_POST['userImg']);
					$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
					$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
					$croppedX 			= 	$_POST['croppedX'];
					$croppedY 			= 	$_POST['croppedY'];
					$image 				= 	stripslashes($_FILES['fileCropInp']['name']);
					$temp 				= 	explode(".", $_FILES["fileCropInp"]["name"]);
					$extension 			= 	strtolower(end($temp));
					$uploadedfile		=	$_FILES['fileCropInp']['tmp_name'];
					
					if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
						$src = imagecreatefromjpeg($uploadedfile);
					}
					else if($extension=="png"){
						$src = imagecreatefrompng($uploadedfile);
					}
					else{
						$src = imagecreatefromgif($uploadedfile);
					}
					
					list($width,$height)	=	getimagesize($uploadedfile);
					$tmp					=	imagecreatetruecolor(200,200);
					imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,200,200,$croppedNewWidth,$croppedNewHeight);
					
					$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
					$newfilenamePath = "./public/uploads/".$imageName;
					imagejpeg($tmp,$newfilenamePath,100);
					imagedestroy($tmp);
					imagedestroy($src);
					
					escape_str($imageName);
					return $view = new JsonModel(array(
						'output'  		=> 1,
						'imageName' 	=> $imageName
					));
					}
				break;
				default:
				return $view = new JsonModel(array(
					'output'          => 0,
					'message'          => 'The given extension is not allowed.',
				));
				break;
			}
		}
		
		public function uploadQuoteImageAction(){
			$fileExtentios     = explode(".", $_FILES["QuoteFileCropInp"]["name"]);
			$extention         = strtolower(end($fileExtentios));
			switch($extention){
				case 'jpg' :case 'jpeg': case 'jpe': case 'png': case 'gif':
				if(isset($_FILES) && isset($_FILES['QuoteFileCropInp']['name'])){
					@unlink('./public/quotes/'.$_POST['quotePic']);
					$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
					$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
					$croppedX 			= 	$_POST['croppedX'];
					$croppedY 			= 	$_POST['croppedY'];
					$image 				= 	stripslashes($_FILES['QuoteFileCropInp']['name']);
					$temp 				= 	explode(".", $_FILES["QuoteFileCropInp"]["name"]);
					$extension 			= 	strtolower(end($temp));
					$uploadedfile		=	$_FILES['QuoteFileCropInp']['tmp_name'];
					
					if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
						$src = imagecreatefromjpeg($uploadedfile);
					}
					else if($extension=="png"){
						$src = imagecreatefrompng($uploadedfile);
					}
					else{
						$src = imagecreatefromgif($uploadedfile);
					}
					
					list($width,$height)	=	getimagesize($uploadedfile);
					$tmp					=	imagecreatetruecolor(720,400);
					imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,720,400,$croppedNewWidth,$croppedNewHeight);
					
					$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
					$newfilenamePath = "./public/quotes/".$imageName;
					imagejpeg($tmp,$newfilenamePath,100);
					imagedestroy($tmp);
					imagedestroy($src);
					
					escape_str($imageName);
					return $view = new JsonModel(array(
						'output'  		=> 1,
						'imageName' 	=> $imageName
					));
					}
				break;
				default:
				return $view = new JsonModel(array(
					'output'          => 0,
					'message'          => 'The given extension is not allowed.',
				));
				break;
			}
		}
	
	//Corn mail for does not update duediligence form before 1 year
	public function subscribeMailAction(){
		$baseUrls 	  = $this->getServiceLocator()->get('config');
		$baseUrlArr   = $baseUrls['urls'];
		$baseUrl 	  = $baseUrlArr['baseUrl'];
		$basePath 	  = $baseUrlArr['basePath'];
		$userTable    = $this->getServiceLocator()->get('Models\Model\usersFactory');
		$subscribers  = $userTable->getSubscribersList();
		//echo "<pre>"; print_r($subscribers); exit;
		if(count($subscribers > 0)){
			foreach($subscribers as $userSub){
				global $subscriptionSubject;
				global $subscriptionMessage;
				$subscriptionSubject 	= $subscriptionSubject;
				$subscriptionMessage 	= $subscriptionMessage;
				$subscriptionMessage 	= str_replace("<USERNAME>",$userSub->u_display_name, $subscriptionMessage);
				//$to				  	= $userSub->u_email;
				$to				  	= 'naveenleela3@gmail.com,syaramala@aapthitech.com';
				echo $subscriptionMessage; exit;
				if(sendMail($to,$subscriptionSubject,$subscriptionMessage)){
					echo  "Success";
				}else{
					echo  "Fail";
				}
			}exit;
		}else{
			echo  "Fail"; exit;
		}
	}
	
}	

