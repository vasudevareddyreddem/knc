<?php
namespace QuoteSite\Controller;

use Zend\View\Model\ModelInterface;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\Session\Container;

class QuotesController extends AbstractActionController
{
	public function allEmptyPicureQuotesAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$pictureQuotes 				= $quotesTable->getAllEmptyPictureQuotes();
		$picQuotes = array();
		$picQuotesHtml = '';
		if(count($pictureQuotes) != 0){
			foreach($pictureQuotes as $key=>$pq){
				$picUrl 	= explode('/',$pq['qc_pic_quote_picture_original']);
				$fpicUrl 	= explode('.',$picUrl[4]);
				$picQuotes[$fpicUrl[0]] = $pq['qc_pic_quote_picture_original'];
				$picQuotesHtml .= '<div class="wrap">'.
						'<img style="width:60px;height:54px;" src="'.$pq['qc_pic_quote_picture_original'].'"/>'.
						'<div class="upperhover"></div>'.
					'</div>';
			}
		}
		return new JsonModel(array(					
			'baseUrl' 		=>  $baseUrl,
			'basePath'  	=>  $basePath,
			'picQuotes'  	=>  $picQuotes,
			'picQuotesCount'=>  count($picQuotes),
			'picQuotesHtml' =>  $picQuotesHtml
		));
	}
	public function allPicureQuotesAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$pictureQuotes 				= $quotesTable->getAllPictureQuotes();
		$picQuotes = array();
		$picQuotesHtml = '';
		$qtext1 = '';
		$atext1 = '';
		$picId  = '';
		if(count($pictureQuotes) != 0){
			foreach($pictureQuotes as $key=>$pq){
				if($key == 0){
					$qtext1 = $pq['qc_name'];
					$atext1 = $pq['qc_pic_bottom'];
					$picId =  $pq['qc_id'];
				}
				$picQuotes[$pq['qc_id']]['acolor'] 		= $pq['qc_pic_quote_acolor'];
				$picQuotes[$pq['qc_id']]['afont'] 		= $pq['qc_pic_quote_afont'];
				$picQuotes[$pq['qc_id']]['afontsize'] 	= $pq['qc_pic_quote_afontsize'];
				$picQuotes[$pq['qc_id']]['afontstyle'] 	= $pq['qc_pic_quote_afontstyle'];
				$picQuotes[$pq['qc_id']]['ax'] 			= $pq['qc_pic_quote_ax'];
				$picQuotes[$pq['qc_id']]['ay'] 			= $pq['qc_pic_quote_ay'];
				$picQuotes[$pq['qc_id']]['picture'] 	= $pq['qc_pic_quote_picture_original'];
				$picQuotes[$pq['qc_id']]['bgcolor'] 	= $pq['qc_pic_quote_bgcolor'];
				$picQuotes[$pq['qc_id']]['qalign'] 		= $pq['qc_pic_quote_qalign'];
				$picQuotes[$pq['qc_id']]['qcolor'] 		= $pq['qc_pic_quote_qcolor'];
				$picQuotes[$pq['qc_id']]['qfont'] 		= $pq['qc_pic_quote_qfont'];
				$picQuotes[$pq['qc_id']]['qfontsize'] 	= $pq['qc_pic_quote_qfontsize'];
				$picQuotes[$pq['qc_id']]['qfontstyle'] 	= $pq['qc_pic_quote_qfontstyle'];
				$picQuotes[$pq['qc_id']]['qmaxheight'] 	= $pq['qc_pic_quote_qmaxheight'];
				$picQuotes[$pq['qc_id']]['qwidth'] 		= $pq['qc_pic_quote_qwidth'];
				$picQuotes[$pq['qc_id']]['qx'] 			= $pq['qc_pic_quote_qx'];
				$picQuotes[$pq['qc_id']]['qy'] 			= $pq['qc_pic_quote_qy'];
				$picQuotes[$pq['qc_id']]['qtext'] 		= $pq['qc_name'];
				$picQuotes[$pq['qc_id']]['atext'] 		= $pq['qc_pic_bottom'];
				
				
				$picQuotesHtml .= '<div class="wrap" id="pic_quote_'.$pq['qc_id'].'">'.
						'<img src="'.$pq['qc_pic_quote_picture_preview'].'" id="'.$pq['qc_id'].'"/>'.
						'<div class="upperhover"></div>'.
					'</div>';
			}
		}
		return new JsonModel(array(					
			'baseUrl' 		=>  $baseUrl,
			'basePath'  	=>  $basePath,
			'picQuotes'  	=>  $picQuotes,
			'picQuotesCount'=>  count($picQuotes),
			'picQuotesHtml' =>  $picQuotesHtml,
			'qtext1' 		=>  $qtext1,
			'atext1' 		=>  $atext1,
			'picId' 		=>  $picId,
		));
	}
	public function uploadCamPictureAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		
		$folder = './public/pictures/picturequotes/uploads/';
		$filename = md5($_SERVER['REMOTE_ADDR'].rand()).'.jpg';
		$original = $folder.$filename;
		$input = file_get_contents('php://input');
		if(md5($input) == '7d4df9cc423720b7f1f3d672b89362be'){
			exit;
		}
		$result = file_put_contents($original, $input);
		if (!$result) {
			echo '{
				"error"		: 1,
				"message"	: "Failed save the image. Make sure you chmod the uploads folder and its subfolders to 777."
			}';
			exit;
		}
		$info = getimagesize($original);
		if($info['mime'] != 'image/jpeg'){
			unlink($original);
			exit;
		}
		rename($original,'./public/pictures/picturequotes/uploads/'.$filename);
		$original 	= './public/pictures/picturequotes/uploads/'.$filename;
		$origImage	= imagecreatefromjpeg($original);
		$newImage	= imagecreatetruecolor(465,360);
		imagecopyresampled($newImage,$origImage,0,0,0,0,465,360,520,370); 
		imagejpeg($newImage,'./public/pictures/picturequotes/uploads/'.$filename);
		
		$ffilename = $baseUrl.'public/pictures/picturequotes/uploads/'.$filename;
		$ofilename = 'public/pictures/picturequotes/uploads/'.$filename;
		echo '{"path":"'.$ffilename.'","url":"'.$ffilename.'","original":"'.$ofilename.'"}';
		exit;
	}
	public function uploadMakePictureAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		
		if(isset($_FILES['file']['name'])){
			$extention 			= explode('.',$_FILES['file']['name']);
			$imageName 			= date('Ymd') ."_". date("His").'.'.end($extention);
			$newfilenamePath 	= "./public/pictures/picturequotes/uploads/".$imageName;
			move_uploaded_file($_FILES['file']['tmp_name'], $newfilenamePath);
		
			$img_info 			= getimagesize($newfilenamePath);
			$width 				= $img_info[0];
			$height 			= $img_info[1];
			
			if(end($extention) == 'png'){
				$src = imagecreatefrompng($newfilenamePath);
				$dst = imagecreatetruecolor(465, 360);
				imagecopyresampled($dst, $src, 0, 0, 0, 0, 465, 360, $width, $height);
				imagepng($dst, $newfilenamePath);
				imagedestroy($dst);
			}else{
				$src = imagecreatefromjpeg($newfilenamePath);
				$dst = imagecreatetruecolor(465, 360);
				imagecopyresampled($dst, $src, 0, 0, 0, 0, 465, 360, $width, $height);
				imagejpeg($dst, $newfilenamePath,100);
				imagedestroy($dst);
			}
			$filenamePath 			= "public/pictures/picturequotes/uploads/".$imageName;
			$output = array();
			$output['path'] 		= $baseUrl.$filenamePath;
			$output['url'] 			= $baseUrl.$filenamePath;
			$output['original'] 	= $filenamePath;
		}else{
			$output = array();
		}
		return new JsonModel(array(					
			'baseUrl' 		=>  $baseUrl,
			'basePath'  	=>  $basePath,
			'output'  		=>  $output,
		));
	}
	public function savePictureQuoteAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$pictureQuoteTable   	    = $this->getServiceLocator()->get('Models\Model\PictureQuoteFactory');
		if(isset($_POST['base64data'])){
			$imageName 			= date('Ymd') ."_". date("His");
			$newfilenamePath 	= "./public/pictures/picturequotes/patterns";
			$postBase64Data 	= preg_replace('#^data:image/\w+;base64,#i', '', $_POST['base64data']);
			//Full Image
				$image_f = @imagecreatefromstring(base64_decode($postBase64Data));
				imagejpeg($image_f, $newfilenamePath."/".$imageName.'.jpg',100);
			// Samll
				$img_info 			= getimagesize($newfilenamePath."/".$imageName.'.jpg');
				$width 				= $img_info[0];
				$height 			= $img_info[1];
				$image_s = imagecreatetruecolor(70, 54);
				imagecopyresampled($image_s, $image_f, 0, 0, 0, 0, 70, 54, $width, $height);
				imagejpeg($image_s, $newfilenamePath."/".$imageName.'_preview.jpg',100);
			// End
			imagedestroy($image_f);
			$filenamePath 	= "public/pictures/picturequotes/patterns";
			
			global $seoGTitle;
			global $seoGDecrpt;
			global $seoGUrl;
			global $seoGImage;
			$seoGTitle 		= 'Make a Picture Quote - Spread the Quote';
			$seoGDecrpt     = $_POST['qtext'];
			$seoGImage		= $baseUrl.$filenamePath.'/'.$imageName.'.jpg';
			$seoGUrl		= $baseUrl.'make-picture-quote';
			$fbShare    = "https://www.facebook.com/sharer/sharer.php?u=".$seoGUrl;
			$twittShare = "https://twitter.com/intent/tweet?url=".$seoGUrl;
			$gShare     = "https://plus.google.com/share?url=".$seoGUrl;
			$fbUrlShareUrl = '"'.$fbShare.'"';
			$twittShareUrl = '"'.$twittShare.'"';
			$gShareUrl     = '"'.$gShare.'"';
			$output = array();
			$output['picture'] 		= $baseUrl.$filenamePath.'/'.$imageName.'.jpg';
			$output['add_callback'] = false;
			$output['status'] 		= 'ok';
			$output['content'] 	= '<div class="big-share" data-picture="'.$seoGImage.'" data-url="'.$seoGImage.'" data-title="'.$seoGTitle.'" data-description="'.$seoGDecrpt.'" data-twitter-text="'.$seoGDecrpt.'" tabindex="1000">
    
			<a class="f" href="#">&nbsp;</a>
			<a class="t" href="#">&nbsp;</a>
    
			</div>'.
			
			'<a href="'.$baseUrl.$filenamePath.'/'.$imageName.'.jpg" target="_blank" style="margin-left:5px">View image page</a>';
		
			$qc_img 		= $baseUrl.$filenamePath.'/'.$imageName.'.jpg';
			$qc_u_id 		= $_POST['user_id'];
			$qc_name 		= $_POST['qtext'];
			$qc_pic_bottom 	= $_POST['atext'];
			$quoteId 		= $quotesTable->addMakeQuoteuser($qc_img,$qc_u_id,$qc_name,$qc_pic_bottom);
			$qc_picture 	= $filenamePath."/".$imageName.'.jpg';
			$preview 		= $filenamePath."/".$imageName.'_preview.jpg';
			$pictureQuoteTable->addMakeQuoteuser($_POST,$quoteId,$qc_picture,$preview);
		}else{
			$output = array();
		}
		return new JsonModel(array(					
			'baseUrl' 		=>  $baseUrl,
			'basePath'  	=>  $basePath,
			'output'  		=>  $output,
		));
	}
	public function makePictureQuoteAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		if(isset($user_session->userId)){
			$userId = $user_session->userId;
		}else{
			$userId = 0;
		}
		return new ViewModel(array(					
			'baseUrl' 			=>  $baseUrl,
			'basePath'  		=>  $basePath,
			'userId'  			=>  $userId,
		));
	}
    public function indexAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		
		return new ViewModel(array(					
			'baseUrl' 			=>  $baseUrl,
			'basePath'  		=>  $basePath,
			
		));
		
	}
	public function createAQuoteAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$quoteCategoriesTable       = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$authorTable                = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$userTable                  = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$languageTable              = $this->getServiceLocator()->get('Models\Model\LanguageFactory');

		$famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);	
		
		$QuoteInfo = "";
		$routes 					= $this->params()->fromRoute('id');
			if($routes != "")
			{
				$ids 						= explode("-",$routes);
			}
		//echo "<pre>";print_r($_POST);exit;		
		if(isset($_POST) && $_POST !="" && !empty($_POST) && empty($ids))
		{
			$Imgname = "";
			if(isset($_POST["file_data"]) && $_POST["file_data"] != "")
			{
				$Imgname = $_POST["file_data"];
			}			
			if(isset($_POST['sessionId']) && $_POST['sessionId']!=""){			
				$uid = rtrim($_POST['sessionId']);
			}else{
				$uid = '';
			}
			$checkUser  =  $userTable->getUserData($uid);
			if(isset($checkUser->u_id) && $checkUser->u_id!=""){				
				$dataa = array(
					'au_fname'    => ucfirst($checkUser->uf_fname),				
					'au_lname'    => ucfirst($checkUser->uf_lname),		
					'au_descrpt'  => $checkUser->uf_about_me,   
					'au_u_id'     => $checkUser->u_id,   
				);	
				$checkAuthor = $authorTable->checkAuthor($checkUser->u_id);
				if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
					$qc_au_id = $checkAuthor->au_id;	
				}else{
					$addedAuthor = $authorTable->addSQAuthor($dataa);
					if($addedAuthor){
						$qc_au_id = $addedAuthor;
					}
				}
				
				$data1 = array(
					'quoteText'    => $_POST['quoteText'],						
					'sessionId'    => $_POST['sessionId'],						
					'qc_qc_cat_id' => $_POST['qc_qc_cat_id'],						
					'qc_id'    => $_POST['qc_id'],						
					'qc_lang_id'    => $_POST['qc_lang_id'],						
					'qc_tags'    => $_POST['qc_tags'],
					'qc_au_id'    => $qc_au_id,
				);	
				$quoteId	= $quotesTable->addUserQuote($data1,$Imgname,$flag="add");

				if($quoteId){
					$qc_cat_id=explode(',',$_POST['qc_qc_cat_id']);
					$addCategories = $quoteCategoriesTable->addQuotecategories($qc_cat_id,$quoteId);
				}else{
					
				}
				
			}				
			return new JsonModel(array(					
					'output' 	=> 'sucess',
			));
			
		}
		else if(isset($ids) && $ids !="" && !empty($ids) && empty($_POST))
		{
	
			$QuoteInfo	= $quotesTable->getUserQuote($ids);
			
		}
		else if(!empty($_POST) && !empty($ids))
		{
	
			$uid  = base64_decode($ids['0']);
			$QtId = base64_decode($ids['1']);
			
			$Imgname = "";
			if(isset($_POST["file_data"]) && $_POST["file_data"] != "")
			{
				$Imgname = $_POST["file_data"];
			}
			if(isset($_POST['sessionId']) && $_POST['sessionId']!=""){			
				$uid = rtrim($_POST['sessionId']);
			}else{
				$uid = '';
			}
				$checkAuthor = $authorTable->checkAuthor($uid);
				if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
					$qc_au_id = $checkAuthor->au_id;	
				}else{
					$qc_au_id = "";	
				}
				
				$data1 = array(
					'quoteText'    => $_POST['quoteText'],						
					'sessionId'    => $_POST['sessionId'],						
					'qc_qc_cat_id' => $_POST['qc_qc_cat_id'],						
					'qc_id'    => $_POST['qc_id'],						
					'qc_lang_id'    => $_POST['qc_lang_id'],						
					'qc_tags'    => $_POST['qc_tags'],
					'qc_au_id'    => $qc_au_id,
				);
			$quoteId	= $quotesTable->addUserQuote($data1,$Imgname,$flag="update");
			$qc_cat_id=explode(',',$_POST['qc_qc_cat_id']);
			$addCategories = $quoteCategoriesTable->addQuotecategories($qc_cat_id,$quoteId);
				
			return new JsonModel(array(					
				'output' 	=> 'updated',
			));
		}
		$langsList = $languageTable->languagesList();		
		if(count($langsList)!=0){
			escape_arr($langsList);
		}else{
			$langsList = "";
		}
		
		return new ViewModel(array(					
				'baseUrl' 							=>  $baseUrl,
				'basePath'  						=>  $basePath,		
				'QuoteInfo'							=>  $QuoteInfo,
				'famousCategoriesList'  			=>  $famousCategoriesList,
				'langArray'     =>  $langsList
		));
	}
	public function allQuotesAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   	            = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		
		$allQuotes 					= $quotesTable->quotesList();
		$famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);			
		$famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);			
		
		
		return new ViewModel(array(					
			'baseUrl' 						=>  $baseUrl,
			'basePath'  					=>  $basePath,
			'allQuotes'  					=>  $allQuotes,
			'famousCategoriesList'  		=>  $famousCategoriesList,
			'famousAuthorsList'  			=>  $famousAuthorsList,
			
		));
		
	}
	
	public function quoteOfTheDayAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   		= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		
		$quoteOfDay 				= $quotesTable->quoteoftheday($flag=1);
		$famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);	
		$famousAuthorsList 			= $famousAuthorsTable->famousAuthors($flag=1);
		$pageCount  				= 10;
		$pagesInRange  				= 1;
		$quoteOfDay->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$quoteOfDay->setItemCountPerPage($pageCount);	
		$quoteOfDay->setPageRange(5);
		$QtOfDay = array();		
		if(count($quoteOfDay))
		{
			foreach($quoteOfDay as $q=>$qDay)
			{
				$QtOfDay[$q]['qc_id'] 			      = $qDay->qc_id;
				$QtOfDay[$q]['qc_name'] 		      = $qDay->qc_name;
				$QtOfDay[$q]['qc_image']		      = $qDay->qc_image;
				$QtOfDay[$q]['qc_tags']			      = $qDay->qc_tags;
				$QtOfDay[$q]['qc_qc_cat_id']		  = $qDay->qc_qc_cat_id;
				$QtOfDay[$q]['qc_created_at']	      = $qDay->qc_created_at;
				$QtOfDay[$q]['fav']				      = $qDay->fav;
				$QtOfDay[$q]['vupCatId']		      = $qDay->vupCatId;
				$QtOfDay[$q]['viewCounnt']		      = $qDay->viewCounnt;
				$QtOfDay[$q]['au_id']			      = $qDay->au_id;
				$QtOfDay[$q]['au_fname']		      = $qDay->au_fname;
				$QtOfDay[$q]['au_lname']		      = $qDay->au_lname;
				$QtOfDay[$q]['au_pic']			      = $qDay->au_pic;
				$QtOfDay[$q]['qc_cat_id']		      = $qDay->qc_cat_id;
				$QtOfDay[$q]['qc_quote_of_day_date']  = $qDay->qc_quote_of_day_date;
				$QtOfDay[$q]['qc_cat_name']           = $qDay-> qc_cat_name;
				
			}
		}
		return new ViewModel(array(					
			'baseUrl' 							=>  $baseUrl,
			'basePath'  						=>  $basePath,			
			'famousCategoriesList'  			=>  $famousCategoriesList,
			'famousAuthorsList'  				=>  $famousAuthorsList,
			'QtOfDay'  							=>  $QtOfDay,
			'paginationQuoteOfDay'  			=>  $quoteOfDay,
			'pageCount' 						=>  $pageCount,
			'pagesInRange' 						=>  $pagesInRange,
			
		));
		
	}
	
	public function postAQuoteAction(){
		
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		$quotesTable   				= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   	= $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$quoteCategoriesTable       = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$authorTable                = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$userTable                  = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$languageTable              = $this->getServiceLocator()->get('Models\Model\LanguageFactory');

		$famousCategoriesList 		= $famousCategoriesTable->famousCategories($flag=1);	
		
		$QuoteInfo = "";
		$routes 					= $this->params()->fromRoute('id');
			if($routes != "")
			{
				$ids 						= explode("-",$routes);
			}
		//echo "<pre>";print_r($_POST);exit;		
		if(isset($_POST) && $_POST !="" && !empty($_POST) && empty($ids))
		{
			$Imgname = "";
			if(isset($_POST["file_data"]) && $_POST["file_data"] != "")
			{
				$Imgname = $_POST["file_data"];
			}			
			if(isset($_POST['sessionId']) && $_POST['sessionId']!=""){			
				$uid = rtrim($_POST['sessionId']);
			}else{
				$uid = '';
			}
			$checkUser  =  $userTable->getUserData($uid);
			if(isset($checkUser->u_id) && $checkUser->u_id!=""){				
				$dataa = array(
					'au_fname'    => ucfirst($checkUser->uf_fname),				
					'au_lname'    => ucfirst($checkUser->uf_lname),		
					'au_descrpt'  => $checkUser->uf_about_me,   
					'au_u_id'     => $checkUser->u_id,   
				);	
				$checkAuthor = $authorTable->checkAuthor($checkUser->u_id);
				if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
					$qc_au_id = $checkAuthor->au_id;	
				}else{
					$addedAuthor = $authorTable->addSQAuthor($dataa);
					if($addedAuthor){
						$qc_au_id = $addedAuthor;
					}
				}
				
				$data1 = array(
					'quoteText'    => $_POST['quoteText'],						
					'sessionId'    => $_POST['sessionId'],						
					'qc_qc_cat_id' => $_POST['qc_qc_cat_id'],						
					'qc_id'    => $_POST['qc_id'],						
					'qc_lang_id'    => $_POST['qc_lang_id'],						
					'qc_tags'    => $_POST['qc_tags'],
					'qc_au_id'    => $qc_au_id,
				);	
				$quoteId	= $quotesTable->addUserQuote($data1,$Imgname,$flag="add");

				if($quoteId){
					$qc_cat_id=explode(',',$_POST['qc_qc_cat_id']);
					$addCategories = $quoteCategoriesTable->addQuotecategories($qc_cat_id,$quoteId);
				}else{
					
				}
				
			}				
			return new JsonModel(array(					
					'output' 	=> 'sucess',
			));
			
		}
		else if(isset($ids) && $ids !="" && !empty($ids) && empty($_POST))
		{
	
			$QuoteInfo	= $quotesTable->getUserQuote($ids);
			
		}
		else if(!empty($_POST) && !empty($ids))
		{
	
			$uid  = base64_decode($ids['0']);
			$QtId = base64_decode($ids['1']);
			
			$Imgname = "";
			if(isset($_POST["file_data"]) && $_POST["file_data"] != "")
			{
				$Imgname = $_POST["file_data"];
			}
			if(isset($_POST['sessionId']) && $_POST['sessionId']!=""){			
				$uid = rtrim($_POST['sessionId']);
			}else{
				$uid = '';
			}
				$checkAuthor = $authorTable->checkAuthor($uid);
				if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
					$qc_au_id = $checkAuthor->au_id;	
				}else{
					$qc_au_id = "";	
				}
				
				$data1 = array(
					'quoteText'    => $_POST['quoteText'],						
					'sessionId'    => $_POST['sessionId'],						
					'qc_qc_cat_id' => $_POST['qc_qc_cat_id'],						
					'qc_id'    => $_POST['qc_id'],						
					'qc_lang_id'    => $_POST['qc_lang_id'],						
					'qc_tags'    => $_POST['qc_tags'],
					'qc_au_id'    => $qc_au_id,
				);
			$quoteId	= $quotesTable->addUserQuote($data1,$Imgname,$flag="update");
			$qc_cat_id=explode(',',$_POST['qc_qc_cat_id']);
			$addCategories = $quoteCategoriesTable->addQuotecategories($qc_cat_id,$quoteId);
				
			return new JsonModel(array(					
				'output' 	=> 'updated',
			));
		}
		$langsList = $languageTable->languagesList();		
		if(count($langsList)!=0){
			escape_arr($langsList);
		}else{
			$langsList = "";
		}
		
		return new ViewModel(array(					
				'baseUrl' 							=>  $baseUrl,
				'basePath'  						=>  $basePath,		
				'QuoteInfo'							=>  $QuoteInfo,
				'famousCategoriesList'  			=>  $famousCategoriesList,
				'langArray'     =>  $langsList
		));
	}
	
	
}	

