<?php
namespace QuoteSite\Controller;

use Zend\View\Model\ModelInterface;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\Session\Container;

class CategoriesController extends AbstractActionController
{
    public function indexAction(){
		$user_session 				= new Container('user');
		$baseUrls 					= $this->getServiceLocator()->get('config');
		$baseUrlArr 				= $baseUrls['urls'];
		$baseUrl 					= $baseUrlArr['baseUrl'];
		$basePath 					= $baseUrlArr['basePath'];
		
		return new ViewModel(array(					
			'baseUrl' 			=>  $baseUrl,
			'basePath'  		=>  $basePath,
			
		));
		
	}
	public function uploadProfileImageAction(){
		if(isset($_FILES) && isset($_FILES['fileCropInp']['name'])){
			@unlink('./public/uploads/'.$_POST['imageId']);
			$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
			$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
			$croppedX 			= 	$_POST['croppedX'];
			$croppedY 			= 	$_POST['croppedY'];
			$image 				= 	stripslashes($_FILES['fileCropInp']['name']);
			$temp 				= 	explode(".", $_FILES["fileCropInp"]["name"]);
			$extension 			= 	end($temp);
			$uploadedfile		=	$_FILES['fileCropInp']['tmp_name'];
			
			if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
				$src = imagecreatefromjpeg($uploadedfile);
			}
			else if($extension=="png"){
				$src = imagecreatefrompng($uploadedfile);
			}
			else{
				$src = imagecreatefromgif($uploadedfile);
			}
			
			list($width,$height)	=	getimagesize($uploadedfile);
			$tmp					=	imagecreatetruecolor($croppedNewWidth,$croppedNewHeight);
			imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,$croppedNewWidth,$croppedNewHeight,$croppedNewWidth,$croppedNewHeight);
			
			$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
			$newfilenamePath = "./public/uploads/profiles/".$imageName;
			imagejpeg($tmp,$newfilenamePath,100);
			imagedestroy($tmp);
			imagedestroy($src);
			$user_session 			= 	new Container('admin');
			
			$userTable  = 	$this->getServiceLocator()->get('Models\Model\UsersFactory');			
			return $view = new JsonModel(array(
				'output'  		=> 1,
				'imageName' 	=> $imageName
			));
		}
	}
	
	
	public function categoriesListAction(){
		$user_session 											= new Container('user');
		$baseUrls 	  											= $this->getServiceLocator()->get('config');
		$baseUrlArr   											= $baseUrls['urls'];
		$baseUrl 	  											= $baseUrlArr['baseUrl'];
		$basePath 	  											= $baseUrlArr['basePath'];
		$authorsTable      										= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$CategoriesTable   										= $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$paginator        = $CategoriesTable->categoriesList($flag=1);
		// $AuthList  = $authorsTable->famousAuthors($flag=1);		
		$pageCount  	= 36;		
		$paginator->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$paginator->setItemCountPerPage($pageCount);	
		$paginator->setPageRange(5);		
		$categoriesList	= array();
		if(count($paginator))
		{
			foreach($paginator as $c=>$catList)
			{
				$categoriesList[$c]['qc_cat_id'] 				= $catList->qc_cat_id;
				$categoriesList[$c]['qc_cat_name'] 				= $catList->qc_cat_name;
				$categoriesList[$c]['qc_cat_popular'] 			= $catList->qc_cat_popular;
				$categoriesList[$c]['qc_cat_status'] 			= $catList->qc_cat_status;
			}
		}
		return new viewModel(array(					
			'baseUrl' 											=>  $baseUrl,
			'basePath'  										=>  $basePath,
			'paginationcategory'  								=>  $paginator,
			// 'AuthList'  										=>  $AuthList,			
			'catList'  											=>  $categoriesList,
			'pageCount' 										=>  $pageCount,
		
		));
		
	}
}	

