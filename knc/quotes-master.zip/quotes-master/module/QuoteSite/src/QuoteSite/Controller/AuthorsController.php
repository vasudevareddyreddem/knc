<?php
namespace QuoteSite\Controller;

use Zend\View\Model\ModelInterface;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\Session\Container;

class AuthorsController extends AbstractActionController
{
    public function indexAction(){
		$user_session 								= new Container('user');
		$baseUrls 									= $this->getServiceLocator()->get('config');
		$baseUrlArr 								= $baseUrls['urls'];
		$baseUrl 									= $baseUrlArr['baseUrl'];
		$basePath 									= $baseUrlArr['basePath'];
		$authorsTable    							= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$famousCategoriesTable   					= $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$paginator             						= $authorsTable->getAllAuthList();
		$flag 										= 1;
		$famousCategoriesList 						= $famousCategoriesTable->famousCategories($flag);		
		$pageCount  								= 48;		
		$paginator->setCurrentPageNumber((int)$this->params()->fromQuery('page',1));
		$paginator->setItemCountPerPage($pageCount);	
		$paginator->setPageRange(5);
		$totalCount = $paginator->getTotalItemCount();
		 $authorsList	= array();
		if($paginator->count()){
			foreach($paginator as $a=>$auth){
				$authorsList[$a]['au_id'] 			= $auth->au_id;
				$authorsList[$a]['au_fname'] 		= $auth->au_fname;
				$authorsList[$a]['au_lname'] 		= $auth->au_lname;
				$authorsList[$a]['au_pic'] 			= $auth->au_pic;
			}
		}
	
		return new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,
			'authorsList' 							=> $authorsList,
			'paginationauthors'  					=>  $paginator,
			'famousCategories' 						=> $famousCategoriesList,
			'pageCount' 							=>  $pageCount,
			'catQuotesCnt' 							=>  $totalCount,
			
		));		
	}
	public function authorAjaxAction(){
		$user_session 								= new Container('user');
		$baseUrls 									= $this->getServiceLocator()->get('config');
		$baseUrlArr 								= $baseUrls['urls'];
		$baseUrl 									= $baseUrlArr['baseUrl'];
		$basePath 									= $baseUrlArr['basePath'];
		$authorsTable    							= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$famousCategoriesTable   					= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$page      = $_POST['publicBoxesOffset'];
		$pageCount = $_POST['publicBoxesPerPage'];	
		$paginator = $authorsTable->authorpageajax($pageCount,$page);
		$authorsList	= array();
		foreach($paginator as $a=>$auth){
			$authorsList[$a]['au_id'] 			= $auth->au_id;
			$authorsList[$a]['au_fname'] 		= $auth->au_fname;
			$authorsList[$a]['au_lname'] 		= $auth->au_lname;
			$authorsList[$a]['au_pic'] 			= $auth->au_pic;
		}
		$view = new ViewModel(array(					
			'baseUrl' 								=>  $baseUrl,
			'basePath'  							=>  $basePath,
			'authorsList' 							=> $authorsList,
			'cntauthors' 							=> count($authorsList),
		));
		return $view->setTerminal(true);	
	}
}	

