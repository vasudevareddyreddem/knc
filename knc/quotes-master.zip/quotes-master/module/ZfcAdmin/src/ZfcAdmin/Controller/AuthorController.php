<?php
namespace ZfcAdmin\Controller;
use Zend\Form\Form;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\Authentication\AuthenticationService;
use SanAuthWithDbSaveHandler\Storage\IdentityManagerInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\View\Model\JsonModel;
use Zend\Cache\StorageFactory;
use ScnSocialAuth\Mapper\UserProviderInterface;
class AuthorController extends AbstractActionController
{
	public function indexAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			return new viewModel(array(					
				'baseUrl' 		=> 	$baseUrl,
				'basePath'   	=>  $basePath
			));
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function authorUploadPicAction(){
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		if(isset($_GET['type']) && $_GET['type']!=""){
			$temp = explode(".", $_FILES[$_GET['type']]["name"]);
			$name = date('Ymd') ."_". date("His") .'.' . end($temp);
			$newfilenamePath = "./public/authorpics/".$name;			
			$Pic = $basePath."/authorpics/".$name;			
			if (move_uploaded_file($_FILES[$_GET['type']]["tmp_name"], $newfilenamePath)){
				return new JsonModel(array(					
					'imageName' => 	$name,
					'Pic' => $Pic
				));
			}
		}else{
			return $viewModel = new ViewModel(
				array(
					'baseUrl'				 	=> $baseUrl,
					'basePath' 					=> $basePath,
			));	
		}
	}	
	public function authorListsAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$authorTable = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$authorsList = $authorTable->authorsList();
		if(count($authorsList)!=0){
			foreach($authorsList as $key=>$author){
				if($author['au_pic']!="" && $author['au_pic']!=null){
					$authpic = str_replace(' ', '_', strtolower($author['au_fname']));
					$authpic = $authpic.'.jpg';
					$imageUrl = $basePath."/author_imgs/".$authpic;
				}else{
					$imageUrl = $basePath."/images/category.png";
				}
				$data[$key]['au_id']           = $key+1;
				$data[$key]['au_pic']        = "<img src='$imageUrl' width='30%' height='30%'>";
				$data[$key]['au_fname']        = ucfirst($author['au_fname']);
				$data[$key]['au_lname']        = ucfirst($author['au_lname']);
				$data[$key]['au_birth_year']   = $author['au_birth_year'];
				$data[$key]['au_deadth_year']  = $author['au_deadth_year'];
				$data[$key]['au_descrpt']      = $author['au_descrpt'];
				$data[$key]['au_wiki_link']    = $author['au_wiki_link'];
				if($author['au_status']=='1'){
					$au_status	=	'<a href="javascript:void(0);" title="Live" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>';
				}else if($author['au_status']=='2'){
					$au_status ='<a href="javascript:void(0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else if($author['au_status']=='0'){
					$au_status='<a href="javascript:void(0);" title="Hidden" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>';
				}				
				$au_id		=	$author['au_id'];
				$editUrl = $baseUrl.'admin/update-author?auid='.base64_encode($au_id.'quotes'.$au_id);
				$data[$key]['au_status'] = 	$au_status;
				if($author['au_status'] =='1'){
					$data[$key]['action'] = '<a href="javascript:void(0);" 
					onclick="viewAuthor('.$au_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> </a>
					<a href="'.$editUrl.'" class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Hidden" onclick="hideAuthor('.$au_id.',0);" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteAuthor('.$au_id.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else{
					$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="viewAuthor('.$au_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> 
					<a href="javascript:void(0);" title="Live" onclick="hideAuthor('.$au_id.',1);" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteAuthor('.$au_id.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}

		echo json_encode($rclists); exit;	
	}
	public function addAuthorAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$authorTable = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
			if(isset($_POST['au_fname']) && $_POST['au_fname']!=""){
				$addedResult = $authorTable->addAuthor($_POST);
				if($addedResult){
					return new JsonModel(array(					
						'output' 	=> 'success',
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'alreadyexists',
					));	
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}	
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateAuthorAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$authorTable = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
			if(isset($_POST['au_id']) && $_POST['au_id']!=""){
				$id = $_POST['au_id'];
				$addedResult = $authorTable->updateAuthor($_POST,$id);
				if($addedResult){
					return new JsonModel(array(					
						'output' 	=> 'success',
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'alreadyexists',
					));	
				}
			}else if(isset($_GET['auid']) && $_GET['auid']!=""){
				$auid = base64_decode($_GET['auid']);
				$explodeData = explode('quotes',$auid);
				$au_id = $explodeData[0];
				$getAuthorData = $authorTable->getAuthorData($au_id);
				if($getAuthorData!=""){
					escape_arr($getAuthorData);
					return new ViewModel(array(					
						'output' 	 => 'success',
						'authorData' => $getAuthorData,
						'baseUrl'    => $baseUrl,
						'basePath'   => $basePath,
					));	
				}else{
					return new ViewModel(array(					
						'output' 	=> 'fail',
						'authorData' => '',
					));	
				}
			}	
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function viewAuthorAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			if(isset($_POST['au_id']) && $_POST['au_id']!=""){
				$authorTable = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
				$au_id = $_POST['au_id'];
				$getAuthorData = $authorTable->getAuthorData($au_id);
				if($getAuthorData!=""){
					return new JsonModel(array(					
						'output' 	 => 'success',
						'getAuthor'  => $getAuthorData,
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'fail',
						'getAuthor' => '',
					));	
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	} 
	public function updateAuthorStatusAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		if(isset($_POST['au_id']) && $_POST['au_id']!=""){
			$au_id = $_POST['au_id'];
			$statuMode = $_POST['status'];
			$authorQuotesCnt = 0;
			if(isset($_POST['status']) && $_POST['status']==2){
				$authorQuotesCnt = $quotesTable->authorQuotesCnt($au_id);
				if($authorQuotesCnt>0){
					return new JsonModel(array(					
						'output' 	   => 'success',
						'authorQCnt'   => $authorQuotesCnt,
					));	
				}else{
					$deleResult = $authorTable->deleteAuthor($au_id);
					if($deleResult){
						return new JsonModel(array(					
							'output' 	=> 'success',
							'authorQCnt'   => $authorQuotesCnt,
						));	
					}
				}
			}else{
				$statusResult = $authorTable->updateAuthorStatus($au_id,$statuMode);
				if($statusResult){
					return new JsonModel(array(					
						'output' 	=> 'success',
						'authorQCnt'   => $authorQuotesCnt,
					));	
				}
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}
	}
	
	public function uploadProfileImageAction(){
		
		$fileExtentios     = explode(".", $_FILES["fileCropInp"]["name"]);
        $extention         = strtolower(end($fileExtentios));
        switch($extention){
            case 'jpg' :case 'jpeg': case 'jpe': case 'png': case 'gif':
			if(isset($_FILES) && isset($_FILES['fileCropInp']['name'])){
				@unlink('./public/images/'.$_POST['imageId']);
				$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
				$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
				$croppedX 			= 	$_POST['croppedX'];
				$croppedY 			= 	$_POST['croppedY'];
				$image 				= 	stripslashes($_FILES['fileCropInp']['name']);
				$temp 				= 	explode(".", $_FILES["fileCropInp"]["name"]);
				$extension 			= 	strtolower(end($temp));
				$uploadedfile		=	$_FILES['fileCropInp']['tmp_name'];
				
				if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
					$src = imagecreatefromjpeg($uploadedfile);
				}
				else if($extension=="png"){
					$src = imagecreatefrompng($uploadedfile);
				}
				else{
					$src = imagecreatefromgif($uploadedfile);
				}
				
				list($width,$height)	=	getimagesize($uploadedfile);
				$tmp					=	imagecreatetruecolor(200,200);
				imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,200,200,$croppedNewWidth,$croppedNewHeight);
				
				$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
				$newfilenamePath = "./public/images/".$imageName;
				imagejpeg($tmp,$newfilenamePath,100);
				imagedestroy($tmp);
				imagedestroy($src);
				$user_session 			= 	new Container('admin');
				
				if($user_session->userId == $_POST['u_id']){
					$user_session->profile  =   $imageName;
				}
				$userTable  = 	$this->getServiceLocator()->get('Models\Model\UsersFactory');
				$result		=	$userTable->updateUserProfileImage($imageName,$_POST['u_id']);
				escape_str($imageName);
				return $view = new JsonModel(array(
					'output'  		=> 1,
					'imageName' 	=> $imageName
				));
				}
			break;
            default:
            return $view = new JsonModel(array(
                'output'          => 0,
                'message'          => 'The given extension is not allowed.',
            ));
            break;
		}
	}
	
}