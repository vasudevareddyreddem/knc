<?php
namespace ZfcAdmin\Controller;
use Zend\Form\Form;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\Authentication\AuthenticationService;
use SanAuthWithDbSaveHandler\Storage\IdentityManagerInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\View\Model\JsonModel;
use Zend\Cache\StorageFactory;
use ScnSocialAuth\Mapper\UserProviderInterface;
class AdminController extends AbstractActionController
{
	public function indexAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$url = $baseUrl.'/admin/user-management';
			return $this->redirect()->toUrl($url);
		}else{
			return new viewModel(array(					
				'baseUrl' 		=> 	$baseUrl,
				'basePath'   	=>  $basePath
			));
		}
	}
	public function headerAction($params)
    {
		$admin_session 	= 	new Container('admin');
		$baseUrls 	= $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl 	= $baseUrlArr['baseUrl'];
		$basePath 	= $baseUrlArr['basePath'];
		return $this->layout()->setVariable(
			"headerarray",array(
				'baseUrl' 		=> $baseUrl,
				'basePath' 		=> $basePath,
			)
		);
	}
	public function adminLogoutAction(){
		$admin_session 	= 	new Container('admin');
		$baseUrls 	= $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl 	= $baseUrlArr['baseUrl'];
		$basePath 	= $baseUrlArr['basePath'];
		session_destroy();
		return new JsonModel(array(					
			'output' => 1
		));
	}
	public function checkingLoginAction(){
		$admin_session 	= 	new Container('admin');
		$baseUrls 	= $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl 	= $baseUrlArr['baseUrl'];
		$basePath 	= $baseUrlArr['basePath'];
		if(isset($_POST['u_email']) && $_POST['u_email']!=""){
			$email = $_POST['u_email'];
			$pwd   = $_POST['u_password'];
			$userTable   = $this->getServiceLocator()->get('Models\Model\UsersFactory');
			$resultCount = $userTable->checkEmail($email,'1');
			if($resultCount!=0){
				$userResult = $userTable->userLogin($email,$mobile='',$pwd,'1');
				if ( isset($userResult->u_ut_id) && $userResult->u_ut_id=='1' ) {
					$admin_session->display_name=$userResult->u_display_name;
					$admin_session->email=$userResult->u_email;
					$admin_session->user_id=$userResult->u_id;
					$admin_session->usertype=$userResult->u_ut_id;			
					return $result = new JsonModel(array(					
						'output' 		=> 'success',
						'success'		=>	true,
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'wrongdeatils',
					));	
				}				
			}else{
				return new JsonModel(array(					
					'output' 	=> 'emailnotinrecord',
				));
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));		
		}	
	}
	
	
	
}