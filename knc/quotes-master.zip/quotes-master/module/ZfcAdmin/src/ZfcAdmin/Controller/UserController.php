<?php
namespace ZfcAdmin\Controller;
use Zend\Form\Form;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\Authentication\AuthenticationService;
use SanAuthWithDbSaveHandler\Storage\IdentityManagerInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\View\Model\JsonModel;
use Zend\Cache\StorageFactory;
use ScnSocialAuth\Mapper\UserProviderInterface;
class UserController extends AbstractActionController
{
	public function indexAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			return new viewModel(array(					
				'baseUrl' 		=> 	$baseUrl,
				'basePath'   	=>  $basePath
			));
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function viewUserAdminAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$userTable=$this->getServiceLocator()->get('Models\Model\UsersFactory');
			if(isset($_POST['u_id']) && $_POST['u_id']!=""){
				$u_id  = $_POST['u_id'];
				$getUserData = $userTable->admingetUserData($u_id);
				if(isset($getUserData->u_id) && $getUserData->u_id!=""){
					return new JsonModel(array(					
						'output' 	 => 'success',
						'getUser'  => $getUserData,
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'fail',
						'getUser' => '',
					));	
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function usersListAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$userTable=$this->getServiceLocator()->get('Models\Model\UsersFactory');
		$usersList = $userTable->allUsersList();
		if(count($usersList)!=0){
			foreach($usersList as $key=>$user){
				if($user['uf_pic']!="" && $user['uf_pic']!=null){
					$imageUrl = $basePath."/uploads/".$user['uf_pic'];
				}else{
					$imageUrl = $basePath."/img/icon-user.png";
				}
				$joinDate = strtotime($user['u_created_at']);
				$joinD    = date("Y-m-d", $joinDate);
				$dateValue = strtotime($joinD);
				$year = date('Y',$dateValue);
				$monthName = date('F',$dateValue);
				$dayName = date('d',$dateValue);
				$createdDate = $monthName.' '.$dayName.', '.$year;
				$data[$key]['u_id']           = $key+1;
				$data[$key]['uf_pic']          = "<img src='$imageUrl' width='30%' height='30%'>";
				$data[$key]['u_display_name']  = ucfirst($user['uf_fname']).' '.ucfirst($user['uf_lname']);
				$data[$key]['u_email']         = $user['u_email'];
				$data[$key]['u_mobile']        = $user['u_mobile'];				
				$data[$key]['joindate']        = $createdDate;				
				if($user['u_status']=='1'){
					$u_status	=	'<a href="javascript:void(0);" title="Live" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>';
				}else if($user['u_status']=='2'){
					$u_status ='<a href="javascript:void(0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else if($user['u_status']=='0'){
					$u_status='<a href="javascript:void(0);" title="Hidden" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>';
				}				
				$u_id		=	$user['u_id'];
				$editUrl = $baseUrl.'admin/update-user-admin?auid='.base64_encode($u_id.'quotes'.$u_id);
				$data[$key]['u_status'] = $u_status;
				if($user['u_status'] =='1'){
					$data[$key]['action'] = '<a href="javascript:void(0);" 
					onclick="viewUserMode('.$u_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> </a>
					<a href="javascript:void(0);" title="Hidden" onclick="hideUserhide('.$u_id.',0);" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteUserDelete('.$u_id.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else{
					$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="viewUserMode('.$u_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> 
					<a href="javascript:void(0);" title="Live" onclick="hideUserhide('.$u_id.',1);" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteUserDelete('.$u_id.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}
		echo json_encode($rclists); exit;	
	}
	function getUniqueCode($length = "")
	{
		$code = md5(uniqid(rand(), true));
		if ($length != "")
		return substr($code, 0, $length);
		else
		return $code;
	}
	public function updateUserStatusAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$userTypeTable=$this->getServiceLocator()->get('Models\Model\UserTypeFactory');
		$userTable=$this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userInfoTable  = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		$authorTable = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		if(isset($_POST['u_id']) && $_POST['u_id']!=""){
			$u_id = $_POST['u_id'];
			$statuMode = $_POST['status'];
			$userexists = 0;
			if(isset($_POST['status']) && $_POST['status']==2){
				$userexists = $authorTable->userAuthor($u_id);
				if($userexists>0){
					return new JsonModel(array(					
						'output' 	   => 'success',
						'userexists'   => $userexists,
					));	
				}else{
					$deleResult = $userTable->deleteUserByAdmin($u_id);
					$deleResultt = $userInfoTable->deleteUserInfoByAdmin($u_id);
					if($deleResultt){
						return new JsonModel(array(					
							'output' 	=> 'success',
							'userexists'   => $userexists,
						));	
					}
				}
			}else{
				$statusResult = $userTable->updateUserStatus($u_id,$statuMode);
				if($statusResult){
					return new JsonModel(array(					
						'output' 	=> 'success',
						'userexists'   => $userexists,
					));	
				}
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}
	}
	public function adminAddUserAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$userTypeTable=$this->getServiceLocator()->get('Models\Model\UserTypeFactory');
			$userTable=$this->getServiceLocator()->get('Models\Model\UsersFactory');
			$userInfoTable  = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');		
			$getUserTypes = $userTypeTable->getUserTypes();
			$userTypes = array();
			foreach($getUserTypes as $u=>$usertype){
				$userTypes[$u]['ut_id']   = $usertype->ut_id;
				$userTypes[$u]['ut_name'] = $usertype->ut_name;
			}
			$checkEmail = 0;
			if(isset($_POST['u_ut_id']) && $_POST['u_ut_id']!=""){
				$u_email  = $_POST['u_email'];
				$uf_name  = $_POST['uf_name'];
				$u_ut_id  = $_POST['u_ut_id'];
				$password = getUniqueCode('8');
				$checkEmail = $userTable->checkEmail($u_email,$u_ut_id,$password);
				if($checkEmail==0){
					$adminAddNewUser = $userTable->adminAddUser($u_email,$u_ut_id,$uf_name);
					if($adminAddNewUser>0){
						$u_id = $adminAddNewUser;
						$addInfo = $userInfoTable->addInfoUser($u_id,$uf_name);
						if($addInfo>0){
							// Mailing
							return new JsonModel(array(					
								'output'    	=>  'success',
							));
						}
					}
				}else{
					return new JsonModel(array(					
						'output'    	=>  'fail',
						'emailExists'   =>  'emailinrecord'
					));
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath,
					'userTypes'   	=>  $userTypes
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function changePasswordAction()
	{
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			if(isset($_POST['u_password']) && $_POST['u_password']!=""){
				$u_id = $_POST['u_id'];
				$u_password = $_POST['u_password'];
				$old_password = $_POST['o_u_password'];
				$n_u_password = $_POST['n_u_password'];
				$userTable=$this->getServiceLocator()->get('Models\Model\UsersFactory');
				if($old_password!=$n_u_password){
					$checkOldPassword = $userTable->getpassword($u_id,$old_password);
					if($checkOldPassword>0){
						$statusRest = $userTable->changepwd($u_id,$u_password);
						if($statusRest){
							$viewModel = new ViewModel(
							array(
								'baseUrl'	=> $baseUrl,
								'basePath' 	=> $basePath,				
								'sucMsg' 	=> "Successfully changed the password.",
								'errMsg' 	=> "",
								'ErrorM' 	=> "",
								'data'      => ''
							));
							return $viewModel;			
						}else{
							$viewModel = new ViewModel(
							array(
								'baseUrl'	=> $baseUrl,
								'basePath' 	=> $basePath,				
								'sucMsg' 	=> "Not changed the password .",
								'errMsg' 	=> "",
								'ErrorM' 	=> "",
								'data'      => $_POST
							));
							return $viewModel;
						}		
					}else{
						$viewModel = new ViewModel(
						array(
							'baseUrl'	=> $baseUrl,
							'basePath' 	=> $basePath,				
							'errMsg' 	=> "Your old password is wrong.",
							'sucMsg' 	=> "",
							'ErrorM' 	=> "",
							'data'      => $_POST
						));
						return $viewModel;	
					}
				}else{
					$viewModel = new ViewModel(
					array(
						'baseUrl'	=> $baseUrl,
						'basePath' 	=> $basePath,				
						'ErrorM' 	=> "Entered your Old password and New password is same.",
						'sucMsg' 	=> "",
						'data'      => $_POST
					));
					return $viewModel;	
				}
			}else{
				$viewModel = new ViewModel(
					array(
						'baseUrl'	=> $baseUrl,
						'basePath' 	=> $basePath,
						'sucMsg'	=> "",
						'ErrorM' 	=> "",
						'errMsg' 	=> ""
				));
				return $viewModel;	
			}
		}else{ 
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function viewUserAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		return new viewModel(array(					
			'baseUrl' 		=> 	$baseUrl,
			'basePath'   	=>  $basePath
		));
	}
	
	// Forget password
	public function checkForgotEmailAction()
	{
		$email = "";
		if(isset($_POST['email']) && $_POST['email']!= "")
		{
			$email = $_POST['email'];
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$forgotTable  					= $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');			
		$usersTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');			
		$forgotEmailArr					= $usersTable->checkForgotMailAdmin($email);	
		
		if($forgotEmailArr != "")
		{
			$token = getUniqueCode('10');
			$user_id = $forgotEmailArr['u_id'];
			$checkUserId				= $forgotTable->checkForgotMail($user_id);			
			if(isset($checkUserId['ft_u_id']) && $checkUserId['ft_u_id'] != "" && $checkUserId['ft_u_id'] != 0)
			{
				$uid 			= $checkUserId['ft_u_id'];				
				$updateToken	= $forgotTable->updateForgetpwd($uid,$token);
			}
			else
			{
				$updateToken 		= $forgotTable->addForgetpwd($user_id,$token);
			}
			if(isset($updateToken) && $updateToken != "")
			{
				$to=$forgotEmailArr['u_email'];
				$userName=ucfirst($forgotEmailArr['u_display_name']);
				$user_session = new Container('user');
				$user_session->username=$forgotEmailArr['u_display_name'];
				$user_session->email=$forgotEmailArr['u_email'];
				$user_session->user_id=$forgotEmailArr['u_id'];				
				global $ForgotPassowrdSubject;				
				global $ForgotPasswordMessage;				
				$ForgotPasswordMessage = str_replace("<FULLNAME>",$userName, $ForgotPasswordMessage);
				$ForgotPasswordMessage = str_replace("<PASSWORDLINK>",$baseUrl.'admin/email-reset-pwd?uid='.$user_id.'&token='.$token.'&reset=1', $ForgotPasswordMessage);
				if(sendMail($to,$ForgotPassowrdSubject,$ForgotPasswordMessage)){
					return new JsonModel(array(					
						'output' 	=> 'success'
					));
				}
				else{
					return new JsonModel(array(					
						'output' 	=> 'fail'
					));
				}
				
			}
						
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'check email',				
			));
		}
			
	}
	// Update password for forget password
	public function resetPasswordAction()
	{
		$uid = "";$password = "";
		if(isset($_POST['f_UserId']) && $_POST['f_UserId']!= "")
		{
			$uid 						= $_POST['f_UserId'];
			$password 					= $_POST['f_confirmPass'];
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$forgotTable  					= $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');			
		$usersTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');			
		$delToken						= $forgotTable->deletetoken($uid);		
		if($delToken != 0)
		{
			$updateFgtPass				= $usersTable->updtFgtPass($uid,$password);			
			if($updateFgtPass != "")
			{
				return new JsonModel(array(					
				'output'    	=>  'sucess',				
				));
			}
			else
			{
				return new JsonModel(array(					
				'output'    	=>  'fail',				
				));
			}
		}
		else
		{
			return new JsonModel(array(					
				'output' 	=> 'fail deletion',				
			));
		}	
				
	}
	
	public function checkFgtUidAction()
	{
		$uid = "";$token = "";
		if(isset($_POST['uid']) && $_POST['uid']!= "")
		{
			$uid 						= $_POST['uid'];			
			$token 						= $_POST['token'];			
		}
		$user_session 					= new Container('user');
		$baseUrls 						= $this->getServiceLocator()->get('config');
		$baseUrlArr 					= $baseUrls['urls'];
		$baseUrl 						= $baseUrlArr['baseUrl'];
		$basePath 						= $baseUrlArr['basePath'];
		$forgotTable  					= $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');			
		$usersTable  					= $this->getServiceLocator()->get('Models\Model\UsersFactory');			
		$checkFuid						= $forgotTable->checktoken($uid,$token);		
		if(!empty($checkFuid) && !is_null($checkFuid))
		{
			return new JsonModel(array(					
				'output' 	=> 'sucess',				
			));
		}
		else{
			return new JsonModel(array(					
				'output' 	=> 'fail',				
			));
		}
	}
	
	
}