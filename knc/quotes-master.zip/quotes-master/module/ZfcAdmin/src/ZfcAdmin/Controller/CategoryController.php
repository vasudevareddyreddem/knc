<?php
namespace ZfcAdmin\Controller;
use Zend\Form\Form;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\Authentication\AuthenticationService;
use SanAuthWithDbSaveHandler\Storage\IdentityManagerInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\View\Model\JsonModel;
use Zend\Cache\StorageFactory;
use ScnSocialAuth\Mapper\UserProviderInterface;
class CategoryController extends AbstractActionController
{
	public function indexAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			return new viewModel(array(					
				'baseUrl' 		=> 	$baseUrl,
				'basePath'   	=>  $basePath
			));
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function categoryListsAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$cateList = $categoryTable->appCatList();		
		if(count($cateList)!=0){
			foreach($cateList as $key=>$cat){
				if($cat['qc_cat_pic']!="" && $cat['qc_cat_pic']!=null){
					$imageUrl = $basePath."/categorypics/".$cat['qc_cat_pic'];
				}else{
					$imageUrl = $basePath."/images/category.png";
				}
				$data[$key]['qc_cat_id']     = 	$key+1;
				$data[$key]['qc_cat_pic']    = "<img src='$imageUrl' width='30%' height='30%'>";
				$data[$key]['qc_cat_name']   = 	ucfirst($cat['qc_cat_name']);			
				if($cat['qc_cat_status']=='1'){
					$qc_status	=	'<a href="javascript:void(0);" title="Live" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>';
				}else if($cat['qc_cat_status']=='2'){
					$qc_status						=	'<a href="javascript:void(0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else if($cat['qc_cat_status']=='0'){
					$qc_status				=	'<a href="javascript:void(0);" title="Hidden" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>';
				}
				$name								=	"'".$cat['qc_cat_name']."'";
				$qc_cat_pic							=	"'".$cat['qc_cat_pic']."'";
				$catid								=	$cat['qc_cat_id'];
				$data[$key]['qc_status']          	= 	$qc_status;
				if($cat['qc_cat_status'] =='1'){
					$data[$key]['action'] = '<a href="javascript:void(0);" 
					onclick="viewCategory('.$catid.','.$name.','.$qc_cat_pic.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> </a>
					<a href="javascript:void(0);" onclick="editCategory('.$catid.','.$name.','.$qc_cat_pic.');" 
					class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Hidden" onclick="hideCategory('.$catid.',0);" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteCategory('.$catid.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else{
					$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="viewCategory('.$catid.','.$name.','.$qc_cat_pic.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> 
					<a href="javascript:void(0);" title="Live" onclick="hideCategory('.$catid.',1);" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteCategory('.$catid.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}
		echo json_encode($rclists); exit;
	}
	public function addCategoryAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){		
			$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
			if(isset($_POST['qc_cat_name']) && $_POST['qc_cat_name']!=""){
				$categoryName = $_POST['qc_cat_name'];
				$checkinStatus = $categoryTable->checkCategory($categoryName);			
				if($checkinStatus==0){
					$addedResult = $categoryTable->addCategory($_POST);				
					if($addedResult){
						return new JsonModel(array(					
							'output' 	=> 'success',
						));	
					}
				}else{
					return new JsonModel(array(					
						'output' 	=> 'alreadyexists',
					));	
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateCategoryAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
			if(isset($_POST['qc_cat_name']) && $_POST['qc_cat_name']!=""){
				$categoryName = $_POST['qc_cat_name'];
				$cat_id       = $_POST['qc_cat_id'];
				$checkinStatus = $categoryTable->checkCategoryData($categoryName,$cat_id);
				if($checkinStatus!=0){
					$updatedResult = $categoryTable->updateCategory($_POST);
					if($updatedResult){
						return new JsonModel(array(					
							'output' 	=> 'success',
						));	
					}
				}else{
					$checkingStatus = $categoryTable->checkCategory($categoryName);
					if($checkingStatus==0){
						$updatedResult = $categoryTable->updateCategory($_POST);
						if($updatedResult){
							return new JsonModel(array(					
								'output' 	=> 'success',
							));	
						}
					}else{
						return new JsonModel(array(					
							'output' 	=> 'alreadyexists',
						));	
					}
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateCategoryStatusAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');	
		if(isset($_POST['qc_cat_id']) && $_POST['qc_cat_id']!=""){
			$qc_cat_id = $_POST['qc_cat_id'];
			$statuMode = $_POST['status'];
			$catQuotesCnt = 0;
			if($statuMode==2){
				$catQuotesCnt = $quoteCategoriesTable->catQuotesCnt($qc_cat_id);
				if($catQuotesCnt>0){
					return new JsonModel(array(					
						'output' 	      => 'success',
						'catQuotesCnt'    => $catQuotesCnt,
					));	
				}else{
					$deleResult = $categoryTable->deleteCat($qc_cat_id);
					if($deleResult){
						return new JsonModel(array(					
							'output' 	      => 'success',
							'catQuotesCnt'    => $catQuotesCnt,
						));	
					}
				}
			}else{
				$statusResult = $categoryTable->updateCategoryStatus($qc_cat_id,$statuMode);
				if($statusResult){
					return new JsonModel(array(					
						'output' 	    => 'success',
						'catQuotesCnt' 	=> $catQuotesCnt,
					));	
				}
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}	 
	}
	public function categoryUploadPicAction(){
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		if(isset($_GET['type']) && $_GET['type']!=""){
			$temp = explode(".", $_FILES[$_GET['type']]["name"]);
			$name = date('Ymd') ."_". date("His") .'.' . end($temp);
			$newfilenamePath = "./public/categorypics/".$name;			
			$Pic = $basePath."/categorypics/".$name;			
			if (move_uploaded_file($_FILES[$_GET['type']]["tmp_name"], $newfilenamePath)){
				return new JsonModel(array(					
					'imageName' => 	$name,
					'Pic' => $Pic
				));
			}
		}else{
			return $viewModel = new ViewModel(
				array(
					'baseUrl'				 	=> $baseUrl,
					'basePath' 					=> $basePath,
			));	
		}	
	}
}