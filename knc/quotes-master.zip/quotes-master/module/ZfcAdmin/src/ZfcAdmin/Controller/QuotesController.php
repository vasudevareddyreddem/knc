<?php
namespace ZfcAdmin\Controller;
use Zend\Form\Form;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\Authentication\AuthenticationService;
use SanAuthWithDbSaveHandler\Storage\IdentityManagerInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\View\Model\JsonModel;
use Zend\Cache\StorageFactory;
use ScnSocialAuth\Mapper\UserProviderInterface;
class QuotesController extends AbstractActionController
{
	public function indexAction()
	{
			
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			return new viewModel(array(					
				'baseUrl' 		=> 	$baseUrl,
				'basePath'   	=>  $basePath
			));
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function quotesUploadPicAction(){
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		if(isset($_GET['type']) && $_GET['type']!=""){
			$temp = explode(".", $_FILES[$_GET['type']]["name"]);
			$name = date('Ymd') ."_". date("His") .'.' . end($temp);
			$newfilenamePath = "./quotes/".$name;			
			if (move_uploaded_file($_FILES[$_GET['type']]["tmp_name"], $newfilenamePath)){
				return new JsonModel(array(					
					'imageName' => 	$name
				));
			}
		}else{
			return $viewModel = new ViewModel(
				array(
					'baseUrl'				 	=> $baseUrl,
					'basePath' 					=> $basePath,
			));	
		}
	}	
	function categoriesList($qc_id){
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$categoires = $quoteCategoriesTable->getCategories($qc_id);
		$cat = "";
		$cat_names = "";    
		foreach($categoires as $key=>$cat){
			$cat_names .= ucfirst($cat['qc_cat_name'].',');
			$cat = rtrim($cat_names, ',');					
		}	
		return $cat;
	}
	public function quotesListAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			return new ViewModel(array(					
				'output' 	    => 'success',
				'baseUrl'       => $baseUrl,
				'basePath'      => $basePath,
			));
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function quoteslistajaxAction(){
		// echo $baseUrl;exit;
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$quotesList   = $quotesTable->adminsidequotesList();	
		if(count($quotesList)!=0){
			foreach($quotesList as $key=>$quote){
				$qc_id		=	$quote['qc_id'];
				$cat = $this->categoriesList($qc_id);
				if($quote['qc_quote_of_day_date']!=""){
					$qc_quote_of_day      = strtotime($quote['qc_quote_of_day_date']);
					$qc_quote_of_day_date = date("Y-m-d", $qc_quote_of_day);
				}else{
					$qc_quote_of_day_date = "";
				}
				$data[$key]['qc_qc_cat_id']    = $cat;		
				$data[$key]['qc_id']           = $key+1;
				$data[$key]['qc_au_id']        = ucfirst($quote['au_fname'].' '.$quote['au_lname']);				
				$data[$key]['qc_name']         = $quote['qc_name'];
				$data[$key]['qc_quote_of_day_date'] = $qc_quote_of_day_date;
				$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="setquoteoftheday('.$qc_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y">Set Quote</i>';
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}
		echo json_encode($rclists); exit;
	}
	public function quoteinfoajaxAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		if(isset($_POST['qc_id']) && $_POST['qc_id']!=""){
			$qc_id = $_POST['qc_id'];
			$quotesList   = $quotesTable->getQuoteData($qc_id);
			if(isset($quotesList->qc_id) && $quotesList->qc_id!=""){
				$qc_name = $quotesList->qc_name;
				$qc_quote_of_day      = strtotime($quotesList->qc_quote_of_day_date);
				if($qc_quote_of_day!=""){
					$qc_quote_of_day_date = date("Y-m-d", $qc_quote_of_day);
				}else{
					$qc_quote_of_day_date = "";
				}
				return new JsonModel(array(					
					'qc_name'             => 	$qc_name,
					'qc_quote_of_day_date' => 	$qc_quote_of_day_date
				));
			}
		}
			
	}
	public function postquoteinfoAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		if(isset($_POST['qc_id']) && $_POST['qc_id']!=""){
			$qc_id   = $_POST['qc_id'];
			$dateqfd = $_POST['dateqfd'];
			$quotesList   = $quotesTable->getQuoteData($qc_id);
			if(isset($quotesList->qc_id) && $quotesList->qc_id!=""){
				$qc_quote_of_day      = strtotime($quotesList->qc_quote_of_day_date);
				$qc_quote_of_day_date = date("Y-m-d", $qc_quote_of_day);
				if($dateqfd == $qc_quote_of_day_date ){
					return new JsonModel(array(					
						'setdatequofday'      => 	'alreadsameset',
					));
				}else{
					$updatesetqfday   = $quotesTable->setquoteofthedayadmin($qc_id,$dateqfd);
					return new JsonModel(array(					
						'setdatequofday'      => 	'success',
					));
				}
			}
		}
	}
	public function quotesListsAction(){
		// echo $baseUrl;exit;
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$quotesList   = $quotesTable->adminquotesList();	
		if(count($quotesList)!=0){
			foreach($quotesList as $key=>$quote){
				$qc_id		=	$quote['qc_id'];
				$cat = $this->categoriesList($qc_id);
				$data[$key]['qc_qc_cat_id']    = $cat;		
				if(isset($quote['qc_image']) && $quote['qc_image']!="" && $quote['qc_image']!=null){
					$imageUrl = $basePath."/quotes/".$quote['qc_image'];
				}else{
					$imageUrl = $basePath."/images/category.png";
				}
				$qc_status = "";
				$data[$key]['qc_id']           = $key+1;
				$data[$key]['qc_image']        = "<img src='$imageUrl' width='30%' height='30%'>";
				$data[$key]['qc_au_id']        = ucfirst($quote['au_fname'].' '.$quote['au_lname']);				
				$data[$key]['qc_lang_id']      = $quote['lang_name'];
				$data[$key]['qc_name']         = $quote['qc_name'];
				if($quote['qc_status']=='1'){
					$qc_status	=	'<a href="javascript:void(0);" title="Live" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>';
				}else if($quote['qc_status']=='2'){
					$qc_status ='<a href="javascript:void(0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else if($quote['qc_status']=='0'){
					$qc_status='<a href="javascript:void(0);" title="Hidden" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>';
				}					
				$editUrl = $baseUrl.'admin/update-quote?qcid='.base64_encode($qc_id.'quotes'.$qc_id);
				$data[$key]['qc_status'] = 	$qc_status;
				if($quote['qc_status'] =='1'){
					$data[$key]['action'] = '<a href="javascript:void(0);" 
					onclick="viewQuote('.$qc_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> </a>
					<a href="'.$editUrl.'" class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Hidden" onclick="hideQuote('.$qc_id.',0,0);" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteQuote('.$qc_id.',2,0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
					if($quote['qc_approved'] == 1){
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Deny" onclick="approveQuote('.$qc_id.',4,0,0);" title="Deny" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-times-circle"></i></a>';
					}else{
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Approve" onclick="approveQuote('.$qc_id.',5,0,0);" title="Approve" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-check-circle"></i></a>';
					}
				}else{
					$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="viewQuote('.$qc_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i>
					</a><a href="'.$editUrl.'" class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Live" onclick="hideQuote('.$qc_id.',1,0);" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteQuote('.$qc_id.',2,0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
					if($quote['qc_approved'] == 1){
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Deny" onclick="approveQuote('.$qc_id.',4,0,0);" title="Deny" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-times-circle"></i></a>';
					}else{
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Approve" onclick="approveQuote('.$qc_id.',5,0,0);" title="Approve" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-check-circle"></i></a>';
					}
				}					
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}
		echo json_encode($rclists); exit;
	}
	public function userQuotesAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){		
			return new ViewModel(array(					
				'output' 	    => 'success',
				'baseUrl'       => $baseUrl,
				'basePath'      => $basePath,
			));	
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	//User Quotes List Action 
	public function userQuotesListsAction(){
		// echo $baseUrl;exit;
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$quotesList   = $quotesTable->adminquotesUserList();	
		if(count($quotesList)!=0){
			foreach($quotesList as $key=>$quote){
				$qc_id		=	$quote['qc_id'];
				$cat = $this->categoriesList($qc_id);
				$data[$key]['qc_qc_cat_id']    = $cat;		
				if(isset($quote['qc_image']) && $quote['qc_image']!="" && $quote['qc_image']!=null){
					$imageUrl = $basePath."/quotes/".$quote['qc_image'];
				}else{
					$imageUrl = $basePath."/images/category.png";
				}
				$qc_status = "";
				$data[$key]['qc_id']           = $key+1;
				$data[$key]['qc_image']        = "<img src='$imageUrl' width='30%' height='30%'>";
				if(isset($quote['au_fname']) && $quote['au_fname'] != ""){
					$data[$key]['qc_au_id']        = ucfirst($quote['au_fname'].' '.$quote['au_lname']);
				}else{
					$data[$key]['qc_au_id']        = "";
				}
								
				$data[$key]['qc_lang_id']      = $quote['lang_name'];
				$data[$key]['qc_name']         = $quote['qc_name'];
				if($quote['qc_status']=='1'){
					$qc_status	=	'<a href="javascript:void(0);" title="Live" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>';
				}else if($quote['qc_status']=='2'){
					$qc_status ='<a href="javascript:void(0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else if($quote['qc_status']=='0'){
					$qc_status='<a href="javascript:void(0);" title="Hidden" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>';
				}					
				$editUrl = $baseUrl.'admin/update-quote?qcid='.base64_encode($qc_id.'quotes'.$qc_id.'quotes'.'1');
				$data[$key]['qc_status'] = 	$qc_status;
				
				$email 	= "'".$quote['u_email']."'";
				
				if($quote['qc_status'] =='1'){
					$data[$key]['action'] = '<a href="javascript:void(0);" 
					onclick="viewQuote('.$qc_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> </a>
					<a href="'.$editUrl.'" title="Edit" class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Hidden" onclick="hideQuote('.$qc_id.',0,1);" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteQuote('.$qc_id.',2,1);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
					if($quote['qc_approved'] == 1){
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Deny" onclick="approveQuote('.$qc_id.',4,1,'.$email.');" title="Deny" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-times-circle"></i></a>';
					}else{
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Approve" onclick="approveQuote('.$qc_id.',5,1,'.$email.');" title="Approve" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-check-circle"></i></a>';
					}
				}else{
					$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="viewQuote('.$qc_id.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i>
					</a><a href="'.$editUrl.'" title="Edit" class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Live" onclick="hideQuote('.$qc_id.',1,1);" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteQuote('.$qc_id.',2,1);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
					if($quote['qc_approved'] == 1){
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Deny" onclick="approveQuote('.$qc_id.',4,1,'.$email.');" title="Deny" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-times-circle"></i></a>';
					}else{
						$data[$key]['action'] .='<a href="javascript:void(0);" title="Approve" onclick="approveQuote('.$qc_id.',5,1,'.$email.');" title="Approve" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-check-circle"></i></a>';
					}
				}					
			}
			$qclists['aaData'] = $data;
		}else{
			$qclists['aaData'] = array();		
		}
		echo json_encode($qclists); exit;
	}
	
	public function addQuoteAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
			$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
			$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
			$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
			$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
			if(isset($_POST['qc_au_id']) && $_POST['qc_au_id']!=""){
				$addedResult = $quotesTable->addQuote($_POST);
				if($addedResult){
					$addCategories = $quoteCategoriesTable->addQuotecategories($_POST['qc_qc_cat_id'],$addedResult);
					return new JsonModel(array(					
						'output' 	=> 'success',
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'alreadyexists',
					));	
				}
			}else{
				$authorsList = $authorTable->authorsList();		
				if(count($authorsList)!=0){
					escape_arr($authorsList);
				}else{
					$authorsList = "";
				}
				$cateList = $categoryTable->adminCategoriesList();		
				if(count($cateList)!=0){
					escape_arr($cateList);
				}else{
					$cateList = "";
				}
				$langsList = $languageTable->languagesList();		
				if(count($langsList)!=0){
					escape_arr($langsList);
				}else{
					$langsList = "";
				}
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath,
					'authorArray'   =>  $authorsList,
					'catArray'      =>  $cateList,
					'langArray'     =>  $langsList,
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateQuoteAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
			$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
			$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
			$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
			if(isset($_POST['qc_id']) && $_POST['qc_id']!=""){
				$id = $_POST['qc_id'];
				$updatedResult = $quotesTable->updateQuote($_POST,$id);
				$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
				$addCategories = $quoteCategoriesTable->addQuotecategories($_POST['qc_qc_cat_id'],$id);
				if($updatedResult){
					return new JsonModel(array(					
						'output' 	=> 'success',
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'alreadyexists',
					));	
				}
			}else if(isset($_GET['qcid']) && $_GET['qcid']!=""){
				$qcid = base64_decode($_GET['qcid']);
				$explodeData = explode('quotes',$qcid);
				$qc_id = $explodeData[0];
				$getQuoteData = $quotesTable->getQuoteData($qc_id);
				$authorsList  = $authorTable->authorsList();	
			// 	$cat = $this->categoriesList($qc_id);	
				if(count($authorsList)!=0){
					escape_arr($authorsList);
				}else{
					$authorsList = "";
				}
				$cateList = $categoryTable->adminCategoriesList();		
				if(count($cateList)!=0){
					escape_arr($cateList);
				}else{
					$cateList = "";
				}
				$langsList = $languageTable->languagesList();		
				if(count($langsList)!=0){
					escape_arr($langsList);
				}else{
					$langsList = "";
				}
				$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
				$categoires = $quoteCategoriesTable->getCategories($qc_id);
				$cat_ids ="";
				foreach($categoires as $key=>$cat){				
					$cat_ids[$cat['qcat_qc_cat_id']] = $cat['qcat_qc_cat_id'];
					escape_arr($cat_ids);
				}	
				if($getQuoteData!=""){				
					return new ViewModel(array(					
						'output' 	    => 'success',
						'quoteData'     => $getQuoteData,
						'categoires'     => $cat_ids,
						'baseUrl'       => $baseUrl,
						'basePath'      => $basePath,
						'authorArray'   =>  $authorsList,
						'catArray'      =>  $cateList,
						'langArray'     =>  $langsList,
					));	
				}else{
					return new ViewModel(array(					
						'output' 	    => 'fail',
						'quoteData'     => '',
						'categoires'    => '',
						'authorArray'   =>  $authorArray,
						'catArray'      =>  $catArray,
						'langArray'     =>  $langArray,
					));	
				}
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function viewQuoteAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$getQuoteData ="";
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			if(isset($_POST['qc_id']) && $_POST['qc_id']!=""){
				$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
				$qc_id = $_POST['qc_id'];
				$getQuoteData = $quotesTable->getQuoteData($qc_id);
				$cat = $this->categoriesList($qc_id);
				if($getQuoteData!=""){
					// escape_arr($getQuoteData);
					// escape_arr($cat);
					return new JsonModel(array(					
						'output' 	 => 'success',
						'getQuote'   => $getQuoteData,
						'categories' => $cat,
					));	
				}else{
					return new JsonModel(array(					
						'output' 	  => 'fail',
						'getQuote'    => '',
						'categories'  => '',
					));	
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateQuoteStatusAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		if(isset($_POST['qc_id']) && $_POST['qc_id']!=""){
			$qc_id = $_POST['qc_id'];
			$statuMode = $_POST['status'];
			if(isset($_POST['status']) && $_POST['status']==2){				
				$deleStatus   = $quoteCategoriesTable->deleteQuoteCategories($qc_id);
				$statusResult = $quotesTable->deleteQuote($qc_id);
			}else{
				$statusResult = $quotesTable->updateQuotesStatus($statuMode,$qc_id);
			}	
			return new JsonModel(array(					
				'output' 	=> 'success',
			));				
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}
	}
	//Approve quote status 
	public function approveQuoteStatusAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		
		$qc_id 		  = $_POST['qc_id'];
		$statuMode    = $_POST['status'];
		$statusResult = $quotesTable->updateQuotesApproveStatus($statuMode,$qc_id);
		if($statuMode == 4){
			global $userRejectQuoteSubject;
			global $userRejectQuoteMessage;
			
			$userRejectQuoteSubject 	= $userRejectQuoteSubject;
			$userRejectQuoteMessage 	= $userRejectQuoteMessage;
			$to				  		= $_POST['userEmail'];
			// $to				  	= 'naveenleela3@gmail.com,syaramala@aapthitech.com';
			 //echo $userRejectQuoteMessage; exit;
			if(sendMail($to,$userRejectQuoteSubject,$userRejectQuoteMessage)){
				return new JsonModel(array(					
					'output' 	=> 'success',
				));	
			}
		}else{
			global $userAcceptQuoteSubject;
			global $userAcceptQuoteMessage;
			
			$userAcceptQuoteSubject 	= $userAcceptQuoteSubject;
			$userAcceptQuoteMessage 	= $userAcceptQuoteMessage;
			$to	= $_POST['userEmail'];
			// $to				  	= 'naveenleela3@gmail.com,syaramala@aapthitech.com';
			 //echo $userAcceptQuoteMessage; exit;
			if(sendMail($to,$userAcceptQuoteSubject,$userAcceptQuoteMessage)){
				return new JsonModel(array(					
					'output' 	=> 'success',
				));	
			}
		}
	} 
	public function uploadProfileImageAction(){
		
		if($_POST['add_quote_hid'] == 1)
		{
			$fileExtentios     = explode(".", $_FILES["fileCropInp"]["name"]);
			$extention         = strtolower(end($fileExtentios));
			switch($extention){
				case 'jpg' :case 'jpeg': case 'jpe': case 'png': case 'gif':
				if(isset($_FILES) && isset($_FILES['fileCropInp']['name'])){
					@unlink('./public/uploads/'.$_POST['imageId']);
					$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
					$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
					$croppedX 			= 	$_POST['croppedX'];
					$croppedY 			= 	$_POST['croppedY'];
					$image 				= 	stripslashes($_FILES['fileCropInp']['name']);
					$temp 				= 	explode(".", $_FILES["fileCropInp"]["name"]);
					$extension 			= 	strtolower(end($temp));
					$uploadedfile		=	$_FILES['fileCropInp']['tmp_name'];
					
					if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
						$src = imagecreatefromjpeg($uploadedfile);
					}
					else if($extension=="png"){
						$src = imagecreatefrompng($uploadedfile);
					}
					else{
						$src = imagecreatefromgif($uploadedfile);
					}
					
					list($width,$height)	=	getimagesize($uploadedfile);
					$tmp					=	imagecreatetruecolor(200,200);
					imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,200,200,$croppedNewWidth,$croppedNewHeight);
					
					$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
					$newfilenamePath = "./public/uploads/".$imageName;
					imagejpeg($tmp,$newfilenamePath,100);
					imagedestroy($tmp);
					imagedestroy($src);
					$user_session 			= 	new Container('admin');
					
					if($user_session->userId == $_POST['quote_id']){
						$user_session->profile  =   $imageName;
					}
					/* $userTable  = 	$this->getServiceLocator()->get('Models\Model\QuotesFactory');
					$result		=	$userTable->updateUserProfileImage($imageName,$_POST['quote_id']); */
					escape_str($imageName);
					return $view = new JsonModel(array(
						'output'  		=> 1,
						'imageName' 	=> $imageName
					));
					}
				break;
				default:
				return $view = new JsonModel(array(
					'output'          => 0,
					'message'          => 'The given extension is not allowed.',
				));
				break;
			}
		}
		else
		{
			
			$fileExtentios     = explode(".", $_FILES["fileCropInp"]["name"]);
			$extention         = strtolower(end($fileExtentios));
			switch($extention){
				case 'jpg' :case 'jpeg': case 'jpe': case 'png': case 'gif':
				if(isset($_FILES) && isset($_FILES['fileCropInp']['name'])){
					@unlink('./public/uploads/'.$_POST['imageId']);
					$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
					$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
					$croppedX 			= 	$_POST['croppedX'];
					$croppedY 			= 	$_POST['croppedY'];
					$image 				= 	stripslashes($_FILES['fileCropInp']['name']);
					$temp 				= 	explode(".", $_FILES["fileCropInp"]["name"]);
					$extension 			= 	strtolower(end($temp));
					$uploadedfile		=	$_FILES['fileCropInp']['tmp_name'];
					
					if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
						$src = imagecreatefromjpeg($uploadedfile);
					}
					else if($extension=="png"){
						$src = imagecreatefrompng($uploadedfile);
					}
					else{
						$src = imagecreatefromgif($uploadedfile);
					}
					
					list($width,$height)	=	getimagesize($uploadedfile);
					$tmp					=	imagecreatetruecolor(200,200);
					imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,200,200,$croppedNewWidth,$croppedNewHeight);
					
					$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
					$newfilenamePath = "./public/uploads/".$imageName;
					imagejpeg($tmp,$newfilenamePath,100);
					imagedestroy($tmp);
					imagedestroy($src);
					$user_session 			= 	new Container('admin');
					
					if($user_session->userId == $_POST['quote_id']){
						$user_session->profile  =   $imageName;
					}
					/*$userTable  = 	$this->getServiceLocator()->get('Models\Model\QuotesFactory');
					$result		=	$userTable->updateUserProfileImage($imageName,$_POST['quote_id']);*/
					escape_str($imageName);
					return $view = new JsonModel(array(
						'output'  		=> 1,
						'imageName' 	=> $imageName
					));
					}
				break;
				default:
				return $view = new JsonModel(array(
					'output'          => 0,
					'message'          => 'The given extension is not allowed.',
				));
				break;
			}
		}
		
	}
	public function quoteofthedayAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			return new ViewModel(array(					
				'output' 	    => 'success',
				'baseUrl'       => $baseUrl,
				'basePath'      => $basePath,
			));	
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function quoteofthedayajaxAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$quotesList   = $quotesTable->adminquoteoftheday();	
		if(count($quotesList)!=0){
			foreach($quotesList as $key=>$quote){
				$qc_id		=	$quote->qc_id;
				$cat = $this->categoriesList($qc_id);
				$qc_quote_of_day = strtotime($quote->qc_quote_of_day_date);
				$qc_quote_of_day_date = date("Y-m-d", $qc_quote_of_day);
				// $mydate=getdate($qc_quote_of_day_date);
				// echo "$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]";
				$data[$key]['qc_qc_cat_id']         = $cat;	
				$data[$key]['qc_id']                = $key+1;
				$data[$key]['qc_au_id']             = ucfirst($quote->au_fname.' '.$quote->au_lname);				
				$data[$key]['qc_name']              = $quote->qc_name;
				$data[$key]['qc_quote_of_day_date'] = $qc_quote_of_day_date;
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}
		echo json_encode($rclists); exit;
	}
}