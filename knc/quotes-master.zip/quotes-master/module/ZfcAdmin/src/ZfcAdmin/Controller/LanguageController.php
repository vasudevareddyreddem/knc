<?php
namespace ZfcAdmin\Controller;
use Zend\Form\Form;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\Authentication\AuthenticationService;
use SanAuthWithDbSaveHandler\Storage\IdentityManagerInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\View\Model\JsonModel;
use Zend\Cache\StorageFactory;
use ScnSocialAuth\Mapper\UserProviderInterface;
class LanguageController extends AbstractActionController
{
	public function indexAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			return new viewModel(array(					
				'baseUrl' 		=> 	$baseUrl,
				'basePath'   	=>  $basePath
			));
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function languageListsAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];	
		$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
		$langsList = $languageTable->languagesList();		
		if(count($langsList)!=0){
			foreach($langsList as $key=>$lang){
				$data[$key]['lang_id']     = 	$key+1;
				$data[$key]['lang_name']   = 	ucfirst($lang['lang_name']);
				if($lang['lang_status']=='1'){
					$lang_status	=	'<a href="javascript:void(0);" title="Live" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>';
				}else if($lang['lang_status']=='2'){
					$lang_status						=	'<a href="javascript:void(0);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else if($lang['lang_status']=='0'){
					$lang_status				=	'<a href="javascript:void(0);" title="Hidden" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>';
				}
				$name								=	"'".$lang['lang_name']."'";
				$langid								=	$lang['lang_id'];
				$data[$key]['lang_status']          = 	$lang_status;
				if($lang['lang_status'] =='1'){
					$data[$key]['action'] = '<a href="javascript:void(0);" 
					onclick="viewLanguage('.$langid.','.$name.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> </a>
					<a href="javascript:void(0);" onclick="editLanguage('.$langid.','.$name.');" 
					class="color_b" data-toggle="tooltip" data-placement="top"><i class="fa fa-edit"></i> </a>
					<a href="javascript:void(0);" title="Hidden" onclick="hideLanguage('.$langid.',0);" data-toggle="tooltip" data-placement="top" class="color_r"><i class="fa fa-times-circle"></i></a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteLanguage('.$langid.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}else{
					$data[$key]['action']  = '<a href="javascript:void(0);" 
					onclick="viewLanguage('.$langid.','.$name.');" title="View" data-toggle="tooltip" data-placement="top" class="color_y"><i class="fa fa-eye"></i> 
					<a href="javascript:void(0);" title="Live" onclick="hideLanguage('.$langid.',1);" data-toggle="tooltip" data-placement="top" class="color_g"><i class="fa fa-check-circle"></i> </a>
					<a href="javascript:void(0);" title="Delete" onclick="deleteLanguage('.$langid.',2);" title="Delete" data-toggle="tooltip" data-placement="top" style="color:red"><i class="fa fa-trash-o"></i></a>';
				}
			}
			$rclists['aaData'] = $data;
		}else{
			$rclists['aaData'] = array();		
		}
		echo json_encode($rclists); exit;
	
	}
	public function addLanguageAction()
	{
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){	
			$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
			if(isset($_POST['lang_name']) && $_POST['lang_name']!=""){
				$lang_name = $_POST['lang_name'];
				$checkinStatus = $languageTable->checkLanguage($lang_name);
				if($checkinStatus==0){
					$addedResult = $languageTable->addLanguage($_POST);
					if($addedResult){
						return new JsonModel(array(					
							'output' 	=> 'success',
						));	
					}
				}else{
					return new JsonModel(array(					
						'output' 	=> 'alreadyexists',
					));	
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateLanguageAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];		
		$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
		$admin_session 	= 	new Container('admin');	
		if(isset($_SESSION["admin"]["user_id"]) && $_SESSION["admin"]["user_id"]!=""){
			if(isset($_POST['lang_name']) && $_POST['lang_name']!=""){
				$lang_name = $_POST['lang_name'];
				$lang_id       = $_POST['lang_id'];
				$checkinStatus = $languageTable->checkLanguageData($lang_name,$lang_id);
				if($checkinStatus!=0){
					$updatedResult = $languageTable->updateLanguage($_POST,$lang_id);
					if($updatedResult){
						return new JsonModel(array(					
							'output' 	=> 'success',
						));	
					}
				}else{
					$checkingStatus = $languageTable->checkLanguage($lang_name);
					if($checkingStatus==0){
						$updatedResult = $languageTable->updateLanguage($_POST,$lang_id);
						if($updatedResult){
							return new JsonModel(array(					
								'output' 	=> 'success',
							));	
						}
					}else{
						return new JsonModel(array(					
							'output' 	=> 'alreadyexists',
						));	
					}
				}
			}else{
				return new viewModel(array(					
					'baseUrl' 		=> 	$baseUrl,
					'basePath'   	=>  $basePath
				));
			}
		}else{
			return $this->redirect()->toUrl($baseUrl);
		}
	}
	public function updateLanguageStatusAction(){
		$baseUrls 	   = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl 	   = $baseUrlArr['baseUrl'];
		$basePath 	   = $baseUrlArr['basePath'];
		$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		if(isset($_POST['lang_id']) && $_POST['lang_id']!=""){
			$lang_id = $_POST['lang_id'];
			$statuMode = $_POST['status'];
			$langQuotesCnt = 0;
			if($statuMode==2){
				$langQuotesCnt = $quotesTable->langQuotesCnt($lang_id);
				if($langQuotesCnt>0){
					return new JsonModel(array(					
						'output' 	      => 'success',
						'langQuotesCnt'   => $langQuotesCnt,
					));	
				}else{
					$deleResult = $languageTable->deleteLang($lang_id);
					if($deleResult){
						return new JsonModel(array(					
							'output' 	      => 'success',
							'langQuotesCnt'   => $langQuotesCnt,
						));	
					}
				}
			}else{
				$statusResult = $languageTable->updateLanguageStatus($lang_id,$statuMode);
				if($statusResult){
					return new JsonModel(array(					
						'output' 	        => 'success',
						'langQuotesCnt' 	=> $langQuotesCnt,
					));	
				}
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));
		}	
	} 
}