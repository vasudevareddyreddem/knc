<?php
return array(
	'controller_plugins' => array(
		'invokables' => array(
		   'Adminplugin' => 'ZfcAdmin\Controller\Plugin\Adminplugin',
		 )
	 ),
    'controllers' => array(
        'invokables' => array(
            'ZfcAdmin\Controller\AdminController'      => 'ZfcAdmin\Controller\AdminController',
			'ZfcAdmin\Controller\UserController'       => 'ZfcAdmin\Controller\UserController',
			'ZfcAdmin\Controller\AuthorController'     => 'ZfcAdmin\Controller\AuthorController',
			'ZfcAdmin\Controller\CategoryController'   => 'ZfcAdmin\Controller\CategoryController',
			'ZfcAdmin\Controller\LanguageController'   => 'ZfcAdmin\Controller\LanguageController',		
			'ZfcAdmin\Controller\QuotesController'     => 'ZfcAdmin\Controller\QuotesController',
        ),
    ),
    'zfcadmin' => array(
        'use_admin_layout'      => true,
        'admin_layout_template' => 'layout/admin',
    ),
    'navigation' => array(
        'admin' => array(),
    ),
    'router' => array(
        'routes' => array(
            'zfcadmin' => array(
                'type' => 'literal',
                'options' => array(
                    'route'    => '/admin',
                    'defaults' => array(
                        'controller' => 'ZfcAdmin\Controller\AdminController',
                        'action'     => 'index',
                    ),
                ),
				'may_terminate' => true,
				'child_routes' => array(					
					'admin-logout' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route'    => '/admin-logout',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AdminController',
                                'action'     => 'adminLogout',
                            ),
                        ),
                    ),					
					'check-email-mail' => array(
						'type' => 'literal',
						'options' => array(
							'route'    => '/check-email-mail',
							'constraints' => array(
							   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
							),
							'defaults' => array(
								'controller' => 'ZfcAdmin\Controller\UserController',
								'action'     => 'checkForgotEmail',
							),
						),
					),										
					
					'reset-password' => array(
						'type' => 'literal',
						'options' => array(
							'route'    => '/reset-password',
							'constraints' => array(
							   'id' => '[%&;a-zA-Z0-9][%&+;a-zA-Z0-9_~-]*',
							),
							'defaults' => array(
								'controller' => 'ZfcAdmin\Controller\UserController',
								'action'     => 'resetPassword',
							),
						),
					),
					
					'check-fuid' => array(
						'type' => 'segment',
						'options' => array(
							'route'    => '/check-fuid',
							'defaults' => array(
								'controller' => 'ZfcAdmin\Controller\UserController',
								'action'     => 'checkFgtUid',
							),
						),
					),
					
					'email-reset-pwd' => array(
						'type' => 'segment',
						'options' => array(
							'route'    => '/email-reset-pwd',
							'defaults' => array(
								'controller' => 'ZfcAdmin\Controller\UserController',
								'action'     => 'checkingLogin',
							),
						),
					),
					
					'change-password' => array(
						'type' => 'segment',
						'options' => array(
							'route'    => '/change-password',
							'defaults' => array(
								'controller' => 'ZfcAdmin\Controller\UserController',
								'action'     => 'changePassword',
							),
						),
					),
					'checking-login' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/checking-login',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AdminController',
                                'action'     => 'checkingLogin',
                            ),
                        ),
                    ),
					'category-upload-pic' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/category-upload-pic',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'categoryUploadPic',
                            ),
                        ),
                    ),
					// Quotes management mapped config urls
					'quotes-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quotes-management[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'quotes-list' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quotes-list[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'quotesList',
                            ),
                        ),
                    ),
					//User Quotes list 
					
					'user-quotes' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/user-quotes[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'userQuotes',
                            ),
                        ),
                    ),
					'user-quotes-lists' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/user-quotes-lists[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'userQuotesLists',
                            ),
                        ),
                    ),
					//End 
					'approve-quote-status' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/approve-quote-status[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'approveQuoteStatus',
                            ),
                        ),
                    ),
					'quoteslistajax' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quoteslistajax[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'quoteslistajax',
                            ),
                        ),
                    ),
					'quoteinfoajax' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quoteinfoajax[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'quoteinfoajax',
                            ),
                        ),
                    ),
					'postquoteinfo' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/postquoteinfo[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'postquoteinfo',
                            ),
                        ),
                    ),
					'add-quote' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/add-quote[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'addQuote',
                            ),
                        ),
                    ),
					'quoteoftheday' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quoteoftheday[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'quoteoftheday',
                            ),
                        ),
                    ),
					'quoteofthedayajax' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quoteofthedayajax[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'quoteofthedayajax',
                            ),
                        ),
                    ),
					'quotes-lists' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/quotes-lists[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'quotesLists',
                            ),
                        ),
                    ),
					'view-quote' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/view-quote[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'viewQuote',
                            ),
                        ),
                    ),
					'update-quote' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-quote[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'updateQuote',
                            ),
                        ),
                    ),
					'update-quote-status' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-quote-status[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'updateQuoteStatus',
                            ),
                        ),
                    ),
					// Language management mapped config urls
					'language-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/language-management[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\LanguageController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'language-lists' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/language-lists[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\LanguageController',
                                'action'     => 'languageLists',
                            ),
                        ),
                    ),
					'update-language-status' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-language-status[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\LanguageController',
                                'action'     => 'updateLanguageStatus',
                            ),
                        ),
                    ),
					'add-language' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/add-language[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\LanguageController',
                                'action'     => 'addLanguage',
                            ),
                        ),
                    ),
					'view-language' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/view-language[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\LanguageController',
                                'action'     => 'viewLanguage',
                            ),
                        ),
                    ),
					'update-language' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-language[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\LanguageController',
                                'action'     => 'updateLanguage',
                            ),
                        ),
                    ),
					// Author management mapped config urls
					'author-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/author-management[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'add-author' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/add-author[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'addAuthor',
                            ),
                        ),
                    ),
					'author-upload-pic' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/author-upload-pic[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'authorUploadPic',
                            ),
                        ),
                    ),
					'author-lists' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/author-lists[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'authorLists',
                            ),
                        ),
                    ),
					'view-author' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/view-author[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'viewAuthor',
                            ),
                        ),
                    ),
					'update-author' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-author[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'updateAuthor',
                            ),
                        ),
                    ),
					'update-author-status' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-author-status[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AuthorController',
                                'action'     => 'updateAuthorStatus',
                            ),
                        ),
                    ),
					// Category management mapped config urls
					'category-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/category-management[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'category-lists' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/category-lists[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'categoryLists',
                            ),
                        ),
                    ),
					'add-category' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/add-category[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'addCategory',
                            ),
                        ),
                    ),
					'view-category' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/view-category[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'viewCategory',
                            ),
                        ),
                    ),
					'update-category' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-category[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'updateCategory',
                            ),
                        ),
                    ),
					'update-category-status' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-category-status[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CategoryController',
                                'action'     => 'updateCategoryStatus',
                            ),
                        ),
                    ),
					// User management mapped config urls
					'user-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/user-management[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'view-user-admin' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/view-user-admin[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'viewUserAdmin',
                            ),
                        ),
                    ),
                    'admin-add-user' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/admin-add-user',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'adminAddUser',
                            ),
                        ),
                    ),
					'update-user-status' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-user-status',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'updateUserStatus',
                            ),
                        ),
                    ), 
					'users-list' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/users-list',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'usersList',
                            ),
                        ),
                    ),					
					'view-user' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/view-user[/:id]',
							'constraints' => array(
								'id' => '[%&;a-zA-Z0-9][%&;a-zA-Z0-9_~-]*',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'viewUser',
                            ),
                        ),
                    ),
					'update-user' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/update-user[/:id]',
							'constraints' => array(
								'id' => '[%&;a-zA-Z0-9][%&;a-zA-Z0-9_~-]*',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\UserController',
                                'action'     => 'updateUser',
                            ),
                        ),
                    ),
					'check-email' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/check-email',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AdminController',
                                'action'     => 'checkEmail',
                            ),
                        ),
                    ),
					'admin-logout' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/admin-logout',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\AdminController',
                                'action'     => 'adminLogout',
                            ),
                        ),
                    ),
					//Country
					'country-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/country-management',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CountryController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'countries' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/countries[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CountryController',
                                'action'     => 'countries',
                            ),
                        ),
                    ),
					'add-country' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/add-country[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CountryController',
                                'action'     => 'addCountry',
                            ),
                        ),
                    ),					
					//City
					'city-management' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/city-management',
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CityController',
                                'action'     => 'index',
                            ),
                        ),
                    ),
					'city' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/city[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CityController',
                                'action'     => 'city',
                            ),
                        ),
                    ),
					'add-city' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/add-city[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CityController',
                                'action'     => 'addCity',
                            ),
                        ),
                    ),
					'city-operations' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/city-operations[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\CityController',
                                'action'     => 'cityOperations',
                            ),
                        ),
                    ),
					//End
					'get-cities' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/get-cities[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\VendorsController',
                                'action'     => 'getCities',
                            ),
                        ),
                    ),
					'upload-profile-image' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route'    => '/upload-profile-image[/:action][/:id]',
							'constraints' => array(
								'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'id'     => '[0-9]+',
							),
							'defaults' => array(
                                'controller' => 'ZfcAdmin\Controller\QuotesController',
                                'action'     => 'upload-profile-image',
                            ),
                        ),
                    ),
                ),				
            ),	
        ),
    ),    
    'view_manager' => array(
        'template_path_stack' => array(
            __DIR__ . '/../view'
        ),
		'strategies' => array(
            'ViewJsonStrategy',
        ),
    ),
);
