<?php
// This is to avoid PSR-0 warning from php-cs-fixer
require_once __DIR__ . '/src/ScnSocialAuth/Module.php';
