<?php

namespace ScnSocialAuth\Mapper\Exception;

use ZfcBase\Mapper\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{}
