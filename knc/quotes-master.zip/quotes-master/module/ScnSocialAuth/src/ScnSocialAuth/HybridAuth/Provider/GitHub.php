<?php
namespace ScnSocialAuth\HybridAuth\Provider;

/**
 * This is simply to trigger autoloading as a hack for poor design in HybridAuth.
 */
class GitHub extends \Hybrid_Providers_GitHub {}
