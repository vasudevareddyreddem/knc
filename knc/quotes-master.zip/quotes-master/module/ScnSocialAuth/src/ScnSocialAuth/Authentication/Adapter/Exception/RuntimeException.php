<?php

namespace ScnSocialAuth\Authentication\Adapter\Exception;

use ScnSocialAuth\Authentication\Exception;

class RuntimeException extends Exception\RuntimeException implements
    ExceptionInterface
{
}
