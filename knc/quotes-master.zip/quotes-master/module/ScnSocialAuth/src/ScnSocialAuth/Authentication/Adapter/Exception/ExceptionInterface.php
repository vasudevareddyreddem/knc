<?php

namespace ScnSocialAuth\Authentication\Adapter\Exception;

use ScnSocialAuth\Authentication\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
