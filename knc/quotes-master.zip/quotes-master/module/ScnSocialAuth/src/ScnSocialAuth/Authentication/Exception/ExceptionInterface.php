<?php

namespace ScnSocialAuth\Authentication\Exception;

interface ExceptionInterface
{
}
