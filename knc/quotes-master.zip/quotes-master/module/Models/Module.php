<?php
namespace Models;
use Models\Model\UserType;
use Models\Model\UserTypeTable;
use Models\Model\Users;
use Models\Model\UsersTable;
use Models\Model\UserInfo;
use Models\Model\UserInfoTable;
use Models\Model\Author;
use Models\Model\AuthorTable;
use Models\Model\Category;
use Models\Model\CategoryTable;
use Models\Model\Language;
use Models\Model\LanguageTable;
use Models\Model\Quotes;
use Models\Model\QuotesTable;
use Models\Model\ForgotPassword;
use Models\Model\ForgotPasswordTable;
use Models\Model\SocialProviders;
use Models\Model\SocialProvidersTable;
use Models\Model\Favorites;
use Models\Model\FavoritesTable;
use Models\Model\QuoteCategories;
use Models\Model\QuoteCategoriesTable;
use Models\Model\QuoteViews;
use Models\Model\QuoteViewsTable;
use Models\Model\QuotesDump;
use Models\Model\QuotesDumpTable;
use Models\Model\PictureQuote;
use Models\Model\PictureQuoteTable;
use Zend\Db\TableGateway\TableGateway;
class Module
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
				'Models\Model\PictureQuoteFactory'			=>	'Models\Factory\Model\PictureQuoteTableFactory',
				'Models\Model\UserTypeFactory'			  	=>	'Models\Factory\Model\UserTypeTableFactory',
				'Models\Model\UsersFactory'		    	  	=>	'Models\Factory\Model\UsersTableFactory',		
				'Models\Model\UserInfoFactory'		    	=>	'Models\Factory\Model\UserInfoTableFactory',	
				'Models\Model\ForgotPasswordFactory'		=>  'Models\Factory\Model\ForgotPasswordTableFactory',
				'Models\Model\AuthorFactory'	          	=>	'Models\Factory\Model\AuthorTableFactory',	
				'Models\Model\CategoryFactory'			    =>	'Models\Factory\Model\CategoryTableFactory',
				'Models\Model\LanguageFactory'			    =>	'Models\Factory\Model\LanguageTableFactory',
				'Models\Model\QuotesFactory'			    =>	'Models\Factory\Model\QuotesTableFactory',
				'Models\Model\SocialProvidersFactory'		=>  'Models\Factory\Model\SocialProvidersTableFactory',
				'Models\Model\FavoritesFactory'		        =>  'Models\Factory\Model\FavoritesTableFactory',
				'Models\Model\QuoteCategoriesFactory'		=>  'Models\Factory\Model\QuoteCategoriesTableFactory',
				'Models\Model\QuoteViewsFactory'			=>  'Models\Factory\Model\QuoteViewsTableFactory',
				'Models\Model\QuotesDumpFactory'			=>  'Models\Factory\Model\QuotesDumpTableFactory',
			),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
}