<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class UserInfoTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select 		= new Select();
    }
	// Reg verification
	public function updateUserRegAuth($u_id){
		$data = array(
			'uf_status'  	=>'1',
			'uf_updated_at' => date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('uf_u_id = "'.$u_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();		
	}
	// Add normal new user
	public function addNormalUser($userData,$uid){
		if(isset($userData['uf_fname']) && $userData['uf_fname']!=""){
			$ufname = $userData['uf_fname'];		
		}else{
			$ufname = "";
		}
		if(isset($userData['uf_lname']) && $userData['uf_lname']!=""){
			$ulname = $userData['uf_lname'];
		}else{
			$ulname = $userData['uf_fname'];
		}	
		if(isset($userData['uf_gender']) && $userData['uf_gender']!=""){
			$gender = $userData['uf_gender'];
		}else{
			$gender = '';
		}
		if(isset($userData['uf_pic']) && $userData['uf_pic']!=""){
			$userPic = $userData['uf_pic'];
		}else{
			$userPic = '';
		}
		if(isset($userData['uf_dob']) && $userData['uf_dob']!=""){
			$uDob = $userData['uf_dob'];
		}else{
			$uDob = '';
		}
		if(isset($userData['uf_about_me']) && $userData['uf_about_me']!=""){
			$uf_about_me = $userData['uf_about_me'];
		}else{
			$uf_about_me = '';
		}
		if(isset($userData['social_pic']) && $userData['social_pic']!=""){
			$social_pic = $userData['social_pic'];
		}else{
			$social_pic = '';
		}
		$data = array(
			'uf_u_id' 	    	=> $uid,				
			'uf_fname'  	    => $ufname,
			'uf_lname' 	        => $ulname,
			'uf_gender' 	    => $gender,
			'uf_pic' 	        => $userPic,
			'social_pic' 	     => $social_pic,
			'uf_dob' 	        => $uDob,
			'uf_about_me' 	    => $uf_about_me,
			'uf_ceated_at' 		=> date('Y-m-d H:i:s'),
			'uf_updated_at'     => date('Y-m-d H:i:s'),
			'uf_status'      	=> 0
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();
	}
	// update user 
	public function updateNormalUser($userData,$uid){
		if(isset($userData['fname']) && $userData['fname']!=""){
			if(isset($userData['fname']) && $userData['fname']!=""){
				$uDiplayName = $userData['fname'];
			}else{
				$uDiplayName = $userData['fname'];
			}			
		}else{
			$uDiplayName = "";
		}
		if(isset($userData['uf_about_me']) && $userData['uf_about_me']!=""){
			$aboutMe = $userData['uf_about_me'];
		}else{
			$aboutMe = '';
		}		
		if(isset($userData['u_pic']) && $userData['u_pic']!=""){
			$pic = $userData['u_pic'];
		}else{
			$pic = '';
		}
		$data = array(
			'uf_fname'  	    => $uDiplayName,			
			'uf_pic' 	        => $pic,			
			'uf_about_me' 	    => $aboutMe,
			'uf_updated_at'     => date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('uf_u_id = "'.$uid.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	// insert user data
	public function userRegInfo($userData,$uid,$pic){
		
		if(isset($userData['u_textArea']) && $userData['u_textArea']!=""){
			$aboutMe = $userData['u_textArea'];
		}else{
			$aboutMe = '';
		}
		if(isset($userData['u_flname']) && $userData['u_flname']!=""){
			$flname = $userData['u_flname'];
		}else{
			$flname = '';
		}
		if(isset($pic) && $pic!=""){
			$userPic = $pic;
		}else{
			$userPic = '';
		}
		
		$data = array(
			'uf_u_id' 	    		=> $uid,		
			'uf_pic' 	    		=> $userPic,		
			'uf_fname' 	    		=> $flname,		
			'uf_about_me' 	    	=> $aboutMe,					
			'uf_ceated_at' 			=> date('Y-m-d H:i:s'),			
			'uf_status'      		=> 1
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();		
		return $result->getGeneratedValue();
		
	}
	//update user info
	public function userProfileInfo($post,$img)
	{
		$fullName = $post['u_flname'];		
		$u_textArea = $post['u_textArea'];
		$hUid = $post['hiddenUid'];
		$select = $this->tableGateway->getSql()->select();		
		$data = array(
			'uf_updated_at'			=>	date('Y-m-d H:i:s'),
			'uf_fname'		=>	$fullName,
			'uf_about_me'	=> $u_textArea,
		);
		if(isset($_POST['picchangeflag']) && $_POST['picchangeflag']==1){
			$data['uf_pic'] = $img;
		}
		$row=$this->tableGateway->update($data, array('uf_u_id' => $hUid));
		return $row;
	}
	public function adduserinfo($uid,$users){
		if(isset($users['name']) && $users['name']!=''){
			$u_name = $users['name'];
		}else{
			$u_name = '';
		}
		if(isset($users['lname']) && $users['lname']!=''){
			$ul_name = $users['lname'];
		}else{
			$ul_name = '';
		}
		if(isset($users['email']) && $users['email']!=''){
			$u_email = $users['email'];
		}else{
			$u_email = '';
		}		
		$data = array(
			'uf_u_id' 	  => $uid,
			'uf_fname' 	  => $u_name,	
			'uf_lname' 	  => $ul_name,	
			'uf_status'   => 1,  	
			'uf_ceated_at' 	=> date('Y-m-d H:i:s'),   
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function addInfoUser($uid,$name){			
		$data = array(
			'uf_u_id' 	  => $uid,
			'uf_fname' 	  => $name,	
			'uf_status'   => 1,  	
			'uf_ceated_at' 	=> date('Y-m-d H:i:s'),   
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function deleteUserInfoByAdmin($uf_u_id){
		$dataa = array(				
			'uf_u_id'  => $uf_u_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('uf_u_id = :uf_u_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute($dataa);
		return 	$resultSet;		
	}
	public function addSUserProviderD($uid,$users){
		if(isset($users['name']) && $users['name']!=''){
			$firstName = $users['name'];
		}else{
			$firstName = '';
		}
		if(isset($users['lname']) && $users['lname']!=''){
			$lname = $users['lname'];
		}else{
			$lname = '';
		}
		$data = array(
			'uf_u_id'         => $uid,
			'uf_fname' 	  	  => $firstName,
			'uf_lname' 	  	  => $lname,		
			'uf_status'  	  => 1,  	
			'uf_ceated_at' 	  => date('Y-m-d H:i:s'),   
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function addSGoogleProviderD($uid,$users){
		if(isset($users['given_name']) && $users['given_name']!=''){
			$firstName = $users['given_name'];
		}else{
			$firstName = '';
		}
		if(isset($users['family_name']) && $users['family_name']!=''){
			$lastName = $users['family_name'];
		}else{
			$lastName = '';
		}
		if(isset($users['picture']) && $users['picture']!=''){
			$photo = $users['picture'];
		}else{
			$photo = '';
		}
		$data = array(
			'uf_u_id'        => $uid,
			'uf_fname' 	  	 => $firstName,				
			'uf_lname' 	  	 => $lastName,				
			'social_pic' 	 => $photo,				
			'uf_status'  	 => 1,  	
			'uf_ceated_at' 	 => date('Y-m-d H:i:s'),   
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function insertuserinfodata($users,$uid){
		if(isset($users['userName']) && $users['userName']!=''){
			$uf_fname = $users['userName'];
		}else{
			$uf_fname = '';
		}
		if(isset($users['last_name']) && $users['last_name']!=''){
			$uf_lname = $users['last_name'];
		}else{
			$uf_lname = '';
		}
		if(isset($users['userPic']) && $users['userPic']!=''){
			$social_pic = $users['userPic'];
		}else{
			$social_pic = '';
		}
		if(isset($users['gender']) && $users['gender']!=''){
			$uf_gender = $users['gender'];
		}else{
			$uf_gender = '';
		}
		$data = array(
			'uf_u_id'        => $uid,
			'uf_fname' 	  	 => $uf_fname,				
			'uf_lname' 	  	 => $uf_lname,				
			'social_pic' 	 => $social_pic,				
			'uf_gender' 	 => $uf_gender,				
			'uf_status'  	 => 1,  	
			'uf_updated_at' 	 => date('Y-m-d H:i:s'),   
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	
	public function updateuserinfodata($users,$uid){
		if(isset($users['userName']) && $users['userName']!=''){
			$uf_fname = $users['userName'];
		}else{
			$uf_fname = '';
		}
		if(isset($users['last_name']) && $users['last_name']!=''){
			$uf_lname = $users['last_name'];
		}else{
			$uf_lname = '';
		}
		if(isset($users['userPic']) && $users['userPic']!=''){
			$social_pic = $users['userPic'];
		}else{
			$social_pic = '';
		}
		if(isset($users['gender']) && $users['gender']!=''){
			$uf_gender = $users['gender'];
		}else{
			$uf_gender = '';
		}
		$data = array(
			'uf_fname' 	  	 => $uf_fname,				
			'uf_lname' 	  	 => $uf_lname,				
			'social_pic' 	 => $social_pic,				
			'uf_gender' 	 => $uf_gender,				
			'uf_ceated_at' 	 => date('Y-m-d H:i:s'),   
		);	
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('uf_u_id = "'.$uid.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet =  $statement->execute();
		return 1;	
	}
}