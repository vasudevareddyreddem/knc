<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class AuthorTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select = new Select();
    }
	public function userAuthor($au_u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('au_u_id = :au_u_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('au_u_id' => $au_u_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	//
	public function getAuthorId($au_fname){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('au_fname = :au_fname');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('au_fname' => $au_fname); 
		$result 	= $statement->execute($data)->current();
		return $result;		
	}
	// Delete the author from Db
	public function deleteAuthor($au_id){
		$dataa = array(				
			'au_id'  => $au_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('au_id = :au_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute($dataa);
		return 	$resultSet;
	}
	// Get all authors list	
	public function authorsList(){
		$select = $this->tableGateway->getSql()->select();
		$select->where('au_popular =1');
		$select->order('au_id DESC');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function frontAuthorsList($count){
		$select = $this->tableGateway->getSql()->select();
		$select->order('au_id DESC');
		$select->where('au_status =1');
		$select->where('au_popular =1');
        $resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
		$paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;			
	}		
	// Quote normal user as to author
	public function addSQAuthor($authorData){
		if(isset($authorData['au_fname']) && $authorData['au_fname']!=""){
			$aufname = $authorData['au_fname'];		
		}else{
			$aufname = "";
		}
		if(isset($authorData['au_lname']) && $authorData['au_lname']!=""){
			$aulname = $authorData['au_lname'];		
		}else{
			$aulname = "";
		}		
		if(isset($authorData['au_descrpt']) && $authorData['au_descrpt']!=""){
			$auDescrpt = $authorData['au_descrpt'];		
		}else{
			$auDescrpt = "";
		}
		if(isset($authorData['au_u_id']) && $authorData['au_u_id']!=""){
			$au_u_id = $authorData['au_u_id'];		
		}else{
			$au_u_id = "";
		}		
		$data = array(
			'au_fname'		    =>	$aufname,
			'au_lname'		    =>	$aulname,
			'au_descrpt'		=>	$auDescrpt,
			'au_u_id'		    =>	$au_u_id,
			'au_created_at'	    =>	date('Y-m-d H:i:s'),
			'au_status'		    =>	0,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();		
	}	
	// Add new author
	public function addAuthor($authorData){
		if(isset($authorData['au_fname']) && $authorData['au_fname']!=""){
			$aufname = $authorData['au_fname'];		
		}else{
			$aufname = "";
		}
		if(isset($authorData['au_lname']) && $authorData['au_lname']!=""){
			$aulname = $authorData['au_lname'];		
		}else{
			$aulname = "";
		}
		if(isset($authorData['au_pic']) && $authorData['au_pic']!=""){
			$auPic = $authorData['au_pic'];		
		}else{
			$auPic = "";
		}
		if(isset($authorData['au_birth_year']) && $authorData['au_birth_year']!=""){
			$auBirthYear = $authorData['au_birth_year'];		
		}else{
			$auBirthYear = "";
		}
		if(isset($authorData['au_deadth_year']) && $authorData['au_deadth_year']!=""){
			$auDeathYear = $authorData['au_deadth_year'];		
		}else{
			$auDeathYear = "";
		}
		if(isset($authorData['au_descrpt']) && $authorData['au_descrpt']!=""){
			$auDescrpt = $authorData['au_descrpt'];		
		}else{
			$auDescrpt = "";
		}
		if(isset($authorData['au_wiki_link']) && $authorData['au_wiki_link']!=""){
			$auWikiLink = $authorData['au_wiki_link'];		
		}else{
			$auWikiLink = "";
		}
		$data = array(
			'au_fname'		    =>	$aufname,
			'au_lname'		    =>	$aulname,
			'au_pic'		    =>	$auPic,
			'au_birth_year'		=>	$auBirthYear,
			'au_deadth_year'	=>	$auDeathYear,
			'au_descrpt'		=>	$auDescrpt,
			'au_wiki_link'		=>	$auWikiLink,
			'au_created_at'	    =>	date('Y-m-d H:i:s'),
			'au_updated_at'   	=>	date('Y-m-d H:i:s'),
			'au_status'		    =>	1,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();		
	}	
	// Update author
	public function updateAuthor($authorData,$au_id){
		if(isset($authorData['au_fname']) && $authorData['au_fname']!=""){
			$aufname = $authorData['au_fname'];		
		}else{
			$aufname = "";
		}
		if(isset($authorData['au_lname']) && $authorData['au_lname']!=""){
			$aulname = $authorData['au_lname'];		
		}else{
			$aulname = "";
		}
		if(isset($authorData['au_pic']) && $authorData['au_pic']!=""){
			$auPic = $authorData['au_pic'];		
		}else{
			$auPic = "";
		}
		if(isset($authorData['au_birth_year']) && $authorData['au_birth_year']!=""){
			$auBirthYear = $authorData['au_birth_year'];		
		}else{
			$auBirthYear = "";
		}
		if(isset($authorData['au_deadth_year']) && $authorData['au_deadth_year']!=""){
			$auDeathYear = $authorData['au_deadth_year'];		
		}else{
			$auDeathYear = "";
		}
		if(isset($authorData['au_descrpt']) && $authorData['au_descrpt']!=""){
			$auDescrpt = $authorData['au_descrpt'];		
		}else{
			$auDescrpt = "";
		}
		if(isset($authorData['au_wiki_link']) && $authorData['au_wiki_link']!=""){
			$auWikiLink = $authorData['au_wiki_link'];		
		}else{
			$auWikiLink = "";
		}
		$data = array(
			'au_fname'		    =>	$aufname,
			'au_lname'		    =>	$aulname,
			'au_pic'		    =>	$auPic,
			'au_birth_year'		=>	$auBirthYear,
			'au_deadth_year'	=>	$auDeathYear,
			'au_descrpt'		=>	$auDescrpt,
			'au_wiki_link'		=>	$auWikiLink,
			'au_updated_at'   	=>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('au_id = "'.$au_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	
	// Get author id data
	public function getAuthorData($au_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('au_id = :au_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('au_id' => $au_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	public function getRelatedAuthors($authorProfession){
		$select = $this->tableGateway->getSql()->select();	
		$select->where('au_profession ="'.$authorProfession.'"');
		$select->where('au_popular =1');
		$resultSet = $this->tableGateway->selectWith($select);
		return 	$resultSet;
	}
	
	// Delete category
	public function updateAuthorStatus($au_id,$status)
    {
		$data = array(
			'au_status'	    =>	$status,
			'au_updated_at' =>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('au_id = "'.$au_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	// Famous Authors List
	public function famousAuthors($flag = null)
	{
		
		$select = $this->tableGateway->getSql()->select();		
		$select->where('au_popular = :au_popular');
		$select->order('au_id ASC');
		if($flag == 1)
		{
			$count = 10;
			$select->limit($count);
		}
		else{
			$count = 8;
			$select->limit($count);
		}		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('au_popular' => 1); 
		$result 	= $statement->execute($data);
		$result 	= $result->getResource()->fetchAll();
		return ($result);	
		
	}
	
	public function getAllAuthList(){
		$select = $this->tableGateway->getSql()->select();	
		$select->where('au_popular =1');				
		$select->order('au_fname AUTO');			
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
				$select,
				$this->tableGateway->getAdapter(),
				$resultSet
			);
			$paginator = new Paginator($paginatorAdapter);
			return $paginator;
		
	}
	public function authorpageajax($basepagecount,$offset){
		$select = $this->tableGateway->getSql()->select();	
		$select->where('au_popular =1');
		$select->limit(intVal($basepagecount));
		$select->offset(intVal($offset));		
		$select->order('au_fname AUTO');			
		$resultSet = $this->tableGateway->selectWith($select);
		return 	$resultSet;	
	}
	public function getAllAuthList1(){
		$select = $this->tableGateway->getSql()->select();		
		$select->order('au_fname AUTO');			
		$resultSet = $this->tableGateway->selectWith($select);		
		return $resultSet;
	}
	public function checkAuthor($au_u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('au_u_id = :au_u_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('au_u_id' => $au_u_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	public function updateUserAuthorDescription($au_descrpt,$au_id)
    {
		$data = array(
			'au_descrpt'	    =>	$au_descrpt,
			'au_updated_at' =>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('au_id = "'.$au_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
}