<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class UsersTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select 		= new Select();
    }
	// Delete User
	public function updateUserStatus($u_id,$status)
    {
		$data = array(
			'u_updated_at'	=>	date('Y-m-d H:i:s'),
			'u_status'		=>	$status,
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('u_id = "'.$u_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	public function deleteUserByAdmin($u_id){
		$dataa = array(				
			'u_id'  => $u_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('u_id = :u_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute($dataa);
		return 	$resultSet;	
	}
	public function adminAddUser($uemail,$utid,$ufname,$password){
		$pass = md5($password);
		$data = array(
			'u_ut_id' 	    	=> $utid,				
			'u_display_name'  	=> $ufname,
			'u_email' 	        => $uemail,
			'u_password' 	    => $pass,
			'u_created_at' 		=> date('Y-m-d H:i:s'),
			'u_status'      	=> 1
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();
	}
	// Add normal new user
	public function addNormalUser($userData){
		if(isset($userData['uf_fname']) && $userData['uf_fname']!=""){
			if(isset($userData['uf_lname']) && $userData['uf_lname']!=""){
				$uDiplayName = $userData['uf_fname'].' '.$userData['uf_lname'];
			}else{
				$uDiplayName = $userData['uf_fname'];
			}			
		}else{
			$uDiplayName = "";
		}
		if(isset($userData['u_email']) && $userData['u_email']!=""){
			$uEmail = $userData['u_email'];
		}else{
			$uEmail = '';
		}
		if(isset($userData['u_password']) && $userData['u_password']!=""){
			$uPassword = md5($userData['u_password']);
		}else{
			$uPassword = '';
		}
		if(isset($userData['u_mobile']) && $userData['u_mobile']!=""){
			$uMobile = $userData['u_mobile'];
		}else{
			$uMobile = '';
		}
		$data = array(
			'u_ut_id' 	    	=> '2',				
			'u_display_name'  	=> $uDiplayName,
			'u_email' 	        => $uEmail,
			'u_password' 	    => $uPassword,
			'u_mobile' 	        => $uMobile,
			'u_created_at' 		=> date('Y-m-d H:i:s'),
			'u_status'      	=> 0
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();
	}
	// update user 
	public function updateNormalUser($userData,$u_id){
		if(isset($userData['fname']) && $userData['fname']!=""){
			if(isset($userData['fname']) && $userData['fname']!=""){
				$uDiplayName = $userData['fname'];
			}else{
				$uDiplayName = $userData['fname'];
			}			
		}else{
			$uDiplayName = "";
		}
		if(isset($userData['uf_about_me']) && $userData['uf_about_me']!=""){
			$aboutMe = $userData['uf_about_me'];
		}else{
			$aboutMe = '';
		}		
		if(isset($userData['u_pic']) && $userData['u_pic']!=""){
			$pic = $userData['u_pic'];
		}else{
			$pic = '';
		}
		$data = array(
			'u_display_name'  	=> $uDiplayName,			
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('u_id = "'.$u_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}	
	// Checking unique email is admin or normal user
	public function checkEmail($email,$userType){		
		$select = $this->tableGateway->getSql()->select();
		$select->where('u_email  = :u_email');
		$select->where('u_ut_id  = :u_ut_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_email' => $email, 'u_ut_id' => $userType); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// Get email id user data
	public function emailUserData($email,$userType){
		$select = $this->tableGateway->getSql()->select();		
		$select->where('u_email  = :u_email');			
		$select->where('u_ut_id  = :u_ut_id');			
		$select->where('u_status = :u_status');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_email' => $email,'u_ut_id'=>$userType,'u_status'=>1); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	// Checking unique mobile 
	public function checkMobile($mobile,$userType){
		$select = $this->tableGateway->getSql()->select();
		$select->where('u_mobile  = :u_mobile');
		$select->where('u_ut_id  = :u_ut_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_mobile' => $mobile, 'u_ut_id' => $userType); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// Get mobile user data
	public function mobileUserData($mobile,$userType){
		$select = $this->tableGateway->getSql()->select();
		$select->where('u_mobile = "'.$mobile.'"');
		$select->where('u_ut_id  = "'.$userType.'"');
		$select->where('u_status = 1');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}
	// Forgot Password - Change password
	public function changepwd($u_id,$pwd){
		$password=md5($pwd);
		$data = array(
			'u_password'      =>$password,
			'u_updated_at' 	  => date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('u_id = "'.$u_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
		// return $result->getGeneratedValue();	
	}
	// Getpassword 
	public function getpassword($u_id,$u_password){   
		$password=md5($u_password);
		$select = $this->tableGateway->getSql()->select();                      
		$select->where('u_id=:u_id');                                         
		$select->where('u_password=:u_password');                                         
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $u_id, 'u_password' => $password); 
		$result 	= $statement->execute($data)->count();
		return $result;
	} 
	// User login with email or mobile 
	public function userLogin($email,$mobile,$pwd,$usertype){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		if($mobile!=''){
			$select->where('u_mobile = :u_mobile');
		}else{
			$select->where('u_email  = :u_email');
		}
		$select->where('u_password   = :u_password');
		$select->where('u_ut_id      = :u_ut_id');
		$select->where('u_status     = :u_status');
		$u_pwd = md5($pwd);		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		if($mobile!=''){
		$data 		= array('u_mobile' => $mobile, 'u_password' => $u_pwd, 'u_ut_id'=>$usertype,'u_status' => 1); 
		}else{
		$data 		= array('u_email' => $email, 'u_password' => $u_pwd, 'u_ut_id'=>$usertype,'u_status' => 1);  
		}
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	// Reg verification
	public function updateUserRegAuth($u_id){
		$data = array(
			'u_status'  	=>'1',
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('u_id = "'.$u_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();		
	}	
	// Get User id  userdata
	public function nonActiveUser($u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('qc_users.u_id = :u_id');	
		$select->where('u_status     = :u_status');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $u_id,'u_status'=>0); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	// Get User id  userdata 
	public function getUserData($u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('u_id = :u_id');
		$select->where('u_status     = :u_status');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $u_id,'u_status'=>1); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	//
	public function getDeactiveUserDetails($u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('u_id = :u_id');
		$select->where('u_status     = :u_status');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $u_id,'u_status'=>0); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	public function updateuseraccount($u_id){
		$select = $this->tableGateway->getSql()->select();
		$data = array(
			'u_updated_at'	=>	date('Y-m-d H:i:s'),
			'u_status'		=>	1,
		);
		$row=$this->tableGateway->update($data, array('u_id' => $u_id));
		return $row;
	}
	public function admingetUserData($u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_type','qc_users.u_ut_id=qc_user_type.ut_id',array('*'),'left');
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('u_id = :u_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $u_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	// Get all users data
	public function getAllUsers(){
		$select = $this->tableGateway->getSql()->select();
		$select->order('u_id DESC');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}	
	//Check Password
	public function checkPassword($u_id,$password){
		$u_pwd = md5($password);
		$select = $this->tableGateway->getSql()->select();
		$select->where('u_password = "'.$u_pwd.'"');
		$select->where('u_id = "'.$u_id.'"');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}	
	//Updated Password
	public function updatePassword($u_id,$password)
    {
		$u_pwd = md5($password);
		$select = $this->tableGateway->getSql()->select();
		$data = array(
			'u_updated_at'		=>	date('Y-m-d H:i:s'),
			'u_password'		=>	$u_pwd,
		);
		$row=$this->tableGateway->update($data, array('u_id' => $u_id));
		return $row;
	}
	
	public function checkUserType($post,$userType){
		
		$select = $this->tableGateway->getSql()->select();			
		$select->where('u_email   = :u_email');
		$select->where('u_password  = :u_password');
		$select->where('u_ut_id  = :u_ut_id');
		$select->where('u_status  = :u_status');
		$email = $post['u_email'];
		$pass = $post['u_password'];		
		$u_pwd = md5($pass);		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);		
		$data 		= array('u_email' => $email, 'u_password' => $u_pwd, 'u_ut_id'=>$userType,'u_status' => 1);			
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	
	public function userReg($userData){
		if(isset($userData['u_flname']) && $userData['u_flname']!=""){
			$flname = $userData['u_flname'];
		}else{
			$flname = '';
		}
		if(isset($userData['u_email']) && $userData['u_email']!=""){
			$uemail = $userData['u_email'];		
		}else{
			$uemail = "";
		}
		if(isset($userData['u_password']) && $userData['u_password']!=""){
			$pwd = md5($userData['u_password']);
		}else{
			$pwd = $userData['u_password'];
		}	
		if(isset($userData['u_textArea']) && $userData['u_textArea']!=""){
			$aboutMe = $userData['u_textArea'];
		}else{
			$aboutMe = '';
		}
		if(isset($userData['u_subscribe']) && $userData['u_subscribe']!=""){
			$subScribe = $userData['u_subscribe'];
		}else{
			$subScribe = '';
		}

		$data = array(
			'u_ut_id' 	    		=> 2,		
			'u_display_name' 	    => $flname,		
			'u_email' 	    		=> $uemail,		
			'u_password' 	    	=> $pwd,
			'u_subscribe'           => $subScribe,			
			'u_created_at' 			=> date('Y-m-d H:i:s'),
			'u_status'      		=> 0
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();		
		return $result->getGeneratedValue();
		
	}
	
	public function userData($logggedInId,$userType)
	{
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('u_id = :u_id');
		$select->where('u_ut_id  = :u_ut_id');			
		$select->where('u_status  = :u_status');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $logggedInId,'u_ut_id' =>$userType,'u_status'=>1); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	
	public function getUserDetails($logggedInId,$userType)
	{
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('u_id = :u_id');
		$select->where('u_ut_id  = :u_ut_id');			
		$select->where('u_status  = :u_status');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $logggedInId,'u_ut_id' =>$userType,'u_status'=>1); 
		$result 	= $statement->execute($data)->current();
		return $result;	
	}
	
	public function getSubscribersList()
	{
		$select = $this->tableGateway->getSql()->select();	
		$select->where('u_status  = :u_status');			
		$select->where('u_subscribe  = :u_subscribe');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_subscribe' => 1,'u_status'=> 1); 
		$result 	= $statement->execute($data);
		$results 	= $result->getResource()->fetchAll();
		return $results;
	}
	
	public function userProfileUpdate($post)
	{
		
		$fullName = $post['u_flname'];
		$hUid = $post['hiddenUid'];
		$select = $this->tableGateway->getSql()->select();
		$data = array(
			'u_updated_at'			=>	date('Y-m-d H:i:s'),
			'u_display_name'		=>	$fullName,
		);
		$row=$this->tableGateway->update($data, array('u_id' => $hUid));
		return $row;
	}
	
	public function checkUserPass($post)
	{
		$uid = $post['uid'];
		$pass = md5($post['currentPassword']);
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('u_id = :u_id');
		$select->where('u_password  = :u_password');			
		$select->where('u_status  = :u_status');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_id' => $uid,'u_password'=>$pass,'u_status'=>1); 
		$result 	= $statement->execute($data)->current();
		return $result;	
	}
	
	public function updateUserPass($post)
	{
		$uid = $post['userid'];
		$pass = md5($post['newPass']);		
		$select = $this->tableGateway->getSql()->select();
		$data = array(
			'u_updated_at'		=>	date('Y-m-d H:i:s'),
			'u_password'		=>	$pass,
		);
		$row=$this->tableGateway->update($data, array('u_id' => $uid));
		return $row;	
	}
	// check email for forgot password
	public function checkForgotMail($email){
		$select = $this->tableGateway->getSql()->select();
		$select->where('u_email = :u_email');
		$select->where('u_status = :u_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_email' => $email,'u_status'=>1); 
		$result 	= $statement->execute($data)->current();
		return $result;	
	}
	//Admin 
	public function checkForgotMailAdmin($email){
		$select = $this->tableGateway->getSql()->select();
		$select->where('u_email = :u_email');
		$select->where('u_ut_id = :u_ut_id');
		$select->where('u_status = :u_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('u_email' => $email,'u_status'=>1,'u_ut_id'=>1); 
		$result 	= $statement->execute($data)->current();
		return $result;	
	}
	
	public function updtFgtPass($uid,$pass)
	{
		$select = $this->tableGateway->getSql()->select();
		$data = array(
			'u_updated_at'		=>	date('Y-m-d H:i:s'),
			'u_password'		=>	md5($pass),
		);
		$row=$this->tableGateway->update($data, array('u_id' => $uid));
		return $row;
	}
	/* By Dileep For Scoial Logins*/
	public function checkEmailExists($email){        
		$select = $this->tableGateway->getSql()->select();                       
		$select->where('u_email="'.$email.'"');
		$select->where('u_ut_id=2');
		$select->where('u_status="1"');
		$resultSet = $this->tableGateway->selectWith($select);                            
	   return $resultSet->count();
	}
	public function updateEmail($users,$u_id){
		if(isset($users['email']) && $users['email']!=''){
			$u_email = $users['email'];
		}else{
			$u_email = '';
		}		
		$data = array(
			'u_email'              =>$u_email,
		);
		$updatedResult=$this->tableGateway->update($data, array('u_id' => $u_id));
		return 	$updatedResult;			
	}
	public function getUserInfo($id){
		$userId=$id;
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');	
		$select->where('u_id = :u_id');			
		$select->where('u_ut_id = :u_ut_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
	    $data 		= array('u_id' => $userId,'u_ut_id'=>1); 		
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	public function getUserInfoF($id){
		$userId=$id;
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');	
		$select->where('u_id = :u_id');			
		$select->where('u_ut_id = :u_ut_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
	    $data 		= array('u_id' => $userId,'u_ut_id'=>2); 		
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	public function allUsersList(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');	
		$select->where('u_ut_id != :u_ut_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
	    $data 		= array('u_ut_id'=>1); 		
		$result 	= $statement->execute($data);
		$results 	= $result->getResource()->fetchAll();
		return $results;
	}
	public function addSUserProvider($users){
		if(isset($users['name']) && $users['name']!=''){
			$u_name = $users['name'];
		}else{
			$u_name = '';
		}
		if(isset($users['lname']) && $users['lname']!=''){
			$ul_name = $users['lname'];
		}else{
			$ul_name = '';
		}
		if(isset($users['email']) && $users['email']!=''){
			$u_email = $users['email'];
		}else{
			$u_email = '';
		}		
		$data = array(
			'u_ut_id' 	  	      => 2,	
			'u_display_name' 	  => $ul_name,	
			'u_email' 		       => $u_email,  			
			'u_status'  	       => 1,  	
			'u_created_at' 	       => date('Y-m-d H:i:s'),   
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function addSGoogleProvider($users){
		if(isset($users['name']) && $users['name']!=''){
			$u_name = $users['name'];
		}else{
			$u_name = '';
		}
		if(isset($users['email']) && $users['email']!=''){
			$u_email = $users['email'];
		}else{
			$u_email = '';
		}
		$data = array(
			'u_display_name' 		   => $u_name,	
			'u_email' 		           => $u_email,  				
			'u_status'  	       => 1,  	
			'u_created_at' 	           => date('Y-m-d H:i:s'),   
			'u_ut_id' 	  	      => 2,	 			
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function insertuserinfo($users){
		if(isset($users['userName']) && $users['userName']!='' && isset($users['last_name']) && $users['last_name']!=''){
			$u_name = $users['userName'].' '.$users['last_name'];
		}else if(isset($users['userName']) && $users['userName']!=''){
			$u_name = $users['userName'];
		}else{
			$u_name = '';
		}
		if(isset($users['email']) && $users['email']!=''){
			$u_email = $users['email'];
		}else{
			$u_email = '';
		}
		$data = array(
			'u_display_name' => $u_name,	
			'u_email' 		 => $u_email,  				
			'u_status'  	 => 1,  	
			'u_created_at' 	 => date('Y-m-d H:i:s'),   
			'u_ut_id' 	  	 => 2,	 			
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function updateuserinfo($users,$uid){
		if(isset($users['userName']) && $users['userName']!='' && isset($users['last_name']) && $users['last_name']!=''){
			$u_name = $users['userName'].' '.$users['last_name'];
		}else if(isset($users['userName']) && $users['userName']!=''){
			$u_name = $users['userName'];
		}else{
			$u_name = '';
		}
		if(isset($users['email']) && $users['email']!=''){
			$u_email = $users['email'];
		}else{
			$u_email = '';
		}
		$data = array(
			'u_display_name' => $u_name,	
			'u_email' 		 => $u_email,  				
			'u_updated_at' 	 => date('Y-m-d H:i:s'),   
		);	
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('u_id = "'.$uid.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet =  $statement->execute();
		return 1;
	}
}