<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class CategoryTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select = new Select();
    }
	public function deleteCat($qc_cat_id){
		$dataa = array(				
			'qc_cat_id'  => $qc_cat_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('qc_cat_id = :qc_cat_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute($dataa);
		return 	$resultSet;
	}
	// Check category name
	public function checkCategory($catName){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_cat_name = :qc_cat_name');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_cat_name' => $catName); 
		$result 	= $statement->execute($data)->count();
		return $result;
		
	}
	// Category id
	public function getCategoryId($catName){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_cat_name = :qc_cat_name');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_cat_name' => $catName); 
		$result 	= $statement->execute($data)->current();
		return $result;
		
	}
	// Check category name and catgory id
	public function checkCategoryData($catName,$catid){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_cat_name = :qc_cat_name');		
		$select->where('qc_cat_id = :qc_cat_id');	
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_cat_name' => $catName,'qc_cat_id'=>$catid); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}	
	// Get all categories list	
	public function categoriesList($flag=null){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_categories.qc_cat_popular = 1');
		$select->where('qc_categories.qc_cat_status  = 1');
		if($flag == 1)
		{
			$select->order('qc_cat_name');
		}
		else{
			$select->order('qc_cat_id DESC');
		}		
		 $resultSet 		= $this->tableGateway->selectWith($select);
		 $paginatorAdapter 	= new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator 			= new Paginator($paginatorAdapter);
		return $paginator;
		
	}
	public function adminCategoriesList(){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_cat_status = 1');
		$select->order('qc_cat_name ASC'); 
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result 	= $result->getResource()->fetchAll();

	}
	public function appCatList(){
		$select = $this->tableGateway->getSql()->select();
		$select->order('qc_cat_id DESC');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function frontCategoriesList($defaultAuthorsCount=null){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_cat_status = 1');
		$select->order('qc_cat_name ASC'); 
		$resultSet = $this->tableGateway->selectWith($select);		
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
		$paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;	
	}	
	// Add new category
	public function addCategory($catData){
		
		if(isset($catData['qc_cat_name']) && $catData['qc_cat_name']!=""){
			$catname = $catData['qc_cat_name'];
		}else{
			$catname = "";
		}
		if(isset($catData['qc_cat_pic']) && $catData['qc_cat_pic']!=""){
			$qc_cat_pic = $catData['qc_cat_pic'];
		}else{
			$qc_cat_pic = "";
		}
		$data = array(
			'qc_cat_name'			=>	$catname,
			'qc_cat_pic'			=>	$qc_cat_pic,
			'qc_cat_created_at'	    =>	date('Y-m-d H:i:s'),
			'qc_cat_updated_at'   	=>	date('Y-m-d H:i:s'),
			'qc_cat_status'			=>	1,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();		
		return $result->getGeneratedValue();	
	}	
	// Update category
	public function updateCategory($catData){
		if(isset($catData['qc_cat_name']) && $catData['qc_cat_name']!=""){
			$catname = $catData['qc_cat_name'];
		}else{
			$catname = "";
		}
		if(isset($catData['qc_cat_pic']) && $catData['qc_cat_pic']!=""){
			$qc_cat_pic = $catData['qc_cat_pic'];
		}else{
			$qc_cat_pic = "";
		}
		$data = array(
			'qc_cat_name'		=>	$catname,
			'qc_cat_pic'		=>	$qc_cat_pic,
			'qc_cat_updated_at'   	=>	date('Y-m-d H:i:s'),
		);
		$select 	= $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_cat_id = "'.$catData['qc_cat_id'].'"');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	// Delete category
	public function updateCategoryStatus($qc_cat_id,$status)
    {
		$data = array(
			'qc_cat_updated_at'		=>	date('Y-m-d H:i:s'),
			'qc_cat_status'		=>	$status,
		);
		$select 	= $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_cat_id = "'.$qc_cat_id.'"');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();		
	}	
	// Get category id data
	public function getCategoryData($qc_cat_id){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('qc_cat_id = :$qc_cat_id');	
		$data 		= array('qc_cat_id' => $qc_cat_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	public function getcatnames($qc_cat_ids){
		$catids 	= explode(',',$qc_cat_ids);
		$select 	= $this->tableGateway->getSql()->select();
		$select->where(new \Zend\Db\Sql\Predicate\In('qc_cat_id',$catids));
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result 	= $result->getResource()->fetchAll();
	}
	
	public function famousCategories($flag=null)
	{
		
		$select = $this->tableGateway->getSql()->select();		
		$select->where('qc_categories.qc_cat_popular = :qc_cat_popular');
		$select->where('qc_categories.qc_cat_status = :qc_cat_status');
		$select->order('qc_categories.qc_cat_id DESC');
		if($flag == "")
		{
			$count = 8;
			$select->limit($count);
		}
		else if($flag == 1)
		{
			$count = 10;
			$select->limit($count);
			
		}		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_cat_popular' => 1,'qc_cat_status'=>1); 
		$result 	= $statement->execute($data);
		$result 	= $result->getResource()->fetchAll();
		return ($result);	
		
	}
	public function famousTopics()
	{		
		$select = $this->tableGateway->getSql()->select();		
		$select->where('qc_categories.qc_cat_popular = :qc_cat_popular');
		$select->where('qc_categories.qc_cat_status = :qc_cat_status');
		$select->where('qc_categories.qc_cat_id != :qc_cat_id');
		$select->order('qc_categories.qc_cat_id DESC');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_cat_popular' => 1,'qc_cat_status'=>1,'qc_cat_id'=>1); 
		$result 	= $statement->execute($data);
		$result 	= $result->getResource()->fetchAll();
		return ($result);		
	}
}