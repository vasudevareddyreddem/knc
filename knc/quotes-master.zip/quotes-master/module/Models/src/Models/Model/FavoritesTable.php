<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class FavoritesTable
{
    protected $tableGateway;
	protected $select;
	protected $rwvTg;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select 		= new Select();
		$this->rwvTg 		= new TableGateway('qc_favorites', $this->tableGateway->getAdapter());
		$this->viewTd 		= new TableGateway('qc_views', $this->tableGateway->getAdapter());
    }
	// check favourite
	public function checkFav($uid,$quoteId){		
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('fav_u_id  = :fav_u_id');
		$select->where('fav_qc_id  = :fav_qc_id');
		$select->where('fav_status  = :fav_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('fav_u_id' => $uid, 'fav_qc_id' => $quoteId,'fav_status' => 1); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// count of favourites
	public function usersFavQtsCount(){	
		$this->select = new Select('fav_qc_id');		
		$select = $this->tableGateway->getSql()->select();
		$select->columns(array('quotesCount' => new \Zend\Db\Sql\Expression('COUNT(*)')));		
		$select->group('fav_qc_id');
		$select->order('fav_qc_id DESC');
		$select->limit(5);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);		
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function addFavorite($fav_u_id,$fav_qc_id){		
		$data = array(
			'fav_u_id' 	  	           => $fav_u_id,
			'fav_qc_id' 	  	       => $fav_qc_id,
			'fav_status' 	  	       => 1,
			'fav_created_at' 	  	   => date('Y-m-d H:i:s'),
		);	
		$select 	= $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();		
	}
	public function updateFavorite($fav_u_id,$fav_qc_id){		
		$select = $this->tableGateway->getSql()->select();
		$select->where('fav_u_id  = :fav_u_id');			
		$select->where('fav_qc_id = :fav_qc_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('fav_u_id' => $fav_u_id,'fav_qc_id' => $fav_qc_id,); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;
	}
	public function getFavorite($fav_id,$status){		
		$data = array(			
			'fav_status' 	  	       => $status,
			'fav_created_at' 	  	   => date('Y-m-d H:i:s'),
		);	
		$select 	= $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('fav_id = "'.$fav_id.'"');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();	
	}
	public function userFavorites($fav_u_id,$count){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_users','qc_users.u_id=qc_favorites.fav_u_id',array('*'),'left');
		$select->join('qc_user_info','qc_users.u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->join('qc_quotes','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->where('fav_u_id= "'.$fav_u_id.'"');					 
		$select->where('fav_status= 1');					 
		$resultSet = $this->tableGateway->selectWith($select);		
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
		$paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	public function delFavorite($uid,$qid)
	{
		$row = $this->tableGateway->delete(array('fav_u_id' => $uid,'fav_qc_id'=>$qid));
		return $row;
	}
	
	public function favQuotesCount($loggedInId=null)
	{
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('fav_u_id  = :fav_u_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('fav_u_id' => $loggedInId); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// My Favorites Count
	public function myFavoritesCnt($fav_u_id)
	{
		$select = $this->tableGateway->getSql()->select();
		$select->where('fav_u_id  = :fav_u_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('fav_u_id' => $fav_u_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// Count Favorite for each Quote
	public function countEachQuote($qc_id)
	{
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('fav_qc_id  = :fav_qc_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('fav_qc_id' => $qc_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
}