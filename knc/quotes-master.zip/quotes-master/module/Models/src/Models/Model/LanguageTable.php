<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class LanguageTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select = new Select();
    }
	// Delete the author from Db
	public function deleteLang($lang_id){
		$dataa = array(				
			'lang_id'  => $lang_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('lang_id = :lang_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute($dataa);
		return 	$resultSet;
	}
	// Check language name
	public function checkLanguage($langName){
		$select = $this->tableGateway->getSql()->select();
		$select->where('lang_name = :lang_name');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('lang_name' => $langName); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}	
	// Check language name and langid
	public function checkLanguageData($langName,$lang_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('lang_name = :lang_name');		
		$select->where('lang_id = :lang_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('lang_name' => $langName,'lang_id'=>$lang_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// Get all languages list	
	public function languagesList(){
		$select = $this->tableGateway->getSql()->select();
		$select->order('lang_id DESC');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}	
	// Add new language
	public function addLanguage($langData){
		if(isset($langData['lang_name']) && $langData['lang_name']!=""){
			$langname = $langData['lang_name'];
		}else{
			$langname = "";
		}
		$data = array(
			'lang_name'		   =>	$langname,
			'lang_created_at'  =>	date('Y-m-d H:i:s'),
			'lang_updated_at'  =>	date('Y-m-d H:i:s'),
			'lang_status'	   =>	1,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();
	}	
	// Update language
	public function updateLanguage($langData,$lang_id){
		if(isset($langData['lang_name']) && $langData['lang_name']!=""){
			$langname = $langData['lang_name'];
		}else{
			$langname = "";
		}
		$data = array(
			'lang_name'		   =>	$langname,
			'lang_updated_at'  =>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('lang_id = "'.$lang_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}		
	// Get language id data
	public function getLanguageData($lang_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('lang_id = :lang_id');			
		$data 		= array('lang_id' => $lang_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	// Delete language
	public function updateLanguageStatus($lang_id,$status)
    {
		$data = array(
			'lang_updated_at'	=>	date('Y-m-d H:i:s'),
			'lang_status'		=>	$status,
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('lang_id = "'.$lang_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}	
}