<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class ForgotPasswordTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select = new Select();
    }
	//add token
	public function addForgetpwd($uId,$token){
		$data = array(
			'ft_u_id' 	    	=> $uId,
			'ft_token_code'     => $token,				
			'ft_created_at'  	=> date('Y-m-d H:i:s'),
			'ft_status' 	    => 1,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();
	}
	// update token
	public function updateForgetpwd($ft_id,$token){
		$data 	= array(
			'ft_token_code'     => $token,				
			'ft_updated_at'  	=> date('Y-m-d H:i:s'),
		);
		$select 	= $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('ft_u_id = "'.$ft_id.'"');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	// checkng user id of forgot link
	public function getmailfromfgtpwd($ft_u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('ft_u_id = :ft_u_id');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('ft_u_id' => $ft_u_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	public function gettoken($token){
		$select = $this->tableGateway->getSql()->select();
		$select->where('ft_token_code = :ft_token_code');			
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('ft_token_code' => $token); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;	
	}
	// checking user id of forgot mail
	public function checkForgotMail($uid){
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('ft_u_id = :ft_u_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('ft_u_id' => $uid); 
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	// check token
	public function checktoken($uid,$token){
		$select = $this->tableGateway->getSql()->select();		
		$select->where('ft_u_id = :ft_u_id');
		$select->where('ft_token_code = :ft_token_code');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('ft_u_id' => $uid,'ft_token_code'=>$token); 
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	// delete token
	public function deletetoken($u_id)
    {
		
		$row = $this->tableGateway->delete(array('ft_u_id' => $u_id));
		return $row;
		
	}
	
}