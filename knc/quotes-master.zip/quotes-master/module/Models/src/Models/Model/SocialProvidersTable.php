<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class SocialProvidersTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select = new Select();
    }
	public function addSocialProvide($gd_scl_u_id,$user){
		if(isset($user['id']) && $user['id']!=""){
			$scl_unique_id = $user['id'];
		}else{
			$scl_unique_id = '';
		}
		$data = array(
			'sp_u_id' 	  	   => $gd_scl_u_id,
			'sp_su_id' 	  	   => $scl_unique_id,
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function checkProvider($user){
		$select = $this->tableGateway->getSql()->select()			
				->where('sp_su_id= "'.$user['id'].'"');					 
		$resultSet = $this->tableGateway->selectWith($select);	
        return $resultSet->current();
	}
	public function fbaddSocialProvide($sp_su_id,$uid){
		if(isset($sp_su_id) && $sp_su_id!=""){
			$scl_unique_id = $sp_su_id;
		}else{
			$scl_unique_id = '';
		}
		$data = array(
			'sp_u_id' 	  	   => $uid,
			'sp_su_id' 	  	   => $scl_unique_id,
		);	
		$insertresult=$this->tableGateway->insert($data);	
		return $this->tableGateway->lastInsertValue;	
	}
	public function fbcheckProvider($sp_su_id){
		$select = $this->tableGateway->getSql()->select()			
				->where('sp_su_id= "'.$sp_su_id.'"');					 
		$resultSet = $this->tableGateway->selectWith($select);	
        return $resultSet->current();
	}
}