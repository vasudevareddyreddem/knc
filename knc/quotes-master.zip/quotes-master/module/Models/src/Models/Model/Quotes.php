<?php
namespace Models\Model;
class Quotes
{	
	public $fav;
	public $viewCounnt;
	
	public function exchangeArray($data)
    {
       $this->fav         = (isset($data['fav']))          ? $data['fav']        : null;
       $this->viewCounnt  = (isset($data['viewCounnt']))   ? $data['viewCounnt'] : null;        
	}	
	// Add the following method:
	public function getArrayCopy()
	{
		return get_object_vars($this);
	}
	
}