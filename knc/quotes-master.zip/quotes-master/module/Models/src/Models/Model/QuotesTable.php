<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class QuotesTable
{
    protected $tableGateway;
	protected $select;
	protected $rwvTg;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select 	= new Select();
		$this->rwvTg 	= new TableGateway('qc_favorites', $this->tableGateway->getAdapter());
		$this->viewTd 	= new TableGateway('qc_views', $this->tableGateway->getAdapter());
		$this->quotesCat 	= new TableGateway('qc_quote_categories', $this->tableGateway->getAdapter());
    }
	public function getAllPictureQuotes(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_picture_quote','qc_quotes.qc_id=qc_picture_quote.qc_pic_quote_qc_id',array('*'),'left');
		$select->where('qc_quotes.qc_type = "3"');
		$select->order('qc_quotes.qc_id DESC');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function getAllEmptyPictureQuotes(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_picture_quote','qc_quotes.qc_id=qc_picture_quote.qc_pic_quote_qc_id',array('*'),'left');
		$select->where('qc_quotes.qc_type = "3"');
		$select->group('qc_picture_quote.qc_pic_quote_picture_original');
		$select->order('qc_quotes.qc_id DESC');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function addMakeQuoteuser($qc_img,$qc_u_id,$qc_name,$qc_pic_bottom){
		$data = array(
			'qc_u_id'		    => $qc_u_id,
			'qc_au_id'		    => $qc_u_id,
			'qc_name'		    => $qc_name,
			'qc_pic_bottom'		=> $qc_pic_bottom,
			'qc_image'	        => $qc_img,
			'qc_lang_id'	    => 1,
			'qc_type'	        => 2,
			'qc_created_at'	    => date('Y-m-d H:i:s'),
			'qc_status'		    => 0,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();	
	}
	// Raw Sql Exceute Query example	
	public function querysqls(){
	$sql = "SELECT qc_quotes.qc_id, qc_quotes.qc_name, a.au_fname FROM qc_quotes
	INNER JOIN (SELECT RAND()*(SELECT MAX(qc_id) FROM qc_quotes) AS ID) AS t ON qc_quotes.qc_id >= t.ID
	INNER JOIN qc_authors AS a ON qc_quotes.qc_au_id = a.au_id
	INNER JOIN qc_quote_categories AS b ON qc_quotes.qc_id = b.qcat_qc_id
	WHERE qc_quotes.qc_status=1 And b.qcat_qc_cat_id=1	ORDER BY qc_quotes.qc_id LIMIT 1";
	$resultSet = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
	return $resultSet->current();
	}
	// End
	public function QuoteFavCount($qc_fav_count,$qc_id){
		$data = array(			
			'qc_fav_count' 	  	       => $qc_fav_count,
		);	
		$select 	= $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_id = "'.$qc_id.'"');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result = $statement->execute();
		$result =1;
		return $result =1;
	}
	public function authorQuotesCnt($qc_au_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('qc_au_id = :qc_au_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_au_id' => $qc_au_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	public function langQuotesCnt($qc_lang_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('qc_lang_id = :qc_lang_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_lang_id' => $qc_lang_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// Delete Quote
	public function deleteQuote($qc_id){
		$dataa = array(				
			'qc_id'  => $qc_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('qc_id = :qc_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$statement->execute($dataa);
		$resultSet = $statement->execute($dataa);	
		return  $resultSet;	
	}
	// Random Quote 
	public function randomQuote(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$rand = new \Zend\Db\Sql\Expression('RAND()');
        $select->order($rand);
        $select->limit(1); 	
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute()->current();
		return $result;		
	}// Best User Quote
	public function bestUserQuote(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_best_user_quote  = :qc_best_user_quote');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_best_user_quote' => 1); 
		$result 	= $statement->execute($data)->current();
		return $result;		
	}
	
	// App Quote of the day
	public function frontquoteoftheday(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_quote_of_the_day  = :qc_quote_of_the_day');
		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_quote_of_the_day' => 1); 
		$result 	= $statement->execute($data)->current();
		return $result;		
	}	
	
	// Web Quote of the day
	public function quoteoftheday($flag=null){
		$currentDate    = date("Y-m-d");
		$favSubQuerySelect = $this->rwvTg->getSql()->select();
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->group('fav_qc_id');		
		$favSubQuerySelect->where('qc_favorites.fav_status="1"');
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select->where('qc_quote_of_the_day   = 1');		
		$select->where('qc_quote_of_day_date <= "'.$currentDate.'"');		
		$select->group('qc_quotes.qc_id');

		if($flag == 1)
		{
			$select->order('qc_quotes.qc_quote_of_day_date DESC');
		}
		
		
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator = new Paginator($paginatorAdapter);
		return $paginator;
			
	}
	// Get all quotes list	
	public function quotesList($flag=null){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->order('qc_quotes.qc_id DESC');
		if($flag == 1)
		{
			$select->limit(5);
		}
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}	
	// Admin Quotes List 
	
	public function adminquotesList(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');	
		$select->where('qc_quotes.qc_type != "2"');
		$select->where('qc_quotes.qc_u_id IS NULL OR qc_quotes.qc_u_id = ""');
		$select->order('qc_quotes.qc_id DESC');
		$select->group('qc_quotes.qc_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	//User Quotes List
	public function adminquotesUserList(){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');	
		$select->join('qc_users','qc_users.u_id=qc_quotes.qc_u_id',array('*'),'left');	
		$select->where('qc_quotes.qc_type != "2"');
		$select->where('qc_quotes.qc_u_id != ""');
		$select->order('qc_quotes.qc_id DESC');
		$select->group('qc_quotes.qc_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function adminsidequotesList(){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->where('qc_quote_categories.qcat_qc_cat_id = 1');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');		
		$select->order('qc_quotes.qc_quote_of_day_date DESC');
		$select->group('qc_quotes.qc_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	// Add quote for Apps
	public function addQuoteuser($quoteData,$qc_au_id){
		if(isset($quoteData['u_id']) && $quoteData['u_id']!=""){
			$uid = $quoteData['u_id'];
		}else{
			$uid = "";
		}
		if(isset($qc_au_id) && $qc_au_id!=""){
			$auid = $qc_au_id;
		}else{
			$auid = "";
		}		
		if(isset($quoteData['qc_lang_id']) && $quoteData['qc_lang_id']!=""){
			$langid = $quoteData['qc_lang_id'];
		}else{
			$langid = "";
		}
		if(isset($quoteData['qc_name']) && $quoteData['qc_name']!=""){
			$qcname = $quoteData['qc_name'];
		}else{
			$qcname = "";
		}		
		if(isset($quoteData['qc_tags']) && $quoteData['qc_tags']!=""){
			$qctags = $quoteData['qc_tags'];
		}else{
			$qctags = "";
		}
		$data = array(
			'qc_u_id'		    => $uid,
			'qc_au_id'		    => $auid,
			'qc_lang_id'	    => $langid,
			'qc_name'	        => $qcname,
			'qc_tags'	        => $qctags,
			'qc_created_at'	    => date('Y-m-d H:i:s'),
			'qc_status'		    => 0,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();	
	}	
	
	// Add new quote
	public function addQuote($quoteData){
		/* if(isset($quoteData['qc_u_id']) && $quoteData['qc_u_id']!=""){
			$uid = $quoteData['qc_u_id'];
		}else{
			$uid = "";
		} */
		if(isset($quoteData['qc_au_id']) && $quoteData['qc_au_id']!=""){
			$auid = $quoteData['qc_au_id'];
		}else{
			$auid = "";
		}		
		if(isset($quoteData['qc_lang_id']) && $quoteData['qc_lang_id']!=""){
			$langid = $quoteData['qc_lang_id'];
		}else{
			$langid = "";
		}
		if(isset($quoteData['qc_name']) && $quoteData['qc_name']!=""){
			$qcname = $quoteData['qc_name'];
		}else{
			$qcname = "";
		}
		if(isset($quoteData['qc_image']) && $quoteData['qc_image']!=""){
			$qcimage = $quoteData['qc_image'];
		}else{
			$qcimage = null;
		}		
		// if(isset($quoteData['qc_qc_cat_id']) && $quoteData['qc_qc_cat_id']!=""){
			// /* $catid  = "";
			// $catids = "";
			// foreach($quoteData['qc_qc_cat_id'] as $catidss){
			 // */  //$catids .= $catidss.',';
			  // $catid = rtrim($quoteData['qc_qc_cat_id']);
			// /* } */
		// }else{
			  // $catid = '';
		// }
		$catid ="";
		if(isset($quoteData['qc_movie']) && $quoteData['qc_movie']!=""){
			$qcmovie = $quoteData['qc_movie'];
		}else{
			$qcmovie = "";
		}
		if(isset($quoteData['qc_additional_1']) && $quoteData['qc_additional_1']!=""){
			$qcadditional1 = $quoteData['qc_additional_1'];
		}else{
			$qcadditional1 = "";
		}
		if(isset($quoteData['qc_additional_2']) && $quoteData['qc_additional_2']!=""){
			$qcadditional2 = $quoteData['qc_additional_2'];
		}else{
			$qcadditional2 = "";
		}
		if(isset($quoteData['qc_additional_3']) && $quoteData['qc_additional_3']!=""){
			$qcadditional3 = $quoteData['qc_additional_3'];
		}else{
			$qcadditional3 = "";
		}
		if(isset($quoteData['qc_tags']) && $quoteData['qc_tags']!=""){
			$qctags = $quoteData['qc_tags'];
		}else{
			$qctags = "";
		}
		if(isset($quoteData['qc_clip']) && $quoteData['qc_clip']!=""){
			$qcclip = $quoteData['qc_clip'];
		}else{
			$qcclip = "";
		}
		if(isset($quoteData['qc_quote_short_flag']) && $quoteData['qc_quote_short_flag']!=""){
			$qc_quote_short_flag = $quoteData['qc_quote_short_flag'];
		}else{
			$qc_quote_short_flag = "";
		}
		$data = array(
			// 'qc_u_id'		    => $uid,
			'qc_au_id'		    => $auid,
			'qc_qc_cat_id'		=> $catid,
			'qc_lang_id'	    => $langid,
			'qc_name'	        => $qcname,
			'qc_image'	        => $qcimage,
			'qc_movie'	        => $qcmovie,
			'qc_additional_1'	=> $qcadditional1,
			'qc_additional_2'	=> $qcadditional2,
			'qc_additional_3'	=> $qcadditional3,
			'qc_tags'	        => $qctags,
			'qc_clip'	        => $qcclip,
			'qc_created_at'	    => date('Y-m-d H:i:s'),
			'qc_updated_at'   	=> date('Y-m-d H:i:s'),
			'qc_status'		    => 1,
			'qc_quote_short_flag' => $qc_quote_short_flag,
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();	
	}	
	// updateUserQuote
	public function updateUserQuote($quoteData,$qcid){
		if(isset($quoteData['qc_au_id']) && $quoteData['qc_au_id']!=""){
			$auid = $quoteData['qc_au_id'];
		}else{
			$auid = "";
		}		
		if(isset($quoteData['qc_lang_id']) && $quoteData['qc_lang_id']!=""){
			$langid = $quoteData['qc_lang_id'];
		}else{
			$langid = "";
		}
		if(isset($quoteData['qc_name']) && $quoteData['qc_name']!=""){
			$qcname = $quoteData['qc_name'];
		}else{
			$qcname = "";
		}
		if(isset($quoteData['qc_image']) && $quoteData['qc_image']!=""){
			$qcimage = $quoteData['qc_image'];
		}else{
			$qcimage = "";
		}
		if(isset($quoteData['qc_qc_cat_id']) && $quoteData['qc_qc_cat_id']!=""){
				$catid  = "";
		}else{
			  $catid = '';
		}
		if(isset($quoteData['qc_movie']) && $quoteData['qc_movie']!=""){
			$qcmovie = $quoteData['qc_movie'];
		}else{
			$qcmovie = "";
		}
		if(isset($quoteData['qc_additional_1']) && $quoteData['qc_additional_1']!=""){
			$qcadditional1 = $quoteData['qc_additional_1'];
		}else{
			$qcadditional1 = "";
		}
		if(isset($quoteData['qc_additional_2']) && $quoteData['qc_additional_2']!=""){
			$qcadditional2 = $quoteData['qc_additional_2'];
		}else{
			$qcadditional2 = "";
		}
		if(isset($quoteData['qc_additional_3']) && $quoteData['qc_additional_3']!=""){
			$qcadditional3 = $quoteData['qc_additional_3'];
		}else{
			$qcadditional3 = "";
		}
		if(isset($quoteData['qc_tags']) && $quoteData['qc_tags']!=""){
			$qctags = $quoteData['qc_tags'];
		}else{
			$qctags = "";
		}
		if(isset($quoteData['qc_clip']) && $quoteData['qc_clip']!=""){
			$qcclip = $quoteData['qc_clip'];
		}else{
			$qcclip = "";
		}
		$data = array(
			'qc_au_id'		    => $auid,
			'qc_qc_cat_id'		=> $catid,
			'qc_lang_id'	    => $langid,
			'qc_name'	        => $qcname,
			'qc_image'	        => $qcimage,
			'qc_movie'	        => $qcmovie,
			'qc_additional_1'	=> $qcadditional1,
			'qc_additional_2'	=> $qcadditional2,
			'qc_additional_3'	=> $qcadditional3,
			'qc_tags'	        => $qctags,
			'qc_clip'	        => $qcclip,
			'qc_status'		    => 0,
			'qc_updated_at'   	=> date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_id = "'.$qcid.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}	
	// Update Quote
	public function updateQuote($quoteData,$qcid){
		if(isset($quoteData['qc_au_id']) && $quoteData['qc_au_id']!=""){
			$auid = $quoteData['qc_au_id'];
		}else{
			$auid = "";
		}		
		if(isset($quoteData['qc_lang_id']) && $quoteData['qc_lang_id']!=""){
			$langid = $quoteData['qc_lang_id'];
		}else{
			$langid = "";
		}
		if(isset($quoteData['qc_name']) && $quoteData['qc_name']!=""){
			$qcname = $quoteData['qc_name'];
		}else{
			$qcname = "";
		}
		if(isset($quoteData['qc_image']) && $quoteData['qc_image']!=""){
			$qcimage = $quoteData['qc_image'];
		}else{
			$qcimage = "";
		}
		if(isset($quoteData['qc_qc_cat_id']) && $quoteData['qc_qc_cat_id']!=""){
				$catid  = "";
		}else{
			  $catid = '';
		}
		if(isset($quoteData['qc_movie']) && $quoteData['qc_movie']!=""){
			$qcmovie = $quoteData['qc_movie'];
		}else{
			$qcmovie = "";
		}
		if(isset($quoteData['qc_additional_1']) && $quoteData['qc_additional_1']!=""){
			$qcadditional1 = $quoteData['qc_additional_1'];
		}else{
			$qcadditional1 = "";
		}
		if(isset($quoteData['qc_additional_2']) && $quoteData['qc_additional_2']!=""){
			$qcadditional2 = $quoteData['qc_additional_2'];
		}else{
			$qcadditional2 = "";
		}
		if(isset($quoteData['qc_additional_3']) && $quoteData['qc_additional_3']!=""){
			$qcadditional3 = $quoteData['qc_additional_3'];
		}else{
			$qcadditional3 = "";
		}
		if(isset($quoteData['qc_tags']) && $quoteData['qc_tags']!=""){
			$qctags = $quoteData['qc_tags'];
		}else{
			$qctags = "";
		}
		if(isset($quoteData['qc_clip']) && $quoteData['qc_clip']!=""){
			$qcclip = $quoteData['qc_clip'];
		}else{
			$qcclip = "";
		}
		if(isset($quoteData['qc_quote_short_flag']) && $quoteData['qc_quote_short_flag']!=""){
			$qc_quote_short_flag = $quoteData['qc_quote_short_flag'];
		}else{
			$qc_quote_short_flag = "";
		}
		$data = array(
			'qc_au_id'		    => $auid,
			'qc_qc_cat_id'		=> $catid,
			'qc_lang_id'	    => $langid,
			'qc_name'	        => $qcname,
			'qc_image'	        => $qcimage,
			'qc_movie'	        => $qcmovie,
			'qc_additional_1'	=> $qcadditional1,
			'qc_additional_2'	=> $qcadditional2,
			'qc_additional_3'	=> $qcadditional3,
			'qc_tags'	        => $qctags,
			'qc_clip'	        => $qcclip,
			'qc_updated_at'   	=> date('Y-m-d H:i:s'),
			'qc_quote_short_flag' => $qc_quote_short_flag,
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_id = "'.$qcid.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}
	// Qoute of the day
	public function quoteofthedayadmin($qc_id)
    {
		$data = array(
			'qc_quote_of_the_day'	=>	0,
			'qc_updated_at'	=>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_status = "1"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$res = $statement->execute();
		if($res!=0){
			$data = array(
				'qc_quote_of_the_day'	=>	1,
				'qc_updated_at'	=>	date('Y-m-d H:i:s'),
			);
			$select = $this->tableGateway->getSql()->update();
			$select->set($data);
			$select->where('qc_id = "'.$qc_id.'"');
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			return $statement->execute();
		}
	}
	// Best of user quote
	public function bestofuserquote($qc_id)
    {
		$data = array(
			'qc_best_user_quote'	=>	0,
			'qc_updated_at'	=>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_status = "1"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$res = $statement->execute();
		if($res!=0){
			$data = array(
				'qc_best_user_quote'	=>	1,
				'qc_updated_at'	=>	date('Y-m-d H:i:s'),
			);
			$select = $this->tableGateway->getSql()->update();
			$select->set($data);
			$select->where('qc_id = "'.$qc_id.'"');
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			return $statement->execute();
		}
	}
	// Delete category
	public function updateQuotesStatus($status,$qc_id)
    {
		$data = array(
			'qc_updated_at'	=>	date('Y-m-d H:i:s'),
			'qc_status'		=>	$status,
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_id = "'.$qc_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}	
	public function updateQuotesApproveStatus($status,$qc_id)
    {
		if($status == 4){
			$sta = 0;
		}else{
			$sta = 1;
		}
		$data = array(
			'qc_updated_at'		=>	date('Y-m-d H:i:s'),
			'qc_approved'		=>	$sta,
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_id = "'.$qc_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();
	}	
	// Get quote id data
	public function getQuoteData($qc_id){
		$select = $this->tableGateway->getSql()->select();		
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_id=:qc_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);		
		$data 		= array('qc_id' => $qc_id); 
		$result 	= $statement->execute($data)->current();
		return (object)$result;		
	}
	// get user quote
	public function getUserQuote($ids){
		$uid = "";
		$QtId = "";
		if(isset($ids) && $ids != "" && !empty($ids))
		{
			$uid = base64_decode($ids['0']);
			$QtId = base64_decode($ids['1']);
		}
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_users','qc_quotes.qc_u_id=qc_users.u_id',array('*'),'left');
		$select->join('qc_user_info','qc_quotes.qc_u_id=qc_user_info.uf_u_id',array('*'),'left');
		$select->where('qc_u_id=:qc_u_id');
		$select->where('qc_id=:qc_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_id' => $QtId,'qc_u_id'=>$uid); 
		$result 	= $statement->execute($data)->current();
		return $result;		
	}
	public function userQuotes($qc_u_id,$count){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->where('qc_quotes.qc_u_id="'.$qc_u_id.'"');
		$select->group('qc_quotes.qc_id');
		$select->order('qc_quotes.qc_id DESC');
		$resultSet = $this->tableGateway->selectWith($select);		
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
		$paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	public function latestquotes($count){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->order('qc_quotes.qc_id DESC');
		$select->group('qc_quotes.qc_id');
		$select->limit($count);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	// Latest Quotes for App
	public function latestquotesApp($count){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->order('qc_quotes.qc_id DESC');
		$select->group('qc_quotes.qc_id');
		// New add
		$resultSet = $this->tableGateway->selectWith($select);	
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
		$paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}


	public function quoteInformation($qc_id){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->where('qc_quotes.qc_id=:qc_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);		
		$data 		= array('qc_id' => $qc_id);	
		$result 	= $statement->execute($data)->current();
		return $result;
	}	
	public function authorQuotes($qc_au_id,$count){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		if($qc_au_id!=""){
			$select->where('qc_quotes.qc_au_id="'.$qc_au_id.'"');
		}
		$select->group('qc_quotes.qc_id');
		$select->order('qc_quotes.qc_id DESC');
		$resultSet = $this->tableGateway->selectWith($select);	
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
		$paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
		
	}
	public function categoryQuotes($qc_qc_cat_id,$count){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_quotes.qc_qc_cat_id=:qc_qc_cat_id');
		$select->limit($count);
		$select->group('qc_quotes.qc_id');
		$select->order('qc_quotes.qc_id DESC');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_qc_cat_id' => $qc_qc_cat_id);	
		$result 	= $statement->execute($data);
		$result 	= $result->getResource()->fetchAll();
		return $result;
	}
	public function allQuotesDescFavLoad($basepagecount,$offset){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$favSubQuerySelect = $this->rwvTg->getSql()->select();		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->where('qc_favorites.fav_status="1"');
		$favSubQuerySelect->group('fav_qc_id');		
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->group('qc_quotes.qc_id');
		$select->limit(intVal($basepagecount));
		$select->offset(intVal($offset));		
		$select->order('fav DESC');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}
	public function allQuotesDescFav($ids=null,$resId){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$favSubQuerySelect = $this->rwvTg->getSql()->select();		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->where('qc_favorites.fav_status="1"');
		$favSubQuerySelect->group('fav_qc_id');		
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->group('qc_quotes.qc_id');
		$select->order('fav DESC');
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;		
	}
	
	public function shortQuotesList(){	
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('qc_quotes.qc_quote_short_flag="1"');
		$select->where('(qc_u_id = "" OR qc_u_id IS NULL)');
		$select->group('qc_quotes.qc_id');
		$select->order('qc_fav_count DESC');
		$select->limit(11);
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;		
	} 
	
	public function userQuotesList(){	
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('(qc_u_id != "" OR qc_u_id != "null")');	
		$select->where('qc_quotes.qc_approved = 1');	
		$select->limit(11);		
		$select->group('qc_quotes.qc_id');
		$select->order('qc_views.view_count DESC');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;		
	}
	
	// sub query
	public function quotessubQryList($flag = null){	
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('(qc_u_id = "" OR qc_u_id IS NULL)');
		$select->group('qc_quotes.qc_id');
		if($flag == 'short')
		{			
			$select->order('qc_id DESC');
		}else if($flag == 1){
			$select->order('qc_fav_count DESC');
		}else
		{
			$select->order('qc_views.view_count DESC');
		}		
		if($flag == 1 || $flag == 'short')
		{
			$select->limit(11);
		}		
		
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;		
	}
	// MyQuotesCount 
	public function myQuotesCnt($qc_u_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('qc_u_id = :qc_u_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_u_id' => $qc_u_id); 
		$result 	= $statement->execute($data)->count();
		return $result;		
	}
	// TopQuotes for App Mobile
	
	public function topQuotesApp($cnt)
	{
		$favSubQuerySelect = $this->rwvTg->getSql()->select();		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));		
		$favSubQuerySelect->where('qc_favorites.fav_status="1"');
		$favSubQuerySelect->group('fav_qc_id');
		
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->order('viewssubQuery.viewCounnt ASC');		
		$select->group('qc_quotes.qc_id');
		$resultSet = $this->tableGateway->selectWith($select);	
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	
	// quotes list by quote
	public function quoteViewsList($ids=null,$routeId=null){
		$user_id  = $ids['0'];
		$quote_id = $ids['1'];
		if(isset($ids['3']) && $ids['3'] == 'top'){
			$offset  = $ids['2'];	
		}else{
			$offset  = $ids['3'];	
		}			
		if((isset($ids['2']) && $ids['2'] == 'top') || (isset($ids['3']) && $ids['3'] == 'top')){
				
			$select = $this->tableGateway->getSql()->select();
			$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
			$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
			$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
			$select->limit(intVal(1));
			$select->offset(intVal($offset));				
			$select->order('qc_fav_count DESC');			
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$data 		= array();	
			$result 	= $statement->execute($data)->current();		
			return $result;
		}
	}
	//User Quote vuew list
	public function userQuoteViewsList($ids=null,$routeId=null){
		$user_id  = $ids['0'];
		$quote_id = $ids['1'];
		if(isset($ids['3']) && $ids['3'] == 'userquote'){
			$offset  = $ids['2'];	
		}else{
			$offset  = $ids['3'];	
		}			
		if((isset($ids['2']) && $ids['2'] == 'userquote') || (isset($ids['3']) && $ids['3'] == 'userquote')){
				
			$select = $this->tableGateway->getSql()->select();
			$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
			$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
			$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
			$select->where('qc_u_id != "" OR qc_u_id != "null"');
			$select->limit(intVal(1));
			$select->offset(intVal($offset));				
			$select->order('qc_fav_count DESC');			
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$data 		= array();	
			$result 	= $statement->execute($data)->current();		
			return $result;
		}
	}
	
	public function shortOffQuotesSerach($ids=null,$qcid,$offset)
	{		
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');	
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		if(isset($ids['3']) && $ids['3'] == 'short'){
			$offset  = $ids['2'];	
		}else{
			$offset  = $ids['3'];	
		}
		$select->where('qc_quotes.qc_quote_short_flag=1');					
		$select->limit(intval(1));
        $select->offset(intval($offset));
		$select->order('qc_fav_count DESC');
		$select->group('qc_quotes.qc_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array();	
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	public function categoryQuotesPre($ids=null){
		$offset   = $ids['2'];
		$catId    = 0;
		$type_id  = $ids['0'];
		$quote_id = $ids['1'];
		$auth_id  = $ids['2'];			
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		if($ids['2'] == 'cat' )	{
			$catId = $ids['0'];
			$select->where('qcat_qc_cat_id=:qcat_qc_cat_id');					
			$select->where('qc_id=:qc_id');					
			$select->order('qcat_qc_cat_id DESC');
		}else if($ids['3'] == 'cat'){
			$catId = $ids['0'];
			$select->where('qcat_qc_cat_id=:qcat_qc_cat_id');					
			$select->order('qcat_qc_cat_id DESC');
		}		
		$select->group('qc_quotes.qc_id');
		$select->limit(intVal(1));
		$select->offset(intVal($offset));	
		$quote_status = 1;
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		
		if($ids['2'] == 'cat' ){
			$data = array('qc_id'=>$quote_id,'qcat_qc_cat_id' => $catId);
		}else if($ids['3'] == 'cat'){
			$data = array('qcat_qc_cat_id' => $catId);
		}	
		$result = $statement->execute($data)->current();
		return $result;
	}
	
	public function quoteViewOrderList($ids)
	{
		$offset   = $ids['2'];
		$catId    = 0;
		$type_id  = $ids['0'];
		$quote_id = $ids['1'];
		$auth_id  = $ids['2'];	
		
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		if($ids['2'] == 'cat' )	{
			$catId = $ids['0'];
			$select->where('qcat_qc_cat_id=:qcat_qc_cat_id');					
			$select->where('qc_id=:qc_id');					
			$select->order('qcat_qc_cat_id DESC');
		}else if($ids['3'] == 'cat'){
			$catId = $ids['0'];
			$select->where('qcat_qc_cat_id=:qcat_qc_cat_id');					
			$select->order('qcat_qc_cat_id DESC');
		}else if($ids['2'] == 'auth'){
			$authId = $ids['0'];
			$select->where('qc_au_id=:qc_au_id');
			$select->where('qc_id=:qc_id');				
			$select->order('qc_id DESC');
		}else if($ids['3'] == 'auth'){
			$authId = $ids['0'];
			$select->where('qc_au_id=:qc_au_id');
			$select->order('qc_id DESC');
		}else if($ids['2'] == 'userquote'){
			$authId = $ids['0'];
			$select->where('qc_au_id=:qc_au_id');
			$select->where('qc_id=:qc_id');				
			$select->order('qc_id DESC');
		}else if($ids['3'] == 'userquote'){
			$authId = $ids['0'];
			$select->where('qc_au_id=:qc_au_id');
			$select->order('qc_id DESC');
		}else if($ids['3'] == 'short'){
			$select->where('qc_quote_short_flag=:qc_quote_short_flag');								
			$select->order('qc_fav_count DESC');
		}else if($ids['2'] == 'short'){
			$select->where('qc_quote_short_flag=:qc_quote_short_flag');								
			$select->where('qc_id=:qc_id');								
			$select->order('qc_fav_count DESC');
		}else if($ids['3'] == 'A'){
			$select->where('qc_status=:qc_status');				
			$select->order('viewCounnt DESC');
		}else if($ids['2'] == 'Quote'){
			$userId = $ids['0'];
			$speId =array('0','1');
			$select->where(new \Zend\Db\Sql\Predicate\In('qc_quotes.qc_status',$speId));
			$select->where('qc_u_id=:qc_u_id');	
			$select->where('qc_id=:qc_id');	
			$select->order('qc_id DESC');
		}else if($ids['3'] == 'Quote'){
			$userId = $ids['0'];
			$speId =array('0','1');
			$select->where(new \Zend\Db\Sql\Predicate\In('qc_quotes.qc_status',$speId));
			$select->where('qc_u_id=:qc_u_id');
			$select->order('qc_id DESC');
		}else if($ids['2'] == 'fav'){
			$userId = $ids['0'];
			$select->where('fav_u_id=:fav_u_id');	
			$select->where('qc_id=:qc_id');	
			$select->order('qc_id DESC');
		}else if($ids['3'] == 'fav'){
			$userId = $ids['0'];
			$select->where('fav_u_id=:fav_u_id');
			$select->order('qc_id DESC');
		}		
		$select->group('qc_quotes.qc_id');
		$select->limit(intVal(1));
		$select->offset(intVal($offset));	
		$quote_status = 1;
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		if($ids['2'] == 'cat' ){
			$data = array('qc_id'=>$quote_id,'qcat_qc_cat_id' => $catId);
		}else if($ids['3'] == 'cat'){
			$data = array('qcat_qc_cat_id' => $catId);
		}else if($ids['2'] == 'auth' ){
			$data = array('qc_au_id' => $authId,'qc_id'=>$quote_id);
		}else if($ids['3'] == 'auth'){
			$data = array('qc_au_id' => $authId);
		}else if($ids['2'] == 'userquote' ){
			$data = array('qc_au_id' => $authId,'qc_id'=>$quote_id);
		}else if($ids['3'] == 'userquote'){
			$data = array('qc_au_id' => $authId);
		}else if($ids['2'] == 'short'){
			$data = array('qc_id'=>$quote_id,'qc_quote_short_flag' => 1);
		}else if($ids['3'] == 'short'){
			$data = array('qc_quote_short_flag' => 1);
		}else if($ids['2'] == 'Quote' ){
			$data = array('qc_u_id' => $userId, 'qc_id'=>$quote_id);
		}else if($ids['3'] == 'Quote'){
			$data = array('qc_u_id' => $userId);
		}else if($ids['2'] == 'fav' ){
			$data = array('fav_u_id' => $userId,'qc_id'=>$quote_id);
		}else if($ids['3'] == 'fav'){
			$data = array('fav_u_id' => $userId);
		}else{
			$data = array('qc_status' => $quote_status);
		}	
		$result = $statement->execute($data)->current();
		return $result;
	}
	
	public function quoteViewListCount($ids = null)
	{
		
		if(isset($ids['0']) && $ids['0'] != "")
		{
			$id = $ids['0'];
		}
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');

			if($ids['2'] == 'cat' || $ids['3'] == 'cat'){			
				$select->where('qcat_qc_cat_id=:qcat_qc_cat_id');
			}else if($ids['2'] == 'auth' || $ids['3'] == 'auth'){
				$select->where('qc_au_id=:qc_au_id');
				
			}else if($ids['2'] == 'short' || $ids['3'] == 'short'){
				$select->where('qcat_qc_cat_id=:qcat_qc_cat_id');
			} else if($ids['2'] == 'Quote' || $ids['3'] == 'Quote')
			{
				$speId =array('0','1');
				$select->where(new \Zend\Db\Sql\Predicate\In('qc_quotes.qc_status',$speId));
				$select->where('qc_u_id=:qc_u_id');	
			}
			
			else if($ids['2'] == 'fav' ||$ids['3'] == 'fav' )
			{
				$userId = $ids['0'];
				$select->where('fav_u_id=:fav_u_id');	
			}else{
				$select->where('qc_status=:qc_status');
			} 
		$select->group('qc_quotes.qc_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		
			if($ids['2'] == 'cat' || $ids['3'] == 'cat'){
				$data 	= array('qcat_qc_cat_id' => $id); 
			}
			else if($ids['2'] == 'auth' || $ids['3'] == 'auth')
			{			
				$data 	= array('qc_au_id' => $id); 
			}else if($ids['2'] == 'short' || $ids['3'] == 'short')
			{			
				$data 	= array('qcat_qc_cat_id' => 1); 
			}else if($ids['2'] == 'Quote' || $ids['3'] == 'Quote')
			{			
				$data 	= array('qc_u_id' => $id); 
			}else if($ids['2'] == 'fav' || $ids['3'] == 'fav')
			{			
				$data 	= array('fav_u_id' => $userId); 
			}
			else{
				$data = array('qc_status' => 1); 
			}
		
		$result = $statement->execute($data)->count();
		return $result;
	}
	public function shortOffQuotes($boxesPerPage,$offset)
	{	
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');	
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('qc_quotes.qc_quote_short_flag=1');					
		$select->limit(intval($boxesPerPage));
        $select->offset(intval($offset));
		$select->order('qc_fav_count DESC');
		$select->group('qc_quotes.qc_id');		
		return $resultSet = $this->tableGateway->selectWith($select);		
	}
	
	public function shortFullQuotesList($ids=null,$resId)
	{
		$catId = 0;
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');	
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('qc_quotes.qc_quote_short_flag=1');					
		$select->order('qc_fav_count DESC');
		$select->group('qc_quotes.qc_id');		
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	public function authorQuotesBypage($auid,$boxesPerPage,$offset)
	{
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');

		// $favSubQuerySelect = $this->rwvTg->getSql()->select();		
		// $favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		// $favSubQuerySelect->group('fav_qc_id');
		// $viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		// $viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		// $select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		// $select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');		
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('qc_au_id='.$auid);	
		$select->limit(intval($boxesPerPage));
        $select->offset(intval($offset));		
		$select->order('qc_id DESC');
		$select->group('qc_quotes.qc_id');		
		$resultSet = $this->tableGateway->selectWith($select);
		return  $resultSet;
	}
	public function categoryQuotesBypage($catid,$boxesPerPage,$offset)
	{
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');

		// $favSubQuerySelect = $this->rwvTg->getSql()->select();		
		// $favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		// $favSubQuerySelect->group('fav_qc_id');
		// $viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		// $viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		// $select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		// $select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');		
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->where('subbbQuery.qcat_qc_cat_id='.$catid);	
		$select->limit(intval($boxesPerPage));
        $select->offset(intval($offset));	
		$select->order('subbbQuery.qcat_qc_cat_id DESC');
		$select->group('qc_quotes.qc_id');		
		$resultSet = $this->tableGateway->selectWith($select);
		return  $resultSet;
	}
	
	
	public function categoryWiseQtList($ids=null,$resId)
	{
		$catId = 0;
		
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');		
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		
		if(isset($ids['1']) && $ids['1'] == 'category')
		{
			if(isset($resId) && $resId!= "")
			{
				$catId = $resId;
			}
			
			$select->where('qcat_qc_cat_id='.$catId);					
			$select->order('qcat_qc_cat_id DESC');
			$select->group('qc_quotes.qc_id');
		}
		elseif(isset($ids['1']) && $ids['1'] == 'author'){
			
			if(isset($resId) && $resId!= "")
			{
				$catId = $resId;
			}
			
			$select->where('qc_au_id='.$catId);					
			$select->order('qc_id DESC');
			$select->group('qc_quotes.qc_id');
			
		}
		elseif(isset($ids['0']) && $ids['0'] == 'short')
		{
			$catId = 1;
			$select->where('qcat_qc_cat_id='.$catId);					
			$select->order('qc_id DESC');
			$select->group('qc_quotes.qc_id');
			
		}
		else{
			
			$select->where('qc_status=1');					
			$select->order('qc_views.view_count DESC');
			$select->group('qc_quotes.qc_id');
			
		}	
		
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	
	public function favQuotes($loggedInId=null,$flag=null)
	{
		$select = $this->tableGateway->getSql()->select();		
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
	    $select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_quote_categories','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');
		if(isset($flag) && $flag != "" && $flag == 'fav')
		{
			$select->where('fav_u_id ="'.$loggedInId.'"');
			$select->where('qc_status in(0,1)');

		}
		else if(isset($flag) && $flag != "" && $flag == 'quote')
		{
			$select->where('qc_status in(0,1)');
			$select->where('qc_approved in(0,1)');
			$select->where('qc_u_id ="'.$loggedInId.'"');
		}
		$select->order('qc_id  DESC');
		$select->group('qc_id');
		
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	
	public function subquerywithhelper($qid)
	{
		$favSubQuerySelect = $this->rwvTg->getSql()->select();
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id','favUId'=>'fav_u_id'));
		$favSubQuerySelect->group('fav_qc_id');		
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->where('vupCatId=:vupCatId'); 
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);		
		$data = array('vupCatId' => $qid);
		
		$result = $statement->execute($data)->current();
		return $result;
	}
	public function serachQuoteAjax($serachTerm,$boxesPerPage,$offset){
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');

		$favSubQuerySelect = $this->rwvTg->getSql()->select();		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->group('fav_qc_id');
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');		
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');	
		$select->columns(array(new \Zend\Db\Sql\Expression("MATCH(qc_name,qc_tags) AGAINST('+".$serachTerm."*') AS curso"),'*'))->where("MATCH(qc_quotes.qc_name,qc_quotes.qc_tags) AGAINST('+".$serachTerm."*' in boolean mode)");
		$select->limit(intval($boxesPerPage));
        $select->offset(intval($offset));	
		$select->order('fav DESC');
		$select->group('qc_quotes.qc_id');			
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;		
	}
	public function searchQtList($searchedItem)
	{
		$qcSubQuerySelect 	= $this->quotesCat->getSql()->select();
		$qcSubQuerySelect->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');

		$favSubQuerySelect = $this->rwvTg->getSql()->select();		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->group('fav_qc_id');
		// $viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		// $viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbbQuery' => $qcSubQuerySelect), 'qc_quotes.qc_id=qcat_qc_id',array('*'),'left');
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		// $select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');		
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');		
		$select->columns(array(new \Zend\Db\Sql\Expression('MATCH(qc_name,qc_tags) AGAINST("*'.$searchedItem.'*") AS curso'),'*'))->where('MATCH(qc_quotes.qc_name,qc_quotes.qc_tags) AGAINST("*'.$searchedItem.'*" in boolean mode)');
		$select->order('curso DESC');
		$select->group('qc_quotes.qc_id');			
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	//SearchResults for App
	public function searchQtListforApp($searchedItem)
	{
		$select = $this->tableGateway->getSql()->select();		
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
	    $select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->join('qc_quote_categories','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');		
		$select->columns(array(new \Zend\Db\Sql\Expression("MATCH(qc_name,qc_tags) AGAINST('+".$searchedItem."*') AS curso"),'*'))->where("MATCH(qc_name,qc_tags) AGAINST('+".$searchedItem."*' in boolean mode)");
		$select->order('qc_id DESC');
		$select->group('qc_quotes.qc_id');			
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;   
	}
	// website add quote
	public function addUserQuote($quoteData,$imgName,$flag=null){
		if(isset($quoteData['username']) && $quoteData['username']!=""){
			$username = $quoteData['username'];
		}else{
			$username = "";
		}	
		
		if(isset($quoteData['quoteText']) && $quoteData['quoteText']!=""){
			$qcname = $quoteData['quoteText'];
		}else{
			$qcname = "";
		}
		if(isset($imgName) && $imgName!=""){
			$qcimage = $imgName;
		}else{
			$qcimage = "";
		}		
		if(isset($quoteData['sessionId']) && $quoteData['sessionId']!=""){			
			  $uid = rtrim($quoteData['sessionId']);
			
		}else{
			  $uid = '';
		}
		if(isset($quoteData['qc_au_id']) && $quoteData['qc_au_id']!=""){			
			  $qc_au_id = rtrim($quoteData['qc_au_id']);
			
		}else{
			  $qc_au_id = '';
		}
		if(isset($quoteData['qc_qc_cat_id']) && $quoteData['qc_qc_cat_id']!=""){			
			  $qc_qc_cat_id = $quoteData['qc_qc_cat_id'];
			
		}else{
			  $qc_qc_cat_id = '';
		}
		if(isset($quoteData['qc_id']) && $quoteData['qc_id']!=""){			
			  $qc_id = $quoteData['qc_id'];
			
		}else{
			  $qc_id = '';
		}
		if(isset($quoteData['qc_lang_id']) && $quoteData['qc_lang_id']!=""){			
			  $qc_lang_id = $quoteData['qc_lang_id'];
			
		}else{
			  $qc_lang_id = '';
		}
		if(isset($quoteData['qc_tags']) && $quoteData['qc_tags']!=""){			
			  $qc_tags = $quoteData['qc_tags'];
			
		}else{
			  $qc_tags = '';
		}
		
		$data = array(
			'qc_u_id'		    => $uid,
			'qc_au_id'		    => $qc_au_id,
			'qc_qc_cat_id'		=> $qc_qc_cat_id,
			'qc_lang_id'		=> $qc_lang_id,
			'qc_tags'		    => $qc_tags,
			'qc_name'	        => $qcname,
			'qc_image'	        => $qcimage,
			'qc_created_at'	    => date('Y-m-d H:i:s'),
			'qc_updated_at'   	=> date('Y-m-d H:i:s'),
			'qc_status'		    => 0,
		);
		if($flag == 'add')
		{
			$data['qc_approved']	= 0;
			$select = $this->tableGateway->getSql()->insert();
			$select->values($data);
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$result 	= $statement->execute();
			return $result->getGeneratedValue();
		}else if($flag == 'update'){
			$select = $this->tableGateway->getSql()->update();
			$select->set($data);
			$select->where('qc_id = "'.$qc_id.'"');			
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$result 	= $statement->execute();
			return $result->getGeneratedValue();

		}
			
	}
	public function delQuote($qc_id)
	{
		$dataa = array(				
			'qc_id'  => $qc_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('qc_id = :qc_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute($dataa);
	}
	
	public function searchQuoteView($ids)
	{
		$offset = $ids['2'];
		$favSubQuerySelect = $this->rwvTg->getSql()->select();
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();
		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->group('fav_qc_id');			
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();	
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
	    $select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->join('qc_quote_categories','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');		
		$select->columns(array(new \Zend\Db\Sql\Expression("MATCH(qc_name,qc_tags) AGAINST('+".$ids['1']."*') AS curso"),'*'))->where("MATCH(qc_name,qc_tags) AGAINST('+".$ids['1']."*' in boolean mode)");
		$select->order('qc_id DESC');
				
		$select->group('qc_quotes.qc_id');
		
		$select->limit(intVal(1));
		$select->offset(intVal($offset));
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet->current(); 
	}
	
	public function searchQuoteViewList($ids)
	{
		$favSubQuerySelect = $this->rwvTg->getSql()->select();
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();
		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->group('fav_qc_id');			
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		$select = $this->tableGateway->getSql()->select();	
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
	    $select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->join('qc_quote_categories','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');		
		$select->columns(array(new \Zend\Db\Sql\Expression("MATCH(qc_name,qc_tags) AGAINST('+".$ids['1']."*') AS curso"),'*'))->where("MATCH(qc_name,qc_tags) AGAINST('+".$ids['1']."*' in boolean mode)");
		$select->where('qc_id = "'.$ids['4'].'"');			

		$select->order('qc_id DESC');
		$select->limit(intVal(1));

		$select->group('qc_quotes.qc_id');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet->current(); 
	}
	public function searchQtListCount($searchedItem)
	{
		$select = $this->tableGateway->getSql()->select();		
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
	    $select->join('qc_favorites','qc_quotes.qc_id=qc_favorites.fav_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_views','qc_quotes.qc_id=qc_views.view_qc_id',array('*'),'left');
		$select->join('qc_quote_categories','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');		
		$select->columns(array(new \Zend\Db\Sql\Expression("MATCH(qc_name,qc_tags) AGAINST('+".$searchedItem."*') AS curso"),'*'))->where("MATCH(qc_name,qc_tags) AGAINST('+".$searchedItem."*' in boolean mode)");
		$select->order('qc_id DESC');
		$select->group('qc_quotes.qc_id');			
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet->count();
	}
	public function adminquoteoftheday(){
		$favSubQuerySelect = $this->rwvTg->getSql()->select();
		$viewsSubQuerySelect = $this->viewTd->getSql()->select();		
		
		$favSubQuerySelect->columns(array('fav'=>new Expression('COALESCE(SUM(fav_status),0)'),'vupCatId'=>'fav_qc_id'));
		$favSubQuerySelect->group('fav_qc_id');		
		$favSubQuerySelect->where('qc_favorites.fav_status="1"');
		$viewsSubQuerySelect->columns(array('viewCounnt'=>new Expression('view_count'),'viewUserId'=>'view_qc_id'));
		
		$select = $this->tableGateway->getSql()->select();
		$select->join(array('subbQuery' => $favSubQuerySelect), 'qc_quotes.qc_id=vupCatId',array('*'),'left');
		$select->join(array('viewssubbQuery' => $viewsSubQuerySelect), 'qc_quotes.qc_id=viewUserId',array('*'),'left');
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_quote_of_the_day  = 1');		
		$select->group('qc_quotes.qc_id');
		$select->order('qc_quotes.qc_quote_of_day_date DESC');
		return $resultSet = $this->tableGateway->selectWith($select);			
	}
	public function setquoteofthedayadmin($qc_id,$date)
    {		
		$data = array(
			'qc_quote_of_the_day'	=>	1,
			'qc_quote_of_day_date'	=>	$date,
			'qc_updated_at'	        =>	date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->update();
		$select->set($data);
		$select->where('qc_id = "'.$qc_id.'"');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		return $statement->execute();		
	}
	public function todayQuote($cdate){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_authors','qc_quotes.qc_au_id=qc_authors.au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->join('qc_categories','qc_quotes.qc_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_quote_of_the_day   = :qc_quote_of_the_day');
		$select->where('qc_quote_of_day_date  = :qc_quote_of_day_date');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_quote_of_the_day' => 1, 'qc_quote_of_day_date'=>$cdate); 
		$result 	= $statement->execute($data)->current();
		return $result;	
	}
}