<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class QuoteViewsTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select 		= new Select();
    }
	// check favourite
	public function checkFav($uid,$quoteId){		
		$select = $this->tableGateway->getSql()->select();
		$select->where('fav_u_id  = :fav_u_id');
		$select->where('fav_qc_id  = :fav_qc_id');
		$select->where('fav_status  = :fav_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('fav_u_id' => $uid, 'fav_qc_id' => $quoteId,'fav_status' => 1); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	// insert views
	public function addQuoteView($user_id,$q_id,$exitqcvid,$view_count){
		if($exitqcvid==0){
			$data = array(
				'view_u_id' 		=> $user_id,		
				'view_qc_id' 		=> $q_id,					
				'view_created_at' 	=> date('Y-m-d H:i:s'),
				'view_count' 		=> $view_count,					
				'view_status'      	=> 1
			);
			$select = $this->tableGateway->getSql()->insert();
			$select->values($data);
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$result 	= $statement->execute();		
			return $result->getGeneratedValue();
		}else{	
			
			$data = array(
				'view_count' 		=> $view_count,	
				'view_updated_at' 	=> date('Y-m-d H:i:s'),			
			);
			$select = $this->tableGateway->getSql()->update();
			$select->set($data);			
			$select->where('view_id = "'.$exitqcvid.'"');
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			if($statement->execute())
			{
				return 1;
			}
		}	
	}
	public function addViews($ids,$view_count)
	{	
		if(isset($_SESSION['user']['userId']) && $_SESSION['user']['userId']!=""){
			if($ids['2'] == 'Auth' || $ids['3'] == 'Auth' || $ids['2'] == 'Cat' || $ids['3'] == 'Cat'){
				$user_id = 	$_SESSION['user']['userId'];
			}else{
				$user_id = 	$ids['0'];	
			}
		}else{
			$user_id = $_SERVER['REMOTE_ADDR'];			
		}	
		$quote_id = $ids['1'];
		$author_id = $ids['2'];
		if(!is_null($quote_id) && $quote_id != ""){
			$q_id = $quote_id;
		}else{
			$q_id = '';
		}
		if(!is_null($author_id) && $author_id != ""){
			$a_id = $author_id;	
		}else{
			$a_id = "";
		}
		if($view_count == 1)
		{
			$data = array(
			'view_u_id' 		=> $user_id,		
			'view_qc_id' 		=> $q_id,					
			'view_created_at' 	=> date('Y-m-d H:i:s'),
			'view_count' 		=> $view_count,					
			'view_status'      	=> 1
			);
			$select = $this->tableGateway->getSql()->insert();
			$select->values($data);
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$result 	= $statement->execute();		
			return $result->getGeneratedValue();
		}
		else{
			$data = array(
			'view_count' 	=> $view_count,	
			'view_updated_at' 	=> date('Y-m-d H:i:s'),			
			);
			$select = $this->tableGateway->getSql()->update();
			$select->set($data);			
			$select->where('view_qc_id = "'.$q_id.'"');
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			if($statement->execute())
			{
				return 1;
			}
			
		}
		
	}
	public function addQuoteViews($ids,$view_count,$qc_id)
	{	
		if(isset($_SESSION['user']['userId']) && $_SESSION['user']['userId']!=""){
			if($ids['2'] == 'Auth' || $ids['3'] == 'Auth' || $ids['2'] == 'Cat' || $ids['3'] == 'Cat'){
				$user_id = 	$_SESSION['user']['userId'];
			}else{
				$user_id = 	$ids['0'];	
			}
		}else{
			$user_id = $_SERVER['REMOTE_ADDR'];			
		}	
		$quote_id = $qc_id;
		if(!is_null($quote_id) && $quote_id != ""){
			$q_id = $quote_id;
		}else{
			$q_id = '';
		}		
		if($view_count == 1)
		{
			$data = array(
			'view_u_id' 		=> $user_id,		
			'view_qc_id' 		=> $q_id,					
			'view_created_at' 	=> date('Y-m-d H:i:s'),
			'view_count' 		=> $view_count,					
			'view_status'      	=> 1
			);
			$select = $this->tableGateway->getSql()->insert();
			$select->values($data);
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$result 	= $statement->execute();		
			return $result->getGeneratedValue();
		}
		else{
			$data = array(
			'view_count' 	=> $view_count,	
			'view_updated_at' 	=> date('Y-m-d H:i:s'),			
			);
			$select = $this->tableGateway->getSql()->update();
			$select->set($data);			
			$select->where('view_qc_id = "'.$q_id.'"');
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			if($statement->execute())
			{
				return 1;
			}
			
		}
		
	}
	
	// Check viewd App
	public function checkViewsApp($uid,$qc_id){		
		$user_id = 	$uid;
		$quote_id = $qc_id;				
		$select = $this->tableGateway->getSql()->select();		
		$select->where('view_qc_id  = :view_qc_id');
		$select->where('view_u_id   = :view_u_id');
		$select->where('view_status  = :view_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('view_qc_id' => $quote_id,'view_u_id' => $user_id,'view_status' => 1); 
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	
	// check loggedin viewers
	
	public function checkViews($ids){
		if(isset($_SESSION['user']['userId']) && $_SESSION['user']['userId']!=""){
			if($ids['2'] == 'auth' || $ids['3'] == 'auth' || $ids['2'] == 'cat' || $ids['3'] == 'cat'){
				$user_id = 	$_SESSION['user']['userId'];
			}else{
				$user_id = 	$ids['0'];	
			}
		}else{
			$user_id = $_SERVER['REMOTE_ADDR'];	
		}
		$quote_id = $ids['1'];				
		$select = $this->tableGateway->getSql()->select();		
		$select->where('view_qc_id  = :view_qc_id');
		$select->where('view_status  = :view_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('view_qc_id' => $quote_id,'view_status' => 1); 
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	public function checkQuoteViewsCount($ids,$qc_id){
		if(isset($_SESSION['user']['userId']) && $_SESSION['user']['userId']!=""){
			if($ids['2'] == 'auth' || $ids['3'] == 'auth' || $ids['2'] == 'cat' || $ids['3'] == 'cat'){
				$user_id = 	$_SESSION['user']['userId'];
			}else{
				$user_id = 	$ids['0'];	
			}
		}else{
			$user_id = $_SERVER['REMOTE_ADDR'];	
		}
		$quote_id = $qc_id;				
		$select = $this->tableGateway->getSql()->select();		
		$select->where('view_qc_id  = :view_qc_id');
		$select->where('view_status  = :view_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('view_qc_id' => $quote_id,'view_status' => 1); 
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	// get quote
	public function quotesCnt($quote_id){
						
		$select = $this->tableGateway->getSql()->select();		
		$select->where('view_qc_id  = :view_qc_id');
		$select->where('view_status  = :view_status');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('view_qc_id' => $quote_id,'view_status' => 1); 
		$result 	= $statement->execute($data)->current();
		return $result;
	}
	// Count Views for each Quote
	public function countviewQuote($qc_id)
	{
		$select 	= $this->tableGateway->getSql()->select();
		$select->where('view_qc_id  = :view_qc_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('view_qc_id' => $qc_id); 
		$result 	= $statement->execute($data);
		return $result;
	}
}