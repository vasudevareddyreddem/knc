<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class PictureQuoteTable
{
    protected $tableGateway;
	protected $select;
	protected $rwvTg;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select 	= new Select();
    }
	public function addMakeQuoteuser($quote,$quoteId,$picture,$preview){
		$data = array(
			'qc_pic_quote_qc_id'		=> $quoteId,
			'qc_pic_quote_acolor'		=> ltrim($quote['qc_pic_quote_acolor'],'#'),
			'qc_pic_quote_afont'		=> $quote['qc_pic_quote_afont'],
			'qc_pic_quote_afontsize'	=> $quote['qc_pic_quote_afontsize'],
			'qc_pic_quote_afontstyle'	=> $quote['qc_pic_quote_afontstyle'],
			'qc_pic_quote_ax'		    => $quote['qc_pic_quote_ax'],
			'qc_pic_quote_ay'		    => $quote['qc_pic_quote_ay'],
			'qc_pic_quote_bgcolor'		=> ltrim($quote['qc_pic_quote_bgcolor'],'#'),
			'qc_pic_quote_picture'		=> $picture,
			'qc_pic_quote_picture_preview' => $preview,
			'qc_pic_quote_picture_original' => $quote['qc_pic_quote_picture_original'],
			'qc_pic_quote_qalign'		=> $quote['qc_pic_quote_qalign'],
			'qc_pic_quote_qcolor'		=> ltrim($quote['qc_pic_quote_qcolor'],'#'),
			'qc_pic_quote_qfont'		=> $quote['qc_pic_quote_qfont'],
			'qc_pic_quote_qfontsize'	=> $quote['qc_pic_quote_qfontsize'],
			'qc_pic_quote_qfontstyle'	=> $quote['qc_pic_quote_qfontstyle'],
			'qc_pic_quote_qmaxheight'	=> $quote['qc_pic_quote_qmaxheight'],
			'qc_pic_quote_qwidth'		=> $quote['qc_pic_quote_qwidth'],
			'qc_pic_quote_qx'		    => $quote['qc_pic_quote_qx'],
			'qc_pic_quote_qy'		    => $quote['qc_pic_quote_qy'],
			'qc_pic_quote_created_at'	=> date('Y-m-d H:i:s'),
			'qc_pic_quote_updated_at'	=> date('Y-m-d H:i:s'),
		);
		$select = $this->tableGateway->getSql()->insert();
		$select->values($data);
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute();
		return $result->getGeneratedValue();	
	}
}