<?php
namespace Models\Model;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
class QuoteCategoriesTable
{
    protected $tableGateway;
	protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
		$this->select = new Select();
    }
	public function catQuotesCnt($qcat_qc_cat_id){
		$select = $this->tableGateway->getSql()->select();
		$select->where('qcat_qc_cat_id = :qcat_qc_cat_id');		
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qcat_qc_cat_id' => $qcat_qc_cat_id); 
		$result 	= $statement->execute($data)->count();
		return $result;
	}
	public function deleteQuoteCategories($qc_id){
		$dataa = array(				
			'qcat_qc_id'  => $qc_id
		);
		$select = $this->tableGateway->getSql()->delete();
		$select->where('qcat_qc_id = :qcat_qc_id');
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute($dataa);	
		return  $resultSet;
	}
	public function addQuotecategories($qc_cat_id,$qc_id){
		$resDemo = $this->deleteQuoteCategories($qc_id);
		foreach($qc_cat_id as $cat_id){
			$data = array(
				'qcat_qc_cat_id' 	 => $cat_id,
				'qcat_qc_id' 	  	 => $qc_id,
				'qct_status' 	  	 => 1,
				'qct_created_at' 	 => date('Y-m-d H:i:s'),
				'qct_updated_at' 	 => date('Y-m-d H:i:s'),
			);	
			$select = $this->tableGateway->getSql()->insert();
			$select->values($data);
			$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$result 	= $statement->execute();
		}
		return $result->getGeneratedValue();		
	}	
	public function getCategories($qc_id){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->where('qc_quote_categories.qcat_qc_id=:qc_id');
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$data 		= array('qc_id' => $qc_id);	
		$result 	= $statement->execute($data);
		$result 	= $result->getResource()->fetchAll();
		return $result;	
	}
	public function categoryQuotes($catid,$cnt){
		$select = $this->tableGateway->getSql()->select();
		$select->join('qc_quotes','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');
		$select->join('qc_categories','qc_quote_categories.qcat_qc_cat_id=qc_categories.qc_cat_id',array('*'),'left');
		$select->join('qc_authors','qc_authors.au_id=qc_quotes.qc_au_id',array('*'),'left');
		$select->join('qc_languages','qc_quotes.qc_lang_id=qc_languages.lang_id',array('*'),'left');
		$select->where('qc_quote_categories.qcat_qc_cat_id='.$catid);					
		$select->order('qc_quote_categories.qcat_qc_cat_id DESC');			
		$resultSet = $this->tableGateway->selectWith($select);
		$paginatorAdapter = new DbSelect(
			$select,$this->tableGateway->getAdapter(),
			$resultSet
		);
	    $paginator1 = new Paginator($paginatorAdapter);
		return $paginator1;
	}
	public function shortQuoteRefresh(){
		$select = $this->tableGateway->getSql()->select();
		$rand = new \Zend\Db\Sql\Expression('RAND()'); 
		$select->join('qc_quotes','qc_quotes.qc_id=qc_quote_categories.qcat_qc_id',array('*'),'left');
		$select->join('qc_authors','qc_authors.au_id=qc_quotes.qc_au_id',array('*'),'left');			      
		$select->where('qc_quote_categories.qcat_qc_cat_id="1"');
		 $select->order($rand);
        $select->limit(1); 
		$statement 	= $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$result 	= $statement->execute()->current();
		return $result;	
	}
}