<?php
namespace Application\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use ScnSocialAuth\Mapper\Exception as MapperException;
use ScnSocialAuth\Mapper\UserProviderInterface;
use ScnSocialAuth\Options\ModuleOptions;
use Zend\View\Model\JsonModel;
class IndexController extends AbstractActionController
{
	protected $mapper;
    protected $options;
   	public function setOptions(ModuleOptions $options){
        $this->options = $options;
        return $this;
    }	
	public function getOptions(){
        if (!$this->options instanceof ModuleOptions) {
            $this->setOptions($this->getServiceLocator()->get('ScnSocialAuth-ModuleOptions'));
        }
        return $this->options;
    }
	public function indexAction()
    {
		
		$user_session 						= new Container('user');
		$baseUrls 							= $this->getServiceLocator()->get('config');
		$baseUrlArr 						= $baseUrls['urls'];
		$baseUrl 							= $baseUrlArr['baseUrl'];
		$basePath 							= $baseUrlArr['basePath'];
		$quoteCategoriesTable       = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		if(isset($_POST['refresh']) && $_POST['refresh']==1){
			$randomQt = $quoteCategoriesTable->shortQuoteRefresh();
			$uid = 0;
			if(isset($_SESSION['user']['userId']) && $_SESSION['user']['userId'] != "")
			{
				$uid = $_SESSION['user']['userId'];
			}
			if(count($randomQt ) > 0)
			{
				$authorName     = $randomQt['au_fname'].' '.$randomQt['au_lname'];
				$qtId           = $randomQt['qc_id'];
				$quoteName      = $randomQt['qc_name'];
				$userIsfav = 0;
				$userFavTable  = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
				$countfavorites    = $userFavTable->checkFav($uid,$qtId);
				$countofviews     = 0;
				if($countfavorites>0){
					$userIsfav =1;
				}else{
					$userIsfav =0;
				}
				$html = "";
				$authName = str_replace(' ', '-', strtolower($randomQt['au_fname']));
				$url= $baseUrl."author/".$authName;
				$html='<h1 id="QtName">'.$quoteName.'</h1>';
				$html.='<a href="'.$url.'">';
				$html.='<h2>'.$authorName.'</h2></a>';
				$html.='<a href="javascript:void(0)" onclick="headerQuotefav('.$qtId.','.$uid.');" id="quoteFav_'.$qtId.'">';
				if($userIsfav1=0){
					$html.='<i class="fa fa-heart" aria-hidden="true"></i>';
				}else{
					$html.='<i class="fa fa-heart-o" aria-hidden="true"></i></a>';
				}
				$html.='<input type="hidden" name="hidUserFavorate_'.$qtId.'" id="hidUserFavorate_'.$qtId.'" value="'.$userIsfav.'">';

				return new JsonModel(array(					
						'output'    	=>  $html
					));
			}
			else
			{
				return new JsonModel(array(					
						'output'    	=>  'fail'
					));
			}
		}
		return new viewModel(array(					
			'baseUrl' 						=> 	$baseUrl,
			'basePath'   					=>  $basePath,
		));
    }
	public function headerAction($params)
    {
		$seoTitle  = "";
		$seoDecrpt = "";
		$seoUrl    = "";
		$user_session 						=  new Container('user');
		$admin_session 						= new Container('admin');		
		$baseUrls 							= $this->getServiceLocator()->get('config');
		$baseUrlArr 						= $baseUrls['urls'];
		$baseUrl 							= $baseUrlArr['baseUrl'];
		$basePath 							= $baseUrlArr['basePath'];
		$quotesTable   						= $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$famousCategoriesTable   			= $this->getServiceLocator()->get('Models\Model\CategoryFactory');		
		$famousAuthorsTable   	 			= $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$userFavTable   					= $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$famousCategoriesList 				= $famousCategoriesTable->famousCategories();			
		$famousAuthorsList 					= $famousAuthorsTable->famousAuthors();
		$quoteCategoriesTable               = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		if(($_SERVER['REQUEST_URI'] == '/stqstaging/') ||($_SERVER['REQUEST_URI'] == '/') || ($_SERVER['REQUEST_URI'] == '/quotes/trunk/') 
			|| ($_SERVER['REQUEST_URI'] == '/ea/quotes/') || (strpos($_SERVER['REQUEST_URI'], 'email-reset-pwd') !== false) || (strpos($_SERVER['REQUEST_URI'], 'email-verified') !== false)){
			$topQuotes 		= $quotesTable->quotessubQryList($flag=1)->toArray();
			$userQuotes 	= $quotesTable->userQuotesList()->toArray();	
			$shortQuotes 	= $quotesTable->shortQuotesList()->toArray();
			$favQuotesCount = $userFavTable->usersFavQtsCount();					
		}else{
			$topQuotes      = "";
			$userQuotes 	= "";
			$shortQuotes    = "";
			$favQuotesCount = "";
		}	
		$serachTerm = "";
		$serRes ="";
		global $seoGTitle;
		global $seoGDecrpt;
		global $seoGUrl;
		global $seoGImage;
		if(strpos($_SERVER['REQUEST_URI'], 'make-picture-quote') !== false){
			$seoTitle  = "Make Awesome Picture Quotes | Spread the Quote";
			$seoDecrpt = "Here you can create and share your own picture quote";
			$seoUrl    = $baseUrl.'make-picture-quote';
		}else if(strpos($_SERVER['REQUEST_URI'], 'author') !== false && strpos($_SERVER['REQUEST_URI'], 'authors') === false ){
			$seoData    = explode("/author/",$_SERVER['REQUEST_URI']);
			$seoT       = $seoData[1];
			$catn       = str_replace('-', ' ', $seoT);
			$authorName = ucfirst($catn);
			$seoTitle   = ucfirst($authorName).' Quotes - Spread the Quotes';
			$seoDecrpt  = "Share the best $authorName quotes collection with funny and wise quotes by famous authors on $authorName, aging, youth, getting old, being young, middle $authorName and more.";
			$seoUrl    = $baseUrl.'author/'.$seoT;
		}else if(strpos($_SERVER['REQUEST_URI'], 'search-quote') !== false){
			foreach($params as $paDot){
				$serRes = $paDot;
			}
			$serachTerm  = $serRes;
			$serachTermm    = str_replace('+', ' ', $serachTerm);
			$serachTermm    = str_replace("%20","'", $serachTermm);
			$seoDecrpt  = "Share Quotes of the Day with friends on Facebook, Twitter, and blogs. Enjoy our spread the quotes, Funny, Love, Art and Nature quotes.";
			$seoTitle   = ucfirst(str_replace("%20","'", $serachTerm)).' Quotes - Spread the Quotes';
			$seoUrl    = $baseUrl.'search-quote/'.$serachTermm;
		}else if(strpos($_SERVER['REQUEST_URI'], 'topquotes') !== false){
			$seoDecrpt  = "Share Quotes of the Day with friends on Facebook, Twitter, and blogs. Enjoy our spread the quotes, Funny, Love, Art and Nature quotes.";
			$seoTitle   = 'Top Quotes - Spread the Quotes';
			$seoUrl    = $baseUrl.'top-quotes';
		}else if(strpos($_SERVER['REQUEST_URI'], 'viewers') !== false){
			$idss = explode("category-",$_SERVER['REQUEST_URI']);
			$ids = explode("-",$idss[1]);
			$qcid = $ids[1];
			$getQuoteInfo = $quotesTable->quoteInformation($qcid);
			$qcName     = ucfirst($getQuoteInfo['qc_name']);
			$authorName = ucfirst($getQuoteInfo['au_fname']);
			$seoDecrpt   = $authorName.' Quotes';
			$seoTitle  = $qcName.'.. - '.$authorName.' quotes from SpreadtheQuote.com';
			$seoUrl     = $_SERVER['REQUEST_URI'];
		}else if(strpos($_SERVER['REQUEST_URI'], 'quote-of-the-day') !== false){
			$seoTitle   = 'Quote of the Day - Spread the Quotes';
			$seoDecrpt  = "Share Quotes of the Day with friends on Facebook, Twitter, and blogs. Enjoy our spread the quotes, Funny, Love, Art and Nature quotes.";
			$seoUrl    = $baseUrl.'quote-of-the-day';
		}else if(strpos($_SERVER['REQUEST_URI'], 'short-quotes-list') !== false){
			$seoTitle   = 'Short Quotes - Spread the Quotes';
			$seoDecrpt  = "Share the best short quotes collection with funny and wise quotes by famous authors on short quotes, aging, youth, getting old, being young, middle short quotes and more.";
			$seoUrl    = $baseUrl.'short-quotes-list/short-quotes';
		}else if(strpos($_SERVER['REQUEST_URI'], 'category') !== false && strpos($_SERVER['REQUEST_URI'], 'viewers') === false){
			$seoData   = explode("/category/",$_SERVER['REQUEST_URI']);
			$seoT      = $seoData[1];
			$catn = str_replace('-', ' ', $seoT);
			$catName = ucfirst($catn);
			$seoTitle  = ucfirst($catName).' Quotes - Spread the Quotes';
			$seoDecrpt = "Share the best $catName quotes collection with funny and wise quotes by famous authors on $catName, aging, youth, getting old, being young, middle $catName and more.";
			$seoUrl    = $baseUrl.'category/'.$seoT;
		}else if(strpos($_SERVER['REQUEST_URI'], 'categories') !== false){
			$seoTitle  = "Famous Categories - Spreadthequote";
			$seoDecrpt = "Find Success, Happiness, Death, Love, Friendship, Forgiveness, Fake People, Inspirational, Leadership, Life, Love, Motivational,and Positive Attitude";
			$seoUrl    = $baseUrl.'categories';
		}else if(strpos($_SERVER['REQUEST_URI'], 'authors') !== false){
			$seoTitle  = "Favorite Authors - Spreadthequote";
			$seoDecrpt = "Find great quotes by your favorite authors from Abraham Lincoln to Winston Churchill.";
			$seoUrl    = $baseUrl.'authors';
		}else{
			$seoTitle  = "Famous Quotes at Spreadthequote";
			$seoDecrpt = "Share our collection of inspirational and famous quotes by authors you know and love. Share our Quotes of the Day on the web, Facebook, Twitter, and blogs";
			$seoUrl    = $baseUrl;
		}
		// $quoteOfTheDay 	= $quotesTable->frontquoteoftheday();
		// if(isset($quoteOfTheDay) && !is_null($quoteOfTheDay) && !empty($quoteOfTheDay))
		// {
			// if(isset($quoteOfTheDay['qc_id']) && $quoteOfTheDay['qc_id']!=""){
				// $qc_id = $quoteOfTheDay['qc_id'];
				// $quotesList   = $quotesTable->getQuoteData($qc_id);
				// if(isset($quotesList->qc_id) && $quotesList->qc_id!=""){
					// $qc_quote_of_day      = strtotime($quotesList->qc_quote_of_day_date);
					// $qc_quote_of_day_date = date("Y-m-d", $qc_quote_of_day);
				// }
				// $quoteOfTheDay  = $quoteOfTheDay;
			// }
			
		// }else{
			// $quoteOfTheDay = $quoteCategoriesTable->shortQuoteRefresh();
		// }
		$currentDate    = date("Y-m-d");
		// $quoteOfTheDay 	= $quotesTable->todayQuote($currentDate);
		// if(isset($quoteOfTheDay['qc_id']) && $quoteOfTheDay['qc_id']!=""){
			 // $quoteOfTheDay = $quoteOfTheDay;
		// }else{
			 $quoteOfTheDay = $quoteCategoriesTable->shortQuoteRefresh();
		// }
		return $this->layout()->setVariable(
			"headerarray",array(
				'baseUrl' 					=> $baseUrl,
				'basePath' 					=> $basePath,	
				'quoteOfTheDay' 			=> $quoteOfTheDay,	
				'famousCatList'   			=>  $famousCategoriesList,
				'famousAuthList'   			=>  $famousAuthorsList,					
				'options'   			    =>  $this->getOptions(),	
				'topQuotes'   				=>  $topQuotes,
				'userQuotes'   				=>  $userQuotes,
				'shortQuotes'   			=>  $shortQuotes,
				'favQuotesCount'   			=>  $favQuotesCount,
				'seoTitle'   			    =>  $seoTitle,
				'seoDecrpt'   			    =>  $seoDecrpt,
				'seoUrl'   			        =>  $seoUrl,
			)
		);
	}
		public function footerAction(){
		$profiler = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter')->getProfiler();
		$queryProfiles = $profiler->getQueryProfiles();
		$profile = array();
		
		foreach($queryProfiles as $query) {
			$profile[] = $query->toArray();
		} 

		foreach($profile as $k=>$query) {
			if(count($query['parameters']) > 0 ) {
				$qry = $query['sql'];
				foreach( $query['parameters'] as $key=>$value) {
					$qry = str_replace(':'.$key, $value, $qry); 
				}
				echo '<p><b>Query</b> 	: '.$qry.   '</p>'; 
				echo $fprofile = '<p><b>Elapsed</b> : '.round($query['elapsed'], 2 , PHP_ROUND_HALF_UP). '</p>'; 
			} else {
				echo $fprofile = '<p><b>Query</b> 	: '.$query['sql'].   '</p>'; 
				echo $fprofile = '<p><b>Elapsed</b> : '.round($query['elapsed'], 2, PHP_ROUND_HALF_UP). '</p>'; 
				echo $fprofile = '<p>'.print_r($query['parameters']).'</p>';
			} 
		} 
	}

}
