<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class QuotesInformationController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
		$authorsList = $authorTable->authorsList();			
    }
	
	// Common including method file
	public function getCategoires($qc_id){
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$cat = array();
		$cat_names = ""; 
		$cateList = $quoteCategoriesTable->getCategories($qc_id);
		foreach($cateList as $key=>$catt){
			$cat[$key] = $catt['qc_cat_id'];
		}
		return $cat;	
	}
    public function get($id)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$qc_id = base64_decode($id);
		$quoteInfoo  = $quotesTable->quoteInformation($qc_id);		
		$quoteinfo = array();		
		if(isset($quoteInfoo['qc_id']) && $quoteInfoo['qc_id']!=""){
									$cat    = $this->getCategoires($qc_id);	
			$quoteInfo['qc_id'] 			= $quoteInfoo['qc_id'];
			$quoteInfo['qc_name'] 			= ucfirst($quoteInfoo['qc_name']);
			$quoteInfo['qc_image']			= $quoteInfoo['qc_image'];
			$quoteInfo['qc_tags']			= $quoteInfoo['qc_tags'];
			$quoteInfo['qc_created_at']		= $quoteInfoo['qc_created_at'];
			$quoteInfo['lang_id']			= $quoteInfoo['lang_id'];
			$quoteInfo['lang_name']			= ucfirst($quoteInfoo['lang_name']);				
			$quoteInfo['au_id']				= $quoteInfoo['au_id'];
			$quoteInfo['au_fname']			= ucfirst($quoteInfoo['au_fname']);
			$quoteInfo['au_lname']			= ucfirst($quoteInfoo['au_lname']);
			$quoteInfo['au_pic']			= $quoteInfoo['au_pic'];
			$quoteInfo['au_birth_year']		= $quoteInfoo['au_birth_year'];
			$quoteInfo['au_deadth_year']	= $quoteInfoo['au_deadth_year'];
			$quoteInfo['au_wiki_link']	    = $quoteInfoo['au_wiki_link'];
			$quoteInfo['au_descrpt']	    = $quoteInfoo['au_descrpt'];
			$quoteInfo['categories']        = $cat;				
			escape_arr($quoteInfo);
		}else{
			$quoteInfo = "";			
		}
		return new JsonModel(array(				
			'output' 		 => 	'success',
			'quotedata'      =>  $quoteInfo,
		));
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$userTable  =  $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		if(isset($data['u_id']) && $data['u_id']!=""){
			$qc_au_id = '';
			$u_id = $data['u_id'];
			$checkUser  =  $userTable->getUserData($u_id);
			if(isset($checkUser->u_id) && $checkUser->u_id!=""){				
				$dataa = array(
					'au_fname'    => ucfirst($checkUser->uf_fname),				
					'au_lname'    => ucfirst($checkUser->uf_lname),		
					'au_descrpt'  => $checkUser->uf_about_me,   
					'au_u_id'     => $checkUser->u_id,   
				);	
				$checkAuthor = $authorTable->checkAuthor($checkUser->u_id);
				if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
					$qc_au_id = $checkAuthor->au_id;	
				}else{
					$addedAuthor = $authorTable->addSQAuthor($dataa);
					if($addedAuthor){
						$qc_au_id = $addedAuthor;
					}
				}
				$qc_id = $quotesTable->addQuoteuser($data,$qc_au_id);
				if($qc_id>0){
					$addcategories = $quoteCategoriesTable->addQuotecategories($data['qc_qc_cat_id'],$qc_id);
					$myQuotesCount    = $quotesTable->myQuotesCnt($checkUser->u_id);
					$myFavoritesCount = $favoritesTable->myFavoritesCnt($checkUser->u_id);
					return new JsonModel(array(					
						'output' 			=> 'success',
						'myquotescnt'       => $myQuotesCount,   
						'myfavoritescnt'    => $myFavoritesCount,
						'status'            => 'pending',
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'serverfail',
					));	
				}
			}else{
				return new JsonModel(array(					
					'output' 	=> 'serverfail',
				));	
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'serverfail',
			));	
		}	
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($id,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
		$qc_id = base64_decode($id);
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$updateStatus = $quotesTable->updateUserQuote($data,$qc_id);		  	
		$addcategories = $quoteCategoriesTable->addQuotecategories($data['qc_qc_cat_id'],$qc_id);
		if($qc_id>0){
			return new JsonModel(array(					
				'output' 	=> 'success',
				'status'    => 'pending',
			));			
		}
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
		$qc_id = base64_decode($id);
		$baseUrls      = $this->getServiceLocator()->get('config');
		$baseUrlArr    = $baseUrls['urls'];
		$baseUrl       = $baseUrlArr['baseUrl'];
		$basePath      = $baseUrlArr['basePath'];
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$deleteQuote      = $quotesTable->deleteQuote($qc_id);
		$deleteCatQuote   = $quoteCategoriesTable->deleteQuoteCategories($qc_id);
		return new JsonModel(array(					
			'output' 	=> 'success',
			'status'    => 1
		));
		
    }
	
}