<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class QuotePostController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
		$authorsList = $authorTable->authorsList();		
		if(count($authorsList)!=0){
			escape_arr($authorsList);
		}else{
			$authorsList = "";
		}
		$cateList = $categoryTable->categoriesList();		
		if(count($cateList)!=0){
			escape_arr($cateList);
		}else{
			$cateList = "";
		}
		$langsList = $languageTable->languagesList();		
		if(count($langsList)!=0){
			escape_arr($langsList);
		}else{
			$langsList = "";
		}
		return new viewModel(array(					
			'baseUrl' 		=> 	$baseUrl,
			'basePath'   	=>  $basePath,
			'authorArray'   =>  $authorsList,
			'catArray'      =>  $cateList,
			'langArray'     =>  $langsList,
		));	
    }
    public function get($uidCount)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		if($uidCount!=""){
			$explodeData = explode('-',$uidCount);
			$qc_u_id = $explodeData[0];
			$count   = $explodeData[1];
		}			
		if($qc_u_id != ""){
			$userQuotes = $quotesTable->userQuotes($qc_u_id,$count);
			$i =0;
			if(count($userQuotes)!=0){
				foreach($userQuotes as $quoteData){
					$qc_id = (int)$quoteData['qc_id'];
					$cateList = $quoteCategoriesTable->getCategories($qc_id);
					$quotearray[$i] = $quoteData;	
					foreach($cateList as $catData){
						$quotearray[$i]['cat'][$catData['qcat_qc_cat_id']] = $catData['qc_cat_name'];
					}
					$i++;
				}
				escape_arr($quotearray);
			}else{
				$quotearray = "";
			}	
			return new JsonModel(array(
				'output' 	  => 'success',				
				'userQuotes'  => $quotearray
			));	
		}else{
			return new JsonModel(array(
				'output' 	     => 'fail',				
				'userQuotes'  => ''
			));
		}
	}
     public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$userTable  =  $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$authorTable   = $this->getServiceLocator()->get('Models\Model\AuthorFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		if(isset($data['u_id']) && $data['u_id']!=""){
			$qc_au_id = '';
			$u_id = $data['u_id'];
			$checkUser  =  $userTable->getUserData($u_id);
			if(isset($checkUser->u_id) && $checkUser->u_id!=""){				
				$dataa = array(
					'au_fname'    => ucfirst($checkUser->uf_fname),				
					'au_lname'    => ucfirst($checkUser->uf_lname),		
					'au_descrpt'  => $checkUser->uf_about_me,   
					'au_u_id'     => $checkUser->u_id,   
				);	
				$checkAuthor = $authorTable->checkAuthor($checkUser->u_id);
				if(isset($checkAuthor->au_id) && $checkAuthor->au_id!=""){
					$qc_au_id = $checkAuthor->au_id;	
				}else{
					$addedAuthor = $authorTable->addSQAuthor($dataa);
					if($addedAuthor){
						$qc_au_id = $addedAuthor;
					}
				}
				$qc_id = $quotesTable->addQuoteuser($data,$qc_au_id);
				if($qc_id>0){
					$addcategories = $quoteCategoriesTable->addQuotecategories($data['qc_qc_cat_id'],$qc_id);
					$myQuotesCount    = $quotesTable->myQuotesCnt($checkUser->u_id);
					$myFavoritesCount = $favoritesTable->myFavoritesCnt($checkUser->u_id);
					return new JsonModel(array(					
						'output' 			=> 'success',
						'myquotescnt'       => $myQuotesCount,   
						'myfavoritescnt'    => $myFavoritesCount,
						'status'            => 'pending',
					));	
				}else{
					return new JsonModel(array(					
						'output' 	=> 'serverfail',
					));	
				}
			}else{
				return new JsonModel(array(					
					'output' 	=> 'serverfail',
				));	
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'serverfail',
			));	
		}	
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
	
}