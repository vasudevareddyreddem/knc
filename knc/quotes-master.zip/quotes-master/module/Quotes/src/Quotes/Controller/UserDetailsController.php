<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class UserDetailsController extends AbstractRestfulController
{
    public function getList()
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
    public function get($u_id)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$userTable  =  $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$checkUser  =  $userTable->getUserData($u_id);
		$myQuotesCount=0;
		$myFavoritesCount=0; 
		if(isset($checkUser->u_id) && $checkUser->u_id!=""){
			$myQuotesCount    = $quotesTable->myQuotesCnt($checkUser->u_id);
			$myFavoritesCount = $favoritesTable->myFavoritesCnt($checkUser->u_id);
			$data = array(
				'firstname' => $checkUser->uf_fname,				
				'lastname'  => $checkUser->uf_lname,		
				'email'     => $checkUser->u_email,		
				'phone' 	=> $checkUser->u_mobile,   
				'uid' 	    => $checkUser->u_id,   
				'upic' 	    => $checkUser->uf_pic,   
				'aboutme'   => $checkUser->uf_about_me,   
				'gender'    => $checkUser->uf_gender,   
				'dob'       => $checkUser->uf_dob,   
				'myquotescnt'       => $myQuotesCount,   
				'myfavoritescnt'       => $myFavoritesCount,   
			);	
			return new JsonModel(array(
				'output' 	=> 'success',				
				'usData' 	=> $data,
			));			
		}else{
			return new JsonModel(array(
				'output' 	=> 'Fail',
				'usData' 	=> '',
			));
		}
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$userTable        = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userDetailsTable = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		$lastUpdatedId = $userTable->updateNormalUser($data,$uid);
		if($lastUpdatedId){
			$lastUpdatedId = $userDetailsTable->updateNormalUser($data,$uid);
			if($lastUpdatedId){
				return new JsonModel(array(
					'output' 	=> 'success',
					'success' 	=> true,
				));
			}
		}else{
			return new JsonModel(array(
				'output' 	=> 'Fail',
				'success' 	=> false,
			));
		}		
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
}