<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class SigninWithScoialController extends AbstractRestfulController
{
    public function getList()
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$mobileMessagesTable=$this->getServiceLocator()->get('Models\Model\MobileMessagesFactory');
		$getMessage = $mobileMessagesTable->getMessage();
		if($getMessage!=""){
			$message = $getMessage->mm_message;
			return new JsonModel(array(
				'output' 	=> 'success',
				'message' 	=> $message,
			));		
		}else{
			return new JsonModel(array(
				'output' 	=> 'fail',
				'message' 	=> '',
			));			
		}
    }
    public function get($uid)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
    public function create($data)
    {
		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$socialPTable=$this->getServiceLocator()->get('Models\Model\SocialProvidersFactory');
		$userTable=$this->getServiceLocator()->get('Models\Model\UserFactory');	
		$userDetailsTable=$this->getServiceLocator()->get('Models\Model\UserDetailsFactory');
		if(isset($data['loginSocial']) && $data['loginSocial']=="fbLogin"){
			$checkingProvider = $socialPTable->checkProvider($data);
			$fb_user_id = 0;
			if($checkingProvider!=''){					
				$updateEmail = $userTable->updateEmail($data,$facebook_logout='',$checkingProvider->sp_u_id);
				$getUserInfo = $userTable->getUserInfo($checkingProvider->sp_u_id);				
				$fb_user_id=$getUserInfo->u_id;
				$new_user=0;
				return new JsonModel(array(
					'output' 	    => 'success',
					'fb_user_id' 	=> $fb_user_id,
					'new_user' 	    => $new_user
				));			
			}else{
				$email = $data['email'];
				$u_social_logout = '';
				$emailChecking = $userTable->checkEmailExists($email);
				if($emailChecking=='0'){
					if($email!=""){
						$insertedUser = $userTable->addSUserProvider($data,$facebook_logout='');
						$insertedProdiver = $socialPTable->addSocialProvide($insertedUser,$data);	
						$insertedUserD = $userDetailsTable->addSUserProviderD($insertedUser,$data);
						$getUserInfo = $userTable->getUserInfo($insertedUser);
						$fb_user_id=$getUserInfo->u_id;
						$fName=$getUserInfo->ud_first_name;						
						global $welcomeSocialSubject;				
						global $welcomeSocialMessage;
						$welcomeSocialMessage = str_replace("<FULLNAME>",$fName, $welcomeSocialMessage);
						$welcomeSocialMessage = str_replace("<REGLINK>",$baseUrl, $welcomeSocialMessage);		
						sendMail($getUserInfo->u_email,$welcomeSocialSubject,$welcomeSocialMessage);
						$new_user=1;
						return new JsonModel(array(
							'output' 	    => 'success',
							'fb_user_id' 	=> $fb_user_id,
							'new_user' 	    => $new_user
						));	
					}
				}else{
					$alreadyExists='fb';
					$fbLogout='callFbLogout';
					return new JsonModel(array(
						'output' 	     => 'success',
						'alreadyExists'  => $alreadyExists,
						'logoutSoc' 	 => $fbLogout
					));
				}
			}
		}else if(isset($data['loginSocial']) && $data['loginSocial']=="gplusLogin"){
			$checkingProvider = $socialPTable->checkProvider($data);
			$fb_user_id = 0;
			if($checkingProvider!=''){					
				$updateEmail = $userTable->updateEmail($data,$facebook_logout='',$checkingProvider->sp_u_id);
				$getUserInfo = $userTable->getUserInfo($checkingProvider->sp_u_id);				
				$fb_user_id=$getUserInfo->u_id;
				$new_user=0;
				return new JsonModel(array(
					'output' 	    => 'success',
					'fb_user_id' 	=> $fb_user_id,
					'new_user' 	    => $new_user
				));			
			}else{
				$email = $data['email'];
				$u_social_logout = '';
				$emailChecking = $userTable->checkEmailExists($email);
				if($emailChecking=='0'){
					if($email!=""){
						$insertedUser = $userTable->addSUserProvider($data,$facebook_logout='');
						$insertedProdiver = $socialPTable->addSocialProvide($insertedUser,$data);	
						$insertedUserD = $userDetailsTable->addSUserProviderD($insertedUser,$data);
						$getUserInfo = $userTable->getUserInfo($insertedUser);
						$fb_user_id=$getUserInfo->u_id;
						$fName=$getUserInfo->ud_first_name;						
						global $welcomeSocialSubject;				
						global $welcomeSocialMessage;
						$welcomeSocialMessage = str_replace("<FULLNAME>",$fName, $welcomeSocialMessage);
						$welcomeSocialMessage = str_replace("<REGLINK>",$baseUrl, $welcomeSocialMessage);		
						sendMail($getUserInfo->u_email,$welcomeSocialSubject,$welcomeSocialMessage);
						$new_user=1;
						return new JsonModel(array(
							'output' 	    => 'success',
							'fb_user_id' 	=> $fb_user_id,
							'new_user' 	    => $new_user
						));	
					}
				}else{
					$alreadyExists='ge';
					$fbLogout='callgeLogout';
					return new JsonModel(array(
						'output' 	     => 'success',
						'alreadyExists'  => $alreadyExists,
						'logoutSoc' 	 => $fbLogout
					));
				}
			}		
		}
    }
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
	}
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
}