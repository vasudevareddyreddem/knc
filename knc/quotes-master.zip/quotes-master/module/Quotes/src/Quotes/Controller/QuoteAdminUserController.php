<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class QuoteAdminUserController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
			
    }
    public function get($parms)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
        $favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');		
		$dataPull   = explode('-',$parms);
		$uid        = $dataPull['1'];
		$usertigger = $dataPull['0'];
		if($usertigger == "refresh"){
			$randomQuote   = $quotesTable->randomQuote();
			$ranquote = array();
			$ranquote = $randomQuote;
			if(isset($ranquote['qc_id']) && $ranquote['qc_id']!=""){
					$qc_id         = $ranquote['qc_id'];
					$countoffav    = $favoritesTable->countEachQuote($qc_id);
					$countofviews  = $this->getQuotesViewCount($qc_id);
					$cat           = $this->getCategoires($qc_id);				
					if($uid!=0){
						$checkuserquote = $this->getIsFav($qc_id,$uid);
					}else{
						$checkuserquote = 0;
					}
					$ranquote['countoffav']    = $countoffav;
					$ranquote['countofviews']  = $countofviews;
					$ranquote['categories']    = $cat;
					$ranquote['checkquotefav'] = $checkuserquote;
					escape_arr($ranquote);		
			}
			return new JsonModel(array(
				'output' 	  => 'success',				
				'randomQuote' => $ranquote
			));
		}else{
			return new JsonModel(array(
				'output' 	=> 'fail',				
			));			
		}
	}
	public function getCategoires($qc_id){
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$cat = "";
		$cat_names = ""; 
		$cateList = $quoteCategoriesTable->getCategories($qc_id);
		foreach($cateList as $key=>$cat){
			$cat_names .= ucfirst($cat['qc_cat_name'].', ');
			$cat = rtrim($cat_names, ', ');
		}
		return $cat;	
	}
	public function getQuotesViewCount($qc_id){
		$quotesviewsTable = $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$countofviewss  = $quotesviewsTable->countviewQuote($qc_id);
		$countofviews  = 0;		
		if(count($countofviewss)!=0){
			foreach($countofviewss as $countofviewsss){
				if(isset($countofviewsss['view_id']) && $countofviewsss['view_id']!=""){
					$countofviews  += $countofviewsss['view_count'];
				}else{
					$countofviews  = 0;
				}
			}
		}else{
			$countofviews  = 0;
		}
		return $countofviews;
	}
	public function getIsFav($qc_id,$uid){
		$userIsfav = 0;
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$countfavorites    = $favoritesTable->checkFav($uid,$qc_id);
		$countofviews     = 0;
		if($countfavorites>0){
			$userIsfav =1;
		}else{
			$userIsfav =0;
		}
		
		return $userIsfav;
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$uid = $data['u_id'];
		$countoffav = 0;
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');
		$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		// if(isset($data['u_id']) && $data['u_id']!="")
		// {
		  //quote of the day
			$quoteoftheday   = $quotesTable->frontquoteoftheday();
			$quoteday = array();
			$quoteday = $quoteoftheday;
			if(isset($quoteday['qc_id']) && $quoteday['qc_id']!=""){
				    $qc_id         = $quoteday['qc_id'];
					$countoffav    = $favoritesTable->countEachQuote($qc_id);
					$countofviews  = $this->getQuotesViewCount($qc_id);
					$cat           = $this->getCategoires($qc_id);				
					if($uid!=0){
						$checkuserquote = $this->getIsFav($qc_id,$uid);
					}else{
						$checkuserquote = 0;
					}
					$quoteday['countoffav']		= $countoffav;
					$quoteday['countofviews']	= $countofviews;
					$quoteday['categories']     = $cat;
					$quoteday['checkquotefav']  = $checkuserquote;	
					escape_arr($quoteday);	
			}
            //best user quote
            $bestUserQuote   = $quotesTable->bestUserQuote();
			$bestquote = array();
			$bestquote = $bestUserQuote;
			if(isset($bestquote['qc_id']) && $bestquote['qc_id']!=""){
				    $qc_id         = $bestquote['qc_id'];
					$countoffav    = $favoritesTable->countEachQuote($qc_id);
					$countofviews  = $this->getQuotesViewCount($qc_id);
					$cat           = $this->getCategoires($qc_id);				
					if($uid!=0){
						$checkuserquote = $this->getIsFav($qc_id,$uid);
					}else{
						$checkuserquote = 0;
					}
					$bestquote['countoffav']    = $countoffav;
					$bestquote['countofviews']	= $countofviews;
					$bestquote['categories']    = $cat;
					$bestquote['checkquotefav'] = $checkuserquote;	
					escape_arr($bestquote);		
			}			
			//random quote
			$randomQuote   = $quotesTable->randomQuote();
			$ranquote = array();
			$ranquote = $randomQuote;
			if(isset($ranquote['qc_id']) && $ranquote['qc_id']!=""){
				    $qc_id         = $ranquote['qc_id'];
					$countoffav    = $favoritesTable->countEachQuote($qc_id);
					$countofviews  = $this->getQuotesViewCount($qc_id);
					$cat           = $this->getCategoires($qc_id);				
					if($uid!=0){
						$checkuserquote = $this->getIsFav($qc_id,$uid);
					}else{
						$checkuserquote = 0;
					}
					$ranquote['countoffav']    = $countoffav;
					$ranquote['countofviews']  = $countofviews;
					$ranquote['categories']    = $cat;
					$ranquote['checkquotefav'] = $checkuserquote;
					escape_arr($ranquote);	
			}	
			return new JsonModel(array(
			'output' 	        => 'success',				
			'quoteoftheday' 	=> $quoteday,
			'bestuserquote' 	=> $bestquote,
		    'randomQuote' 	    => $ranquote,
		   ));				
	    // }
		// else
		// {   
	        // return new JsonModel(array(
			// 'output' 	=> 'fail',				
			// 'quoteoftheday' 	=> '',
			// 'bestuserquote' 	=> '',
			// 'randomQuote' 	    => '',
		   // ));	
		// }
	}
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
}