<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class LanguagesController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
		$languageTable = $this->getServiceLocator()->get('Models\Model\LanguageFactory');
		$langsLists ="";
		$langsList = $languageTable->languagesList();
		$i=0;
		if(count($langsList)!=0){
			foreach($langsList as $key=>$lang){
				$langsLists[$i]['lang_id'] 		= $lang['lang_id'];
				$langsLists[$i]['lang_name'] 	= ucfirst($lang['lang_name']);				
				$i++;
			}
		}else{
			$langsLists = "";
		}	
		escape_arr($langsLists);
		return new JsonModel(array(				
			'output' 	=> 	'success',
			'langList'  =>  $langsLists,
		));
	}
	
	public function get($qcuidCnt){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
	}
     public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	public function options()
	{
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
}