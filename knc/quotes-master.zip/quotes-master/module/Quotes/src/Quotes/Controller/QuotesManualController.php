<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class QuotesManualController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
			
    }
    public function get($cnt)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$count = (int)$cnt;
		$quotesDumpTable  	= $this->getServiceLocator()->get('Models\Model\QuotesDumpFactory');	
		$quoteList		= $quotesDumpTable->quotesList($count);
		$quotess = array();	
		$i= 1;
		if(count($quoteList))
		{
			foreach($quoteList as $quotes)
			{
				$quotess[$i]['qd_id'] 	= $quotes['qd_id'];
				$quotess[$i]['qd_name'] = $quotes['qd_name'];	
				$i++;
			}
		}	
		return new JsonModel(array(
			'output' 	     => 'success',				
			'quotes'  => $quotess
		));
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		
	}
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
	
}