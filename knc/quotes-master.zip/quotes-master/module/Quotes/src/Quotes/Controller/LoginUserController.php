<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Session\Container;
class LoginUserController extends AbstractRestfulController
{
    public function getList()
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
   public function get($email)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	// Login 
    public function create($logsDetails)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		// u_email, loginwithphone, u_password
		$userTable   = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		if(isset($logsDetails)&& $logsDetails['u_email']!="" && $logsDetails['u_password']!=""){			
			$u_password = $logsDetails['u_password'];
			$errorEmailMobile = "";
			if(isset($logsDetails['loginwithemail']) && $logsDetails['loginwithemail']==1){
				if( emailChecking($logsDetails['u_email']) != 'false' ){
					$errorEmailMobile = 1;
				}else{
					$errorEmailMobile = 0;
				}
			}else if(isset($logsDetails['loginwithphone']) && $logsDetails['loginwithphone']==1){
				if( phoneChecking($logsDetails['u_email']) != 'false' ){
					$errorEmailMobile = 1;
				}else{
					$errorEmailMobile = 0;
				}
			}
			if($errorEmailMobile!=0){
				if(isset($logsDetails['loginwithemail']) && $logsDetails['loginwithemail']==1){
					$u_email    = $logsDetails['u_email'];
					$mobile     = '';
					$resultCount = $userTable->checkEmail($u_email,'2');
				}else if(isset($logsDetails['loginwithphone']) && $logsDetails['loginwithphone']==1){
					$u_email    = '';
					$mobile     = $logsDetails['u_email'];
					$resultCount = $userTable->checkMobile($mobile,'2');
				}else{
					$u_email    = $logsDetails['u_email'];
					$mobile     = '';
					$resultCount = $userTable->checkEmail($u_email,'2');
				}
				$usertype = 2;
				$data = '';	
				if($resultCount!=0){
					$loggedDeatils = $userTable->userLogin($u_email,$mobile,$u_password,$usertype);
					if(isset($loggedDeatils->u_id) && $loggedDeatils->u_id!=''){
						$data = array(
							'firstname' => $loggedDeatils->uf_fname,				
							'lastname'  => $loggedDeatils->uf_lname,		
							'email'     => $loggedDeatils->u_email,		
							'phone' 	=> $loggedDeatils->u_mobile,   
							'uid' 	    => $loggedDeatils->u_id,   
							'upic' 	    => $loggedDeatils->uf_pic,   
							'aboutme'   => $loggedDeatils->uf_about_me,   
						);	
						return new JsonModel(array(					
							'output' 	=> 'success',
							'userdata' 	=> $data,
						));
					}else{
						return new JsonModel(array(					
							'output' 	=> 'fail',
						));
					}
				}else{
					return new JsonModel(array(					
						'output' 	=> 'notInRecords',
					));
				}		
			}else{
				return new JsonModel(array(					
					'output' 	=> 'fail',
					'msg' 	    => 'Email and mobile is wrong',
				));				
			}
		}else{
			return new JsonModel(array(					
				'output' 	=> 'fail',
			));		
		}			
    }
	public function options()
	{
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($id, $data)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description'); 
    }
    public function delete($id)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
}