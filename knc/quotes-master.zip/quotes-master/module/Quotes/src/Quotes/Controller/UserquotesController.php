<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class UserquotesController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
	public function getCategoires($qc_id){
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$cat = "";
		$cat_names = ""; 
		$cateList = $quoteCategoriesTable->getCategories($qc_id);
		foreach($cateList as $key=>$cat){
			$cat_names .= ucfirst($cat['qc_cat_name'].', ');
			$cat = rtrim($cat_names, ', ');
		}
		return $cat;	
	}
	public function getQuotesViewCount($qc_id){
		$quotesviewsTable = $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		$countofviewss  = $quotesviewsTable->countviewQuote($qc_id);
		$countofviews  = 0;		
		if(count($countofviewss)!=0){
			foreach($countofviewss as $countofviewsss){
				if(isset($countofviewsss['view_id']) && $countofviewsss['view_id']!=""){
					$countofviews  += $countofviewsss['view_count'];
				}else{
					$countofviews  = 0;
				}
			}
		}else{
			$countofviews  = 0;
		}
		return $countofviews;
	}
	public function getIsFav($qc_id,$uid){
		$userIsfav = 0;
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$countfavorites    = $favoritesTable->checkFav($uid,$qc_id);
		$countofviews     = 0;
		if($countfavorites>0){
			$userIsfav =1;
		}else{
			$userIsfav =0;
		}
		
		return $userIsfav;
	}
	public function get($parms){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
        $quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');		
		$favoritesTable   = $this->getServiceLocator()->get('Models\Model\FavoritesFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$ids = explode('-',$parms);
		$count  = (int)$ids[0];
		$page   = (int)$ids[1];
		$qc_u_id    =  $ids[2];
		$userquotes = $quotesTable->userQuotes($qc_u_id,$count);
		$userquotes->setCurrentPageNumber($page);
		$userquotes->setItemCountPerPage($count);	
		$userquotes->setPageRange(5);
		$totalUserQuotes = $userquotes->getTotalItemCount();
		$countoffav = 0;
		$i =0;
		$quoteInfo ='';
		$quoteInfos ='';
		if(count($userquotes)!=0){
			foreach($userquotes as $q=>$quoteInfoo){
				$qc_id = (int)$quoteInfoo->qc_id;
				$countoffav    = $favoritesTable->countEachQuote($qc_id);
				$countofviews  = $this->getQuotesViewCount($qc_id);
				$cat           = $this->getCategoires($qc_id);				
				if($qc_u_id!=0){
					$checkuserquote = $this->getIsFav($qc_id,$qc_u_id);
				}else{
					$checkuserquote = 0;
				}
				$quoteInfo[$q]['qc_id'] 			= $quoteInfoo->qc_id;
				$quoteInfo[$q]['qc_name'] 			= ucfirst($quoteInfoo->qc_name);
				$quoteInfo[$q]['qc_image']			= $quoteInfoo->qc_image;
				$quoteInfo[$q]['qc_tags']			= $quoteInfoo->qc_tags;
				$quoteInfo[$q]['qc_created_at']		= $quoteInfoo->qc_created_at;
				$quoteInfo[$q]['lang_id']			= $quoteInfoo->lang_id;
				$quoteInfo[$q]['lang_name']			= ucfirst($quoteInfoo->lang_name);				
				$quoteInfo[$q]['au_id']				= $quoteInfoo->au_id;
				$quoteInfo[$q]['au_fname']			= ucfirst($quoteInfoo->au_fname);
				$quoteInfo[$q]['au_lname']			= ucfirst($quoteInfoo->au_lname);
				$quoteInfo[$q]['au_pic']			= $quoteInfoo->au_pic;
				$quoteInfo[$q]['au_birth_year']		= $quoteInfoo->au_birth_year;
				$quoteInfo[$q]['au_deadth_year']	= $quoteInfoo->au_deadth_year;
				$quoteInfo[$q]['au_wiki_link']	    = $quoteInfoo->au_wiki_link;
				$quoteInfo[$q]['au_descrpt']	    = $quoteInfoo->au_descrpt;
				$quoteInfo[$q]['countoffav']		= $countoffav;
				$quoteInfo[$q]['countofviews']		= $countofviews;
				$quoteInfo[$q]['categories']        = $cat;
				$quoteInfo[$q]['checkquotefav']     = $checkuserquote;					
			}	
			escape_arr($quoteInfo);
		}else{
			$quoteInfo = "";
		}	
		return new JsonModel(array(				
			'output' 		=> 	'success',
			'userquotes'   =>  $quoteInfo,
			'totalUserQuotes' => $totalUserQuotes
		));
	}
     public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	public function options()
	{
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
}