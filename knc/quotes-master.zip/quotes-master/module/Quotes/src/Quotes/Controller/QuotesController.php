<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class QuotesController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');	
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$categoryTable = $this->getServiceLocator()->get('Models\Model\CategoryFactory');
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$top100Quotes = 10;
		$quotesList = $quotesTable->latestquotes($top100Quotes);
		$i =0;
		$cat = "";
		$cat_names = ""; 
		if(count($quotesList)!=0){
			foreach($quotesList as $key=>$quoteData){
				$cateList = $categoryTable->getcatnames($quoteData['qc_qc_cat_id']);
				$quotearray[$i] = $quoteData;	
				foreach($cateList as $key=>$catData){
					$cat_names .= ucfirst($catData['qc_cat_name'].', ');
					$cat = rtrim($cat_names, ', ');
					$quotearray[$i]['cat'] = $cat;
				}
				$i++;
			}
			escape_arr($quotearray);
		}else{
			$quotearray = "";
		}		
		return new JsonModel(array(					
			'latestquotes'  =>  $quotearray,
		));	
    }
    public function get($count)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$cnt = (int)$count;
		$quotesTable   = $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
		$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
		$quotesList = $quotesTable->latestquotes($cnt);	
		$i =0;
		if(count($quotesList)!=0){
			foreach($quotesList as $quoteData){
				$qc_id = (int)$quoteData['qc_id'];
				$cateList = $quoteCategoriesTable->getCategories($qc_id);
				$quotearray[$i] = $quoteData;	
				foreach($cateList as $catData){
					$quotearray[$i]['cat'][$catData['qcat_qc_cat_id']] = $catData['qc_cat_name'];
				}
				$i++;
			}
			escape_arr($quotearray);
		}else{
			$quotearray = "";
		}				
		return new JsonModel (array(					
			'latestquotes'  =>  $quotearray,
		));	
	}
     public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
	
}