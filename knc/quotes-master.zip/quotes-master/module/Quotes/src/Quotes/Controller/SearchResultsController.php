<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class SearchResultsController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		
    }
    public function get($quote_id)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$searchedTerm 			= "";
		if(isset($data['QtSearch']) && $data['QtSearch'] != "")
		{
			$searchedTerm 		= $data['QtSearch'];
			$quotesTable  		= $this->getServiceLocator()->get('Models\Model\QuotesFactory');	
			$quoteCategoriesTable = $this->getServiceLocator()->get('Models\Model\QuoteCategoriesFactory');
			$searchedQtList		= $quotesTable->searchQtListforApp($searchedTerm);	
			$searchQtList = array();		
			if(count($searchedQtList))
			{
				foreach($searchedQtList as $q=>$qDay)
				{
					$categoires  = $quoteCategoriesTable->getCategories($qDay->qc_id);
					$cat = "";
					$cat_names = ""; 				
					$searchQtList[$q]['qc_id'] 				= $qDay->qc_id;
					$searchQtList[$q]['qc_name'] 			= $qDay->qc_name;
					$searchQtList[$q]['qc_image']			= $qDay->qc_image;
					$searchQtList[$q]['qc_tags']			= $qDay->qc_tags;
					$searchQtList[$q]['qc_created_at']		= $qDay->qc_created_at;
					$searchQtList[$q]['fav']				= $qDay->fav;				
					$searchQtList[$q]['viewCounnt']			= $qDay->viewCounnt;
					$searchQtList[$q]['au_id']				= $qDay->au_id;
					$searchQtList[$q]['au_fname']			= $qDay->au_fname;
					$searchQtList[$q]['au_lname']			= $qDay->au_lname;
					$searchQtList[$q]['au_pic']				= $qDay->au_pic;
					$searchQtList[$q]['qc_cat_id']			= $qDay->qc_cat_id;
					foreach($categoires as $key=>$cat){
						$cat_names .= ucfirst($cat['qc_cat_name'].', ');
						$cat = rtrim($cat_names, ', ');
						$searchQtList[$q]['keywords'] = $cat;
					}
				}
			}
		}
		else
		{
			$searchQtList 	=  "";
		}
		return new JsonModel(array(
			'output' 	     => 'success',				
			'searchQtList'  => $searchQtList
		));	
	}
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
	
}