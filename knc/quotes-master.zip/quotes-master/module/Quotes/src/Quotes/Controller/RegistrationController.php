<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class RegistrationController extends AbstractRestfulController
{
    public function getList()
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
    public function get($u_id)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$userTable = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userDetailsTable = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		$checkMind = $userTable->getUserData($u_id);
		if(isset($checkMind->u_id) && $checkMind->u_id!=""){
			return new JsonModel(array(
				'status' 	    =>  'sucess',
				'expried'       =>  'nok',
			));				
		}else{
			$userAuth=$userTable->updateUserRegAuth($u_id);
			if($userAuth){
				$userCount=$userDetailsTable->updateUserRegAuth($u_id);
				if($userCount){
					$checkUser  =  $userTable->getUserData($u_id);
					if(isset($checkUser->u_id) && $checkUser->u_id!=""){		
						$data = array(
							'firstname' => $checkUser->uf_fname,				
							'lastname'  => $checkUser->uf_lname,		
							'email'     => $checkUser->u_email,		
							'phone' 	=> $checkUser->u_mobile,   
							'uid' 	    => $checkUser->u_id,   
							'upic' 	    => $checkUser->uf_pic,   
							'aboutme'   => $checkUser->uf_about_me,   
							'gender'    => $checkUser->uf_gender,   
							'dob'       => $checkUser->uf_dob,  
						);	
						return new JsonModel(array(					
							'output' 	=> 'success',
							'userdata' 	=> $data,
						));
					}else{
						return new JsonModel(array(					
							'output' 	=> 'success',
							'userdata' 	=> '',
						));
					}
				}else{
					return new JsonModel(array(
						'output' 	    =>  'fail',
					));
				}
			}else{
				return new JsonModel(array(
					'output' 	    =>  'fail',
				));
			}			
		}			
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		// uf_fname, u_email, u_password, u_mobile
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$userTable        = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userDetailsTable = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		$email = $data['u_email'];
		if( emailChecking($email) != 'false' ){
			$resultCount = $userTable->checkEmail($email,'2');
			if($resultCount=='0'){
				//$phone = $data['u_mobile'];
				// if( phoneChecking($phone) != 'false' ){
					// $u_idd = 0;
					// $resultCount = $userTable->checkMobile($phone,'2');
					// if($resultCount=="0"){
						 $lastInsertedId = $userTable->addNormalUser($data);
						//uf_fname, uf_lname, uf_gender, uf_pic, uf_dob, uf_about_me
						$userDetailsId = $userDetailsTable->addNormalUser($data,$lastInsertedId);
						if($userDetailsId>0){
							$getDetails = $userTable->nonActiveUser($lastInsertedId);
							if($getDetails!=''){
								$u_name = ucfirst($getDetails->uf_fname);
								$u_id = $getDetails->u_id;
								$u_email = $getDetails->u_email;
								$u_mobile = $getDetails->u_mobile;
								global $regSubject;				
								global $regMessage;
								$url = $baseUrl.'/reg-authentication/'.$u_id;
								$regMessage = str_replace("<FULLNAME>","$u_name", $regMessage);
								$regMessage = str_replace("<REGLINK>",$baseUrl."/reg-authentication/".$u_id, $regMessage);	
								$to = $u_email;					
								if(sendMail($to,$regSubject,$regMessage)){ 
									$result = new JsonModel(array(					
										'output' 	=> 'success',
										'success'	=>	true,
										'url'	=>	$url,
										'u_id'  =>$u_id,
									));	
								}else{ 
									$result = new JsonModel(array(	 				
										'output' 	=> 'success',
										'success'	=>	true,
										'url'	    =>	$url,
										'u_id'      =>$u_id,
									));
								}
								return $result;					
							}
						}else{
							return new JsonModel(array(
								'success'=>false,
							));
						}
					// }else{
						// return new JsonModel(array(
							// 'output' => 'fail',
							// 'status' =>	'phone-already-exists',				
						// ));
					// }
				// }
				// else{
					// return new JsonModel(array(
						// 'output' => 'fail',
						// 'status' =>	'mobile number is wrong formate',				
					// ));
				// }
			}
			else{
				return new JsonModel(array(
					'output' => 'fail',
					'status' =>	'email-already-exists',
				));
			}
		}
		else{
			return new JsonModel(array(
				'output' => 'fail',
				'status' =>	'email-formate-wrong',
			));
		}
    }
    public function update($u_idd, $data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	public function options()
	{
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function delete($id)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	function getUniqueCode($length = "")
	{
		$code = md5(uniqid(rand(), true));
		if ($length != "")
		return substr($code, 0, $length);
		else
		return $code;
	}
}