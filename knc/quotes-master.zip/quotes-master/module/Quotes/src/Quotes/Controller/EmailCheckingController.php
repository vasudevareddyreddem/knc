<?php
namespace UserApi\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class EmailCheckingApiController extends AbstractRestfulController
{
    public function getList()
    {			
	    header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
    public function get($email)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$email = $data['u_email'];
		$userTable=$this->getServiceLocator()->get('Models\Model\UserFactory');
		$checkingExists = $userTable->checkEmailExists($email);
		if($checkingExists!=0){
			return new JsonModel(array(
				'output' 		=> 'exists',
				'Status'        => 'ok'
			));
		}else{
			return new JsonModel(array(
				'output' 	=> 'noyet',
				'Status'    => 'nope'
			));
		}
    }
    public function update($uid, $data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
    public function delete($id)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description'); 
    }
}