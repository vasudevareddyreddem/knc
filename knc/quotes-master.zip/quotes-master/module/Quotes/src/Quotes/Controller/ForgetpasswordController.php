<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class ForgetpasswordController extends AbstractRestfulController
{
    public function getList()
    {			
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');	
    }
    public function get($token)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$forgetpasswordTable = $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');
		$tokenExit=$forgetpasswordTable->gettoken($token);		
		if(isset($tokenExit->ft_u_id) && $tokenExit->ft_u_id!=''){		
			return new JsonModel(array(									
				'output' => 'sucess',
				'u_id' => (int)$tokenExit->ft_u_id,
			));
		}else{
			return new JsonModel(array(									
				'output' => 'fail',
				'status' => 'already used',
			));
		}
    }
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		// u_email
		$userTable           =  $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$forgetpasswordTable =  $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');
		$email   = $data['u_email'];
		if( emailChecking($email) != 'false' ){
			$usetype = '2';
			$emailChecking = $userTable->checkEmail($email,$usetype);
			if($emailChecking!=0){
				$emailCheckingH = $userTable->emailUserData($email,$usetype);
				if($emailCheckingH!=''){
					$u_id = $emailCheckingH->u_id;
					$getDetails = $userTable->getUserData($u_id);
					if($getDetails!=""){
						$ft_u_id  = $getDetails->u_id;
						$userfname = ucfirst($getDetails->uf_fname);				
						$ft_token_code = $this->getUniqueCode('10');
						$tokentime = date("Y-m-d H:i:s", time());						
						$mailExit=$forgetpasswordTable->getmailfromfgtpwd($ft_u_id);
						if(isset($mailExit->ft_id) && $mailExit->ft_id!=""){
							$ft_id = $mailExit->ft_id;
							$insForgotPassword = $forgetpasswordTable->updateForgetpwd($ft_id,$ft_token_code);
						}else{
							$insForgotPassword = $forgetpasswordTable->addForgetpwd($ft_u_id,$ft_token_code);	
						}
						global $fpPwdSubject;                                
						global $fpPwdMessage;
						$url = $baseUrl."/reset-password/".$ft_token_code;
						$fpPwdMessage = str_replace("<FULLNAME>",$userfname, $fpPwdMessage);
						$fpPwdMessage = str_replace("<PASSWORDLINK>",$baseUrl."/reset-password/".$ft_token_code, $fpPwdMessage);	
						$to=$email;		
						if(sendMail($to,$fpPwdSubject,$fpPwdMessage)){
							$result = new JsonModel(array(					
								'output' => 'success',
								'success'=>true,
								'url' =>$url
							));	
						}else{
							$result = new JsonModel(array(					
								'output' => 'success',
								'success'=>true,
								'url' =>$url
							));	
						}
						return $result;
					}else{
						return new JsonModel(array(
							'output' => 'fail',
							'status' =>	'No data found',
						));
					}
				}else{
					return new JsonModel(array(
						'output' => 'fail',
						'status' =>	'noactive',
					));
				}
			}else{
				return new JsonModel(array(
					'output' => 'fail',
					'status' =>	'email-not-found',
				));
			}
		}else{
			return new JsonModel(array(
				'output' => 'fail',
				'status' =>	'Email formate is wrong',
			));
		}
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($id, $data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$userTable           =  $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$forgetpasswordTable = $this->getServiceLocator()->get('Models\Model\ForgotPasswordFactory');
		$user_id = $id;
		// u_password
		$getDetails = $userTable->getUserData($user_id);
		if(isset($getDetails->u_id) && $getDetails->u_id!=''){					
			$changepwd = $userTable->changepwd($getDetails->u_id,$data['u_password']);			
			if($changepwd){
				$deletetokenid=$forgetpasswordTable->deletetoken($getDetails->u_id);		
				$result = new JsonModel(array(					
					'output' => 'success',
					'success' => true
				));			
			}else{
				$result = new JsonModel(array(					
					'output'     => 'fail',
					'success' => false
				));
			}
			return $result;	
		}else{
			return new JsonModel(array(					
				'output'     => 'fail',
				'success' => false
			));
		}
    }
    public function delete($id)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	function getUniqueCode($length = "")
	{
		$code = md5(uniqid(rand(), true));
		if ($length != "")
		return substr($code, 0, $length);
		else
		return $code;
	}
}