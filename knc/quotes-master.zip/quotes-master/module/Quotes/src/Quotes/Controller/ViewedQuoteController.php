<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class ViewedQuoteController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
			
    }
    public function get($cnt)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];		
	}
    public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$baseUrls 				= $this->getServiceLocator()->get('config');
		$baseUrlArr 			= $baseUrls['urls'];
		$baseUrl 				= $baseUrlArr['baseUrl'];
		$basePath 				= $baseUrlArr['basePath'];
		$quotesviewsTable   = $this->getServiceLocator()->get('Models\Model\QuoteViewsFactory');
		if(isset($data['u_id']) && $data['u_id']!=""){
			$u_id     = $data['u_id'];
			$quote_id = $data['qc_id'];
			$checkUserViews	= $quotesviewsTable->checkViewsApp($u_id,$quote_id);	
			
			if($checkUserViews['view_count'] > 0)
			{
				$view_count = $checkUserViews['view_count']+1;
				$exitqcvid  = $checkUserViews['view_id'];
			}
			else{
				$view_count = 1;
				$exitqcvid  = 0;
			}			
			$insertedResults = $quotesviewsTable->addQuoteView($u_id,$quote_id,$exitqcvid,$view_count);
			$quoteViewdCnt   = $quotesviewsTable->countviewQuote($quote_id);
			$quoteViews = 0;
			foreach($quoteViewdCnt as $quotesView){
				$quoteViews += $quotesView['view_count'];
			}
			return new JsonModel(array(
				'output'      => 'success',				
				'id'          => $insertedResults,
				'quoteViews' => $quoteViews
			));
		}else{
			return new JsonModel(array(
				'output' => 'success',				
				'status' => 'fail'
			));
		}
	}
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
    }
	
}