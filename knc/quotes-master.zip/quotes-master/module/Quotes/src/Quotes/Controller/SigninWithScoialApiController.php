<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class SigninWithScoialApiController extends AbstractRestfulController
{
    public function getList()
    {
		header('Access-Control-Allow-Origin: *');		
    }
    public function get($uid)
    {	
		header('Access-Control-Allow-Origin: *');
    }
    public function create($data)
    {		
		header('Access-Control-Allow-Origin: *');
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$socialPTable=$this->getServiceLocator()->get('Models\Model\SocialProvidersFactory');
		$userTable   = $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$userInfoTable   = $this->getServiceLocator()->get('Models\Model\UserInfoFactory');
		$checkingProvider = $socialPTable->checkProvider($data);
		if(isset($checkingProvider->gd_scl_u_id) && $checkingProvider->gd_scl_u_id!=''){					
			$updateEmail = $userTable->updateEmail($data,$checkingProvider->gd_scl_u_id);
			$getUserInfo = $userTable->getUserInfo($checkingProvider->gd_scl_u_id);				
			$new_user=0;
			return new JsonModel(array(
				'output' 	    => 'success',
				'userInfo' 	    => $getUserInfo,
				'new_user' 	    => $new_user
			));			
		}else{
			$email = $data['email'];
			$u_social_logout = '';
			$emailChecking = $userTable->checkEmailExists($email);
			if($emailChecking=='0'){
				if($email!=""){
					$insertedUser = $userTable->addSUserProvider($data);
					$insertedProdiver = $socialPTable->addSocialProvide($insertedUser,$data);
					$addUserinfo = $userInfoTable->adduserinfo($insertedUser,$data);
					$getUserInfo = $userTable->getUserInfo($insertedUser);
					$new_user=1;
					return new JsonModel(array(
						'output' 	    => 'success',
						'userInfo' 	    => $getUserInfo,
						'new_user' 	    => $new_user
					));	
				}
			}else{
				$alreadyExists='fb';
				return new JsonModel(array(
					'output' 	     => 'success',
					'alreadyExists'  => $alreadyExists,
				));
			}
		}		
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
	}
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
    }
}