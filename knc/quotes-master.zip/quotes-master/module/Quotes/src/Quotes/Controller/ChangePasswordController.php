<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class ChangepasswordController extends AbstractRestfulController
{
    public function getList()
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
			
    }
    public function get($user_id)
    {			
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
    public function create($passwords)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($u_id,$passwords)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		$userTable  =  $this->getServiceLocator()->get('Models\Model\UsersFactory');
		$check_old_password = $userTable->getpassword($u_id,$passwords['u_old_password']);
		if($check_old_password!=0){
			$change_password = $userTable->changepwd($u_id,$passwords['u_password']);
			if($change_password){
				return new JsonModel(array(
					'output' 	=> 'success',
					'status' 	=> true,
				));
			}
		}else{
			return new JsonModel(array(
				'output' 	=> 'fail',
				'status' 	=> false,
				'msg'       => 'Old password is wrong'
			));	
		}
    }
    public function delete($id)
    {
        header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description'); 
    }
}