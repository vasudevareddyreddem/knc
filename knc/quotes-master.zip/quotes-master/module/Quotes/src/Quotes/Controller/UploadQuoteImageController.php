<?php
namespace Quotes\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
class UploadQuoteImageController extends AbstractRestfulController
{
    public function getList()
    {		
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
    public function get($uidCount)
    {	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');		
	}
     public function create($data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		// fav_u_id, fav_qc_id
		$baseUrls = $this->getServiceLocator()->get('config');
		$baseUrlArr = $baseUrls['urls'];
		$baseUrl = $baseUrlArr['baseUrl'];
		$basePath = $baseUrlArr['basePath'];
		$fileExtentios     = explode(".", $_FILES["qImage"]["name"]);
        $extention         = strtolower(end($fileExtentios));
        switch($extention){
            case 'jpg' :case 'jpeg': case 'jpe': case 'png': case 'gif':
				if(isset($_FILES) && isset($_FILES['qImage']['name'])){
					@unlink('./public/uploads/'.$_POST['imageId']);
					$croppedNewWidth 	= 	$_POST['croppedNewWidth'];
					$croppedNewHeight 	= 	$_POST['croppedNewHeight'];
					$croppedX 			= 	$_POST['croppedX'];
					$croppedY 			= 	$_POST['croppedY'];
					$image 				= 	stripslashes($_FILES['fileCropInp']['name']);
					$temp 				= 	explode(".", $_FILES["fileCropInp"]["name"]);
					$extension 			= 	strtolower(end($temp));
					$uploadedfile		=	$_FILES['fileCropInp']['tmp_name'];
					
					if($extension=="jpg" || $extension=="jpeg" || $extension=="jpe"){
						$src = imagecreatefromjpeg($uploadedfile);
					}
					else if($extension=="png"){
						$src = imagecreatefrompng($uploadedfile);
					}
					else{
						$src = imagecreatefromgif($uploadedfile);
					}
					
					list($width,$height)	=	getimagesize($uploadedfile);
					$tmp					=	imagecreatetruecolor($croppedNewWidth,$croppedNewHeight);
					imagecopyresampled($tmp,$src,0,0,$croppedX,$croppedY,$croppedNewWidth,$croppedNewHeight,$croppedNewWidth,$croppedNewHeight);
					
					$imageName = date('Ymd') ."_". date("His") .'.' . $extension;
					$newfilenamePath = "./public/uploads/profiles/".$imageName;
					imagejpeg($tmp,$newfilenamePath,100);
					imagedestroy($tmp);
					imagedestroy($src);
					$user_session 			= 	new Container('admin');
					
					// if($user_session->userId == $_POST['u_id']){
						// $user_session->profile  =   $imageName;
					// }
					//$userTable  = 	$this->getServiceLocator()->get('Models\Model\UsersFactory');
					//$result		=	$userTable->updateUserProfileImage($imageName,$_POST['u_id']);
					return $view = new JsonModel(array(
						'output'  		=> 1,
						'imageName' 	=> $imageName
					));
				}
			break;
            default:
            return $view = new JsonModel(array(
                'output'          => 0,
                'message'          => 'The given extension is not allowed.',
            ));
            break;
		}
    }
	public function options(){
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
		die;
	}
    public function update($uid,$data)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');				
    }
    public function delete($id)
    {
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');			
    }
	
}