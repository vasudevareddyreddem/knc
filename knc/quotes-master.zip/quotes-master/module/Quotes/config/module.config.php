<?php	
	return array(
		'controllers' => array(
			'invokables' => array(
				'Quotes\Controller\LoginUser' 	      => 'Quotes\Controller\LoginUserController',
				'Quotes\Controller\Registration'      => 'Quotes\Controller\RegistrationController',
				'Quotes\Controller\Changepassword'    => 'Quotes\Controller\ChangepasswordController',
				'Quotes\Controller\Forgetpassword'    => 'Quotes\Controller\ForgetpasswordController',
				'Quotes\Controller\UserDetails'       => 'Quotes\Controller\UserDetailsController',
				'Quotes\Controller\QuoteAdminUser'    => 'Quotes\Controller\QuoteAdminUserController',
				'Quotes\Controller\Favoritingofquote' => 'Quotes\Controller\FavoritingofquoteController',
				'Quotes\Controller\Authors'           => 'Quotes\Controller\AuthorsController',
				'Quotes\Controller\CategoryQuotes'    => 'Quotes\Controller\CategoryQuotesController',
				'Quotes\Controller\Quotes'            => 'Quotes\Controller\QuotesController',
				'Quotes\Controller\QuotesApi'         => 'Quotes\Controller\QuotePostController',
				'Quotes\Controller\QuotesviewApi'     => 'Quotes\Controller\QuotesviewController',
				'Quotes\Controller\userquotes'        => 'Quotes\Controller\UserquotesController',
				'Quotes\Controller\topquotes'         => 'Quotes\Controller\TopquotesController',
				'Quotes\Controller\views'             => 'Quotes\Controller\ViewsController',
				'Quotes\Controller\SearchResults'     => 'Quotes\Controller\SearchResultsController',
				'Quotes\Controller\SigninWithScoialApi' => 'Quotes\Controller\SigninWithScoialApiController',				
				'Quotes\Controller\QuotesManual'      => 'Quotes\Controller\QuotesManualController',				
				'Quotes\Controller\UserQuoteFav'      => 'Quotes\Controller\UserQuoteFavController',
				'Quotes\Controller\ViewedQuote'       => 'Quotes\Controller\ViewedQuoteController',				
				'Quotes\Controller\Languages'       => 'Quotes\Controller\LanguagesController',				
				'Quotes\Controller\QuotesInformation'=> 'Quotes\Controller\QuotesInformationController',				
			),
		),
		'router' => array(
			'routes' => array(		
				'sign-in' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/sign-in[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\LoginUser',
						),
					),
				),
				'viewed-quote' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/viewed-quote[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\ViewedQuote',
						),
					),
				),
				'edit-user-quote' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/edit-user-quote[/:id]',
						'constraints' => array(
							'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesInformation',
						),
					),
				),
				'update-user-quote' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/update-user-quote[/:id]',
						'constraints' => array(
							'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesInformation',
						),
					),
				),
				'quote-user-del' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/quote-user-del[/:id]',
						'constraints' => array(
							'id' => '[%&=;a-zA-Z0-9][%&=+;a-zA-Z0-9_~-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesInformation',
						),
					),
				),
				'languages-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/languages-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Languages',
						),
					),
				),				
				'quotes-manual-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/quotes-manual-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesManual',
						),
					),
				),
				'sign-up' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/sign-up[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Registration',
						),
					),
				),
				'search-results-app' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/search-results-app[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\SearchResults',
						),
					),
				),
				'check-quote-fav-unfav' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/check-quote-fav-unfav[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\UserQuoteFav',
						),
					),
				),	
				'reg-authentication' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/reg-authentication[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Registration',
						),
					),
				),
				'forgot-password' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/forgot-password[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Forgetpassword',
						),
					),
				),
				'verify-fp-link' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/verify-fp-link[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Forgetpassword',
						),
					),
				),
				'reset-password' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/reset-password[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Forgetpassword',
						),
					),
				),
				
				'quote-information' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/quote-information[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesviewApi',
						),
					),
				),
				
				'latest-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/latest-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesviewApi',
						),
					),
				),
				
				'change-password' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/change-password[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Changepassword',
						),
					),
				),
				'view-user-details' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/view-user-details[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\UserDetails',
						),
					),
				),
				'update-user-details' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/update-user-details[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\UserDetails',
						),
					),
				),
				'quote-admin-user' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/quote-admin-user[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuoteAdminUser',
						),
					),
				),
				'refresh-quote' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/refresh-quote[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuoteAdminUser',
						),
					),
				),
				// Favoriting to Quote
				'favoriting-quote' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/favoriting-quote[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Favoritingofquote',
						),
					),
				),
				'user-favorites' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/user-favorites[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Favoritingofquote',
						),
					),
				),
				'user-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/user-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\userquotes',
						),
					),
				),
				'top-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/top-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\topquotes',
						),
					),
				),
				// Authors list 
				'authors-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/authors-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Authors',
						),
					),
				),
				// Load more author list
				'load-authors-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/load-authors-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Authors',
						),
					),
				),
				// Author quotes
				'author-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/author-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Authors',
						),
					),
				),
				// load-author-quotes
				'load-author-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/load-author-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Authors',
						),
					),
				),
				// Categories list 
				'app-categories-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/app-categories-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\CategoryQuotes',
						),
					),
				),
				// Quotes list 
				'app-quotes-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/app-quotes-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\Authors',
						),
					),
				),
				// Load Categories 
				'load-categories-list' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/load-categories-list[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\CategoryQuotes',
						),
					),
				),
				// Categories Quotes
				'category-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/category-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\CategoryQuotes',
						),
					),
				),
				'scoial-logins' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/scoial-logins[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\SigninWithScoialApi',
						),
					),
				),
				// Categories Quotes
				'load-category-quotes' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/load-category-quotes[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\CategoryQuotes',
						),
					),
				),				
				//Post the quote
				'post-quote' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/post-quote[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\QuotesApi',
						),
					),
				),
				'views-count' => array(
					'type'    => 'Segment',
					'options' => array(
						'route'    => '/views-count[/:id]',
						'constraints' => array(
							'id' => '[%&@*.;a-zA-Z0-9][%&@*.;a-zA-Z0-9_-]*',
						),
						'defaults' => array(
							'controller' => 'Quotes\Controller\views',
						),
					),
				),	
			),
		),
		'view_manager' => array(
			'strategies' => array(
				'ViewJsonStrategy',
			),
		),
		
	);

?>