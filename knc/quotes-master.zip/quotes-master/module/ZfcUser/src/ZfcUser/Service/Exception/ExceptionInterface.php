<?php

namespace ZfcUser\Service\Exception;

interface ExceptionInterface
{
}
