<?php

return [
    'session' => [
        'name'                => 'XDI',
        'save_handler'        => 'files', // 'files' or 'memcached'
        'save_path'           => realpath(__DIR__ . '/../../data/session'),
        'remember_me_seconds' => 7 * 24 * 60 * 60,
        'cookie_lifetime'     => 7 * 24 * 60 * 60,
    ],
];