<?php

return array(
    'db' 				=> 	array(
		'dsn' 			=>	'mysql:dbname=quotes;host=localhost',
        'username' 		=> 	'root',
        'password' 		=> 	'',
    ),
	'urls' 				=> 	array(
		'baseUrl' 		=> 	'http://localhost/quotes/trunk/',
		'basePath' 		=> 	'http://localhost/quotes/trunk/public',
		'imageUrl' 		=> 	'http://localhost/quotes/trunk/',
	),
	'service_manager' 	=> 	array(
        'factories' 	=> 	array(  
        ),
    ),
	'cache' => array(
		'adapter' => array(
			'name'    => 'Filesystem',
			'options' => array(
				'cache_dir' => __DIR__ . '/../../../data/cache',
				'ttl'       => '3600'
			)
		),
		'plugins' => array(
			array(
				'name'    => 'serializer',
				'options' => array()
			),
			'exception_handler' => array(
				'throw_exceptions' => true
			)
		)
	),
	
);

?>
