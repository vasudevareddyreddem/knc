<?php
 
define('BASE_URL', filter_var('http://localhost/quotes/trunk/', FILTER_SANITIZE_URL));
define('CLIENT_ID','462348248285-3n86kiklt0t0sgsfg3fgjana3repn4ng.apps.googleusercontent.com');
define('CLIENT_SECRET','WYncc-dn3uQ5DQbfIgEri-cb');
define('REDIRECT_URI','http://localhost/quotes/trunk/social-sign-in/google');
define('APPROVAL_PROMPT','auto');
define('ACCESS_TYPE','offline');

//For facebook
define('APP_ID','208705476236431');
define('FACEBOOK_APP_ID','208705476236431');
define('APP_SECRET','cb47909b325614cf1a62ce4c57a6cdd4');

include( 'public/global/global_variables.php');
include( 'public/global/global_functions.php');
include( 'public/phpMailer/sendmail.php');
include( 'public/social/Social.php' );

include( 'public/social/social_lib/facebook/facebook.php' );
// include( 'public/social/fbConfig.php');
include( 'public/social/social_lib/google/Google_Client.php' );
include( 'public/social/social_lib/google/Google_Oauth2Service.php' );

global $Social_obj;
$Social_obj= new Social();


global $client;
$client = new Google_Client();
$client->setApplicationName("Quotes");
$client->setClientId(CLIENT_ID);
$client->setClientSecret(CLIENT_SECRET);
$client->setRedirectUri(REDIRECT_URI);
$client->setApprovalPrompt(APPROVAL_PROMPT);
$client->setAccessType(ACCESS_TYPE);


global $serachTermG;
global $seoGTitle;
global $seoGDecrpt;
global $seoGUrl;
global $seoGImage;

// return array(
    // 'db' 					=>	array(
        // 'driver'         	=> 	'Pdo',
        // 'driver_options' 	=> array(
            // PDO::MYSQL_ATTR_INIT_COMMAND 	=> 	'SET NAMES \'UTF8\''
        // ),
		// 'driver_options' 	=> array(
            // PDO::MYSQL_ATTR_INIT_COMMAND 	=> 	'SET SQL_BIG_SELECTS=1'
        // ),
		// 'driver_options' 	=> array(
            // PDO::MYSQL_ATTR_INIT_COMMAND 	=> 	'SET CHARSET \'UTF8\''
        // ),
    // ),
    // 'service_manager' 		=> 	array(
        // 'factories' 		=> 	array(
            // 'Zend\Db\Adapter\Adapter'
							// => 'Zend\Db\Adapter\AdapterServiceFactory',
        // ),
		// 'invokables' => array(
            // 'Zend\Session\SessionManager' => 'Zend\Session\SessionManager',
        // ),
    // ),
	 // 'abstract_factories' => array(
				// 'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
		  // ),
// );


$dbParams = array(
    'database'  => 'quotes',
    'username'  => 'root',
    'password'  => '',
    'hostname'  => 'localhost'
);
return array(
    'db' 					=>	array(
        'driver'         	=> 	'Pdo',
        'driver_options' 	=> array(
            PDO::MYSQL_ATTR_INIT_COMMAND 	=> 	'SET NAMES \'UTF8\''
        ),
		'driver_options' 	=> array(
            PDO::MYSQL_ATTR_INIT_COMMAND 	=> 	'SET SQL_BIG_SELECTS=1'
        ),
		'driver_options' 	=> array(
            PDO::MYSQL_ATTR_INIT_COMMAND 	=> 	'SET CHARSET \'UTF8\''
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Zend\Db\Adapter\Adapter' => function ($sm) use ($dbParams) {
                $adapter = new BjyProfiler\Db\Adapter\ProfilingAdapter(array(
                    'driver'    => 'pdo',
                    'dsn'       => 'mysql:dbname='.$dbParams['database'].';host='.$dbParams['hostname'],
                    'database'  => $dbParams['database'],
                    'username'  => $dbParams['username'],
                    'password'  => $dbParams['password'],
                    'hostname'  => $dbParams['hostname'],
                ));

                if (php_sapi_name() == 'cli') {
                    $logger = new Zend\Log\Logger();
                    $writer = new Zend\Log\Writer\Stream('php://output');
                    $logger->addWriter($writer, Zend\Log\Logger::DEBUG);
                    $adapter->setProfiler(new BjyProfiler\Db\Profiler\LoggingProfiler($logger));
                } else {
                    $adapter->setProfiler(new BjyProfiler\Db\Profiler\Profiler());
                }
                if (isset($dbParams['options']) && is_array($dbParams['options'])) {
                    $options = $dbParams['options'];
                } else {
                    $options = array();
                }
                $adapter->injectProfilingStatementPrototype($options);
                return $adapter;
            },
        ),
    ),
	'abstract_factories' => array(
		'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
	),
);



?>