<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway:300i,400,400i,500,500i,600" rel="stylesheet"> 
    <link rel="stylesheet" href="css/bootstrap.css" >
     <link rel="stylesheet" href="css/custom.css" > 
     <link rel="stylesheet" href="css/skin.css" > 
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/bootstrap.js" ></script>
  </head>
  <body>
	<!-- Header -->
	<nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
		<div class="container-fluid">
		  <a class="navbar-brand nav_innerpad" href="index.php"><img src="images/spread.png" width="250"></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="authors.php">Authors</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="topics.php">Topics</a>
					</li> 
					<li class="nav-item">
						<a class="nav-link" href="#">Quote of the Day</a>
					</li> 
					<li class="nav-item">
						<a class="nav-link" href="#">Make Quotes</a>
					</li>
					<li class="nav-item">
						<a class="nav-link " href="post-a-quote.php">Post a Quote</a>
					</li>
					<li class="nav-item">
						<form class="form-inline">
							<div class="input-group mb-2 mr-sm-2 mb-sm-0 mt-3">
								<input type="text" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Search">
								<div class="input-group-addon"><i class="fa fa-search color_w" aria-hidden="true"></i></div>
							</div>

						</form>
					</li>
				</ul>
				<div class="my-2 my-lg-0">
					<ul class="navbar-nav mr-auto">
						<li class="nav-item active">
							<a class="nav-link" href="#" data-toggle="modal" data-target="#login">Login</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="#" data-toggle="modal" data-target="#signup">Sign Up</a>
						</li>
					</ul>
				</div>
			</div>
			</div>
	</nav>
	<!-- A to Z Numbers -->
	<div class="mt-35 aznumbers ">
		<nav class="nav justify-content-center number_bg">
		  <a class="nav-link disabled" href="#">Authors :</a>
		  <a class="nav-link" href="#">A</a>
		  <a class="nav-link" href="#">B</a>
		  <a class="nav-link" href="#">C</a>
		  <a class="nav-link" href="#">D</a>
		  <a class="nav-link" href="#">E</a>
		  <a class="nav-link" href="#">F</a>
		  <a class="nav-link" href="#">G</a>
		  <a class="nav-link" href="#">H</a>
		  <a class="nav-link" href="#">I</a>
		  <a class="nav-link" href="#">J</a>
		  <a class="nav-link" href="#">K</a>
		  <a class="nav-link" href="#">L</a>
		  <a class="nav-link" href="#">M</a>
		  <a class="nav-link" href="#">N</a>
		  <a class="nav-link" href="#">O</a>
		  <a class="nav-link" href="#">P</a>
		  <a class="nav-link" href="#">Q</a>
		  <a class="nav-link" href="#">R</a>
		  <a class="nav-link" href="#">S</a>
		  <a class="nav-link" href="#">T</a>
		  <a class="nav-link" href="#">U</a>
		  <a class="nav-link" href="#">V</a>
		  <a class="nav-link" href="#">W</a>
		  <a class="nav-link" href="#">X</a>
		  <a class="nav-link" href="#">Y</a>
		  <a class="nav-link" href="#">Z</a>
		  <div class="top_social_links" style="margin-top:3px;">
		  <div class="social" style="width:auto;color:rgb(134, 142, 150)"> <span class="text-muted disabled">&nbsp; |</span>&nbsp; Follow Us :</div><div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
		  <div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
		  <div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div></div>
		</nav>
	</div>
	<!-- Header End -->