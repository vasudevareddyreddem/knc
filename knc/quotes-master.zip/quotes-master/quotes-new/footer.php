<div class="down_footer mt-5">
<footer>
        
        <!--<div class="search-text"> 
            <div class="container">
                <div class="row text-center">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                   <div class="form">
                       <h4>SIGN UP TO OUR NEWSLETTER</h4>
                        <form id="search-form" class="form-search form-horizontal">
                            <input type="text" class="input-search" placeholder="Email Address">
                            <button type="submit" class="btn-search">SUBMIT</button>
                        </form>
                    </div>
                    </div>
                
                </div>         
            </div>     
        </div>-->
        
        <div class="footer-top"> 
           <div class="container">
           <div class="row flex-row flex-nowrap footer_socila_icons">
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center">
                   <a href="#"><i class="fa fa-facebook fa-2x"></i><span>Facebook</span></a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center">
                   <a href="#"><i class="fa fa-twitter fa-2x"></i><span>Twitter</span></a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center m_hide">
                   <a href="#"><i class="fa fa-flickr fa-2x"></i><span>Flickr</span></a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center m_hide">
                    <a href="#"><i class="fa fa-tumblr fa-2x"></i><span>Tumblr</span></a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center">
                    <a href="#"><i class="fa fa-github fa-2x"></i><span>Github</span></a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center">
                    <a href="#"><i class="fa fa-google-plus fa-2x"></i><span>Google</span></a>
                </div>
           </div> 
           </div> 
        </div>  
        
        <div class="container" style="border-top:1px solid grey;">
            <div class="row text-center">   
                <div class="col-lg-12 col-lg-offset-3">
                      <ul class="menu">
                                 
                             <li>
                                <a href="#">Home</a>
                              </li>
                                   
                              <li>
                                 <a href="#">Authors</a>
                              </li>
                                   
                              <li>
                                <a href="#">Topics</a>
                              </li>
                                   
                              <li>
                                 <a href="#">Quote of the Day</a>
                              </li>
                                   
                              <li>
                                <a href="#">Make a Quotes</a>
                             </li> 
							 <li>
                                <a href="#">Post a Quotes</a>
                             </li>
                   
                        </ul>
                </div>
            </div>
        </div>
        
    </footer>
    
    
    <!--<div class="copyright">
     <div class="container">
         <div class="text-center">
         	<p>Copyright © 2017 All rights reserved</p>
         </div>
         
 	   </div>
    </div>
    
    <a href="#" id="top" style="display: inline;">
        <i class="fa fa-arrow-up" aria-hidden="true"></i>
    </a>-->
    </div>
</body>
</html>

<!-- Login Modal -->
<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<form>
			<div class="form-group row">
				<label for="staticEmail" class="col-sm-2 col-form-label">Name</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" id="inputName" placeholder="Name">
				</div>
			</div>
			<div class="form-group row">
				<label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
				<div class="col-sm-10">
				<input type="email" class="form-control" id="inputEmail	" placeholder="Email">
				</div>
			</div>
			<div class="form-group row">
				<label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
				<div class="col-sm-10">
				<input type="password" class="form-control" id="inputPassword" placeholder="Password">
				</div>
			</div>
		</form>
      </div>
      <div class="modal-footer pos_r">
	  <div class="linke_leftposition"><a href="#">Forgot Password? </a></div>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Login</button>
      </div>
    </div>
  </div>
</div>
<!-- Signup Modal -->
<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Sign Up</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<form>
			<div class="form-group row">
				<label for="staticEmail" class="col-sm-2 col-form-label">Name</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" id="inputName" placeholder="Name">
				</div>
			</div>
			<div class="form-group row">
				<label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
				<div class="col-sm-10">
				<input type="email" class="form-control" id="inputEmail	" placeholder="Email">
				</div>
			</div>
			<div class="form-group row">
				<label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
				<div class="col-sm-10">
				<input type="password" class="form-control" id="inputPassword" placeholder="Password">
				</div>
			</div>
		</form>
      </div>
      <div class="modal-footer pos_r">
	  <div class="linke_leftposition"><a href="#">Forgot Password? </a></div>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Login</button>
      </div>
    </div>
  </div>
</div>