<?php include('header.php');?>
<div class="container-fluid mt-3 popular_section">
<div class="white_bg">
<div class="row">
	<div class="col-md-8 col-lg-8 col-sm-8">
		<div class="card">
			<div class="card-body">
				<h4 class="card-title">All 'A' authors</h4>
				<nav aria-label="...">
					<ul class="pagination">
						<li class="page-item disabled">
						<span class="page-link">Previous</span>
						</li>
						<li class="page-item"><a class="page-link" href="#">1</a></li>
						<li class="page-item active">
						<span class="page-link">
						2
						<span class="sr-only">(current)</span>
						</span>
						</li>
						<li class="page-item"><a class="page-link" href="#">3</a></li>
						<li class="page-item">
						<a class="page-link" href="#">Next</a>
						</li>
					</ul>
				</nav>
				<table class="table table-hover table-responsive table-bordered">
				<thead class="thead-inverse">
				<tr>
				<th>Author</th>
				<th>Profession</th>
				</tr>
				</thead>
				<tbody>
				<tr>
				<td>
				<a href="/authors/a_a_milne">A. A. Milne</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/a_p_j_abdul_kalam">A. P. J. Abdul Kalam</a>
				</td>
				<td>
				Statesman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/a_philip_randolph">A. Philip Randolph</a>
				</td>
				<td>
				Activist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/a_r_rahman">A. R. Rahman</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aaron_burr">Aaron Burr</a>
				</td>
				<td>
				Politician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aaron_neville">Aaron Neville</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aaron_rodgers">Aaron Rodgers</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aaron_sorkin">Aaron Sorkin</a>
				</td>
				<td>
				Producer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aaron_swartz">Aaron Swartz</a>
				</td>
				<td>
				Businessman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abbie_hoffman">Abbie Hoffman</a>
				</td>
				<td>
				Activist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abby_wambach">Abby Wambach</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abigail_adams">Abigail Adams</a>
				</td>
				<td>
				First Lady
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abraham_joshua_heschel">Abraham Joshua Heschel</a>
				</td>
				<td>
				Educator
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abraham_lincoln">Abraham Lincoln</a>
				</td>
				<td>
				President
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abraham_maslow">Abraham Maslow</a>
				</td>
				<td>
				Psychologist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/abu_bakr">Abu Bakr</a>
				</td>
				<td>
				Leader
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/action_bronson">Action Bronson</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ada_lovelace">Ada Lovelace</a>
				</td>
				<td>
				Mathematician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_carolla">Adam Carolla</a>
				</td>
				<td>
				Entertainer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_grant">Adam Grant</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_hamilton">Adam Hamilton</a>
				</td>
				<td>
				Clergyman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_lambert">Adam Lambert</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_levine">Adam Levine</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_mckay">Adam McKay</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_sandler">Adam Sandler</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_savage">Adam Savage</a>
				</td>
				<td>
				Entertainer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_smith">Adam Smith</a>
				</td>
				<td>
				Economist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_weishaupt">Adam Weishaupt</a>
				</td>
				<td>
				Clergyman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adam_west">Adam West</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adele">Adele</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/adlai_e_stevenson">Adlai E. Stevenson</a>
				</td>
				<td>
				Politician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aerin_lauder">Aerin Lauder</a>
				</td>
				<td>
				Businesswoman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aeschylus">Aeschylus</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aesop">Aesop</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/agatha_christie">Agatha Christie</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/agnes_de_mille">Agnes de Mille</a>
				</td>
				<td>
				Dancer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ai_weiwei">Ai Weiwei</a>
				</td>
				<td>
				Artist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aishwarya_rai_bachchan">Aishwarya Rai Bachchan</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/al_franken">Al Franken</a>
				</td>
				<td>
				Politician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/al_gore">Al Gore</a>
				</td>
				<td>
				Vice President
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/al_pacino">Al Pacino</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/al_sharpton">Al Sharpton</a>
				</td>
				<td>
				Activist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alain_de_botton">Alain de Botton</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_alda">Alan Alda</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_bennett">Alan Bennett</a>
				</td>
				<td>
				Dramatist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_dershowitz">Alan Dershowitz</a>
				</td>
				<td>
				Lawyer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_greenspan">Alan Greenspan</a>
				</td>
				<td>
				Economist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_jackson">Alan Jackson</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_kay">Alan Kay</a>
				</td>
				<td>
				Scientist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_king">Alan King</a>
				</td>
				<td>
				Comedian
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_moore">Alan Moore</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_rickman">Alan Rickman</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_shepard">Alan Shepard</a>
				</td>
				<td>
				Astronaut
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_turing">Alan Turing</a>
				</td>
				<td>
				Mathematician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alan_watts">Alan Watts</a>
				</td>
				<td>
				Philosopher
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alanis_morissette">Alanis Morissette</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/albert_bandura">Albert Bandura</a>
				</td>
				<td>
				Psychologist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/albert_camus">Albert Camus</a>
				</td>
				<td>
				Philosopher
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/albert_einstein">Albert Einstein</a>
				</td>
				<td>
				Physicist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/albert_ellis">Albert Ellis</a>
				</td>
				<td>
				Psychologist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/albert_pike">Albert Pike</a>
				</td>
				<td>
				Lawyer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/albert_schweitzer">Albert Schweitzer</a>
				</td>
				<td>
				Theologian
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alberto_giacometti">Alberto Giacometti</a>
				</td>
				<td>
				Sculptor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aldo_leopold">Aldo Leopold</a>
				</td>
				<td>
				Environmentalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aldous_huxley">Aldous Huxley</a>
				</td>
				<td>
				Novelist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alec_baldwin">Alec Baldwin</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aleister_crowley">Aleister Crowley</a>
				</td>
				<td>
				Critic
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alejandro_gonzalez_inarri">Alejandro Gonzalez Inarritu</a>
				</td>
				<td>
				Director
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alejandro_jodorowsky">Alejandro Jodorowsky</a>
				</td>
				<td>
				Director
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alek_wek">Alek Wek</a>
				</td>
				<td>
				Designer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aleksandr_solzhenitsyn">Aleksandr Solzhenitsyn</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alex_ferguson">Alex Ferguson</a>
				</td>
				<td>
				Coach
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alex_guarnaschelli">Alex Guarnaschelli</a>
				</td>
				<td>
				Chef
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alex_honnold">Alex Honnold</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alex_turner">Alex Turner</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alexander_graham_bell">Alexander Graham Bell</a>
				</td>
				<td>
				Inventor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alexander_hamilton">Alexander Hamilton</a>
				</td>
				<td>
				Politician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alexander_mcqueen">Alexander McQueen</a>
				</td>
				<td>
				Designer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alexander_pope">Alexander Pope</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alexander_the_great">Alexander the Great</a>
				</td>
				<td>
				Leader
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alexis_de_tocqueville">Alexis de Tocqueville</a>
				</td>
				<td>
				Historian
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alfred_adler">Alfred Adler</a>
				</td>
				<td>
				Psychologist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alfred_hitchcock">Alfred Hitchcock</a>
				</td>
				<td>
				Director
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alfred_lord_tennyson">Alfred Lord Tennyson</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alfred_north_whitehead">Alfred North Whitehead</a>
				</td>
				<td>
				Mathematician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ali_ibn_abi_talib">Ali ibn Abi Talib</a>
				</td>
				<td>
				Clergyman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alice_cooper">Alice Cooper</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alice_meynell">Alice Meynell</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alice_paul">Alice Paul</a>
				</td>
				<td>
				Activist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alice_walker">Alice Walker</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alice_waters">Alice Waters</a>
				</td>
				<td>
				Chef
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alicia_keys">Alicia Keys</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/allen_ginsberg">Allen Ginsberg</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/allen_iverson">Allen Iverson</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/allen_west">Allen West</a>
				</td>
				<td>
				Politician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/allyson_felix">Allyson Felix</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alphonse_karr">Alphonse Karr</a>
				</td>
				<td>
				Critic
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alveda_king">Alveda King</a>
				</td>
				<td>
				Clergyman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/alvin_toffler">Alvin Toffler</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amanda_lindhout">Amanda Lindhout</a>
				</td>
				<td>
				Journalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ambrose_bierce">Ambrose Bierce</a>
				</td>
				<td>
				Journalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amelia_earhart">Amelia Earhart</a>
				</td>
				<td>
				Aviator
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amiri_baraka">Amiri Baraka</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amitabh_bachchan">Amitabh Bachchan</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amos_bronson_alcott">Amos Bronson Alcott</a>
				</td>
				<td>
				Educator
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amy_chua">Amy Chua</a>
				</td>
				<td>
				Educator
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amy_poehler">Amy Poehler</a>
				</td>
				<td>
				Comedian
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amy_tan">Amy Tan</a>
				</td>
				<td>
				Novelist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/amy_winehouse">Amy Winehouse</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anais_nin">Anais Nin</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anatole_france">Anatole France</a>
				</td>
				<td>
				Novelist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anaxagoras">Anaxagoras</a>
				</td>
				<td>
				Philosopher
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anderson_cooper">Anderson Cooper</a>
				</td>
				<td>
				Journalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andie_macdowell">Andie MacDowell</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andre_agassi">Andre Agassi</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andre_gide">Andre Gide</a>
				</td>
				<td>
				Novelist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andre_leon_talley">Andre Leon Talley</a>
				</td>
				<td>
				Editor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andre_maurois">Andre Maurois</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrea_bocelli">Andrea Bocelli</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrea_dworkin">Andrea Dworkin</a>
				</td>
				<td>
				Critic
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_breitbart">Andrew Breitbart</a>
				</td>
				<td>
				Businessman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_carnegie">Andrew Carnegie</a>
				</td>
				<td>
				Businessman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_jackson">Andrew Jackson</a>
				</td>
				<td>
				President
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_johnson">Andrew Johnson</a>
				</td>
				<td>
				President
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_lloyd_webber">Andrew Lloyd Webber</a>
				</td>
				<td>
				Composer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_wyeth">Andrew Wyeth</a>
				</td>
				<td>
				Artist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andrew_young">Andrew Young</a>
				</td>
				<td>
				Clergyman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_goldsworthy">Andy Goldsworthy</a>
				</td>
				<td>
				Artist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_grove">Andy Grove</a>
				</td>
				<td>
				Businessman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_murray">Andy Murray</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_rooney">Andy Rooney</a>
				</td>
				<td>
				Journalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_serkis">Andy Serkis</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_stanley">Andy Stanley</a>
				</td>
				<td>
				Clergyman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/andy_warhol">Andy Warhol</a>
				</td>
				<td>
				Artist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aneurin_bevan">Aneurin Bevan</a>
				</td>
				<td>
				Politician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/angela_davis">Angela Davis</a>
				</td>
				<td>
				Activist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/angela_merkel">Angela Merkel</a>
				</td>
				<td>
				Statesman
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/angelina_jolie">Angelina Jolie</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/angus_young">Angus Young</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ani_difranco">Ani DiFranco</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ann_coulter">Ann Coulter</a>
				</td>
				<td>
				Journalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ann_landers">Ann Landers</a>
				</td>
				<td>
				Journalist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anna_kendrick">Anna Kendrick</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anna_wintour">Anna Wintour</a>
				</td>
				<td>
				Editor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anne_frank">Anne Frank</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anne_lamott">Anne Lamott</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anne_morrow_lindbergh">Anne Morrow Lindbergh</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anne_wojcicki">Anne Wojcicki</a>
				</td>
				<td>
				Scientist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/annie_besant">Annie Besant</a>
				</td>
				<td>
				Philosopher
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/annie_dillard">Annie Dillard</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/annie_leibovitz">Annie Leibovitz</a>
				</td>
				<td>
				Photographer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ansel_adams">Ansel Adams</a>
				</td>
				<td>
				Photographer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anselm_kiefer">Anselm Kiefer</a>
				</td>
				<td>
				Artist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anthony_bourdain">Anthony Bourdain</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anthony_hopkins">Anthony Hopkins</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anthony_j_dangelo">Anthony J. D'Angelo</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anthony_kiedis">Anthony Kiedis</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anthony_trollope">Anthony Trollope</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/antoine_de_saintexupery">Antoine de Saint-Exupery</a>
				</td>
				<td>
				Novelist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anton_chekhov">Anton Chekhov</a>
				</td>
				<td>
				Dramatist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/antoni_gaudi">Antoni Gaudi</a>
				</td>
				<td>
				Architect
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/antonin_scalia">Antonin Scalia</a>
				</td>
				<td>
				Judge
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/antonio_banderas">Antonio Banderas</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/antonio_tabucchi">Antonio Tabucchi</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/anushka_sharma">Anushka Sharma</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/archimedes">Archimedes</a>
				</td>
				<td>
				Mathematician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aretha_franklin">Aretha Franklin</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ariana_grande">Ariana Grande</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aristophanes">Aristophanes</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aristotle">Aristotle</a>
				</td>
				<td>
				Philosopher
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arnold_h_glasow">Arnold H. Glasow</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arnold_j_toynbee">Arnold J. Toynbee</a>
				</td>
				<td>
				Historian
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arnold_palmer">Arnold Palmer</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arnold_schwarzenegger">Arnold Schwarzenegger</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arsene_wenger">Arsene Wenger</a>
				</td>
				<td>
				Coach
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arthur_ashe">Arthur Ashe</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arthur_c_clarke">Arthur C. Clarke</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arthur_conan_doyle">Arthur Conan Doyle</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arthur_miller">Arthur Miller</a>
				</td>
				<td>
				Playwright
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arthur_schopenhauer">Arthur Schopenhauer</a>
				</td>
				<td>
				Philosopher
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/artie_lange">Artie Lange</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/arundhati_roy">Arundhati Roy</a>
				</td>
				<td>
				Novelist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/asap_rocky">ASAP Rocky</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ashton_eaton">Ashton Eaton</a>
				</td>
				<td>
				Athlete
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ashton_kutcher">Ashton Kutcher</a>
				</td>
				<td>
				Actor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ashwin_sanghi">Ashwin Sanghi</a>
				</td>
				<td>
				Author
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/audre_lorde">Audre Lorde</a>
				</td>
				<td>
				Poet
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/audrey_hepburn">Audrey Hepburn</a>
				</td>
				<td>
				Actress
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/august_wilson">August Wilson</a>
				</td>
				<td>
				Playwright
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/auguste_comte">Auguste Comte</a>
				</td>
				<td>
				Sociologist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/auguste_rodin">Auguste Rodin</a>
				</td>
				<td>
				Sculptor
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/augusto_pinochet">Augusto Pinochet</a>
				</td>
				<td>
				Soldier
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/augustus">Augustus</a>
				</td>
				<td>
				Royalty
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/augustus_baldwin_longstre">Augustus Baldwin Longstreet</a>
				</td>
				<td>
				Lawyer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aung_san_suu_kyi">Aung San Suu Kyi</a>
				</td>
				<td>
				Activist
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ava_duvernay">Ava DuVernay</a>
				</td>
				<td>
				Director
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/axl_rose">Axl Rose</a>
				</td>
				<td>
				Musician
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ayn_rand">Ayn Rand</a>
				</td>
				<td>
				Writer
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/ayrton_senna">Ayrton Senna</a>
				</td>
				<td>
				Celebrity
				</td>
				</tr>
				<tr>
				<td>
				<a href="/authors/aziz_ansari">Aziz Ansari</a>
				</td>
				<td>
				Comedian
				</td>
				</tr>
				</tbody>
				</table>
				<nav aria-label="Paginarion" class="mt-4">
					<ul class="pagination">
						<li class="page-item disabled">
						<span class="page-link">Previous</span>
						</li>
						<li class="page-item"><a class="page-link" href="#">1</a></li>
						<li class="page-item active">
						<span class="page-link">
						2
						<span class="sr-only">(current)</span>
						</span>
						</li>
						<li class="page-item"><a class="page-link" href="#">3</a></li>
						<li class="page-item">
						<a class="page-link" href="#">Next</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<div class="col-md-4 col-lg-4 col-sm-4">
		<div class="card">
			<div class="card-body">
				<h4 class="card-title">Popular Topics</h4>
				<ul class="nav flex-column">
				<li class="nav-item"><a class="nav-link active" href="#">Motivational</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Life</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Inspirational</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Love</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Friendship</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Funny</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Positive</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Smile</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Leadership</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Education</a></li>
			</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<h4 class="card-title">Popular Authors</h4>
					<ul class="nav flex-column">
						<li class="nav-item"><a class="nav-link active" href="#">Albert Einstein</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Mahatma Gandhi</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Martin Luther King, Jr.</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Mark Twain</a></li>
						<li class="nav-item"><a class="nav-link" href="#">William Shakespeare</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Buddha</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Winston Churchill</a></li>
						<li class="nav-item"><a class="nav-link" href="#">John F. Kennedy</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Abraham Lincoln</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Confucius</a></li>
					</ul>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<?php include('footer.php');?>