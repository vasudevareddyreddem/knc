<?php include('header.php');?>
<div class="container-fluid mt-3 popular_section author_col">
<div class="white_bg">
	<div class="card-columns">
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">A Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="author-view.php"> A. A. Milne</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> A. P. J. Abdul Kalam</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Abraham Lincoln Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Abraham Maslow</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Adam Smith</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Aeschylus</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Aesop</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Alan Watts</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Albert Camus Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Albert Einstein Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Albert Schweitzer</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aldous Huxley</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Hamilton</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Pope</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander the Great</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexis de Tocqueville</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alfred Lord Tennyson</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alice Walker</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Ambrose Bierce</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Amelia Earhart</a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">B Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="author-view.php"> B. F. Skinner </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Barack Obama Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> bell hooks </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Ben Carson </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Ben Shapiro </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Benjamin Disraeli </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Benjamin Franklin Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Bernie Sanders </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Bertrand Russell </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Beyonce Knowles </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Bill Gates </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Bill Murray </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Billy Graham </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Blaise Pascal </a></li> 
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">C Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="author-view.php"> C. S. Lewis Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Calvin Coolidge </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Carl Jung </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Carl Sagan </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Carol Burnett </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Cesar Chavez </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Chanakya </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Charles Baudelaire </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Charles Bukowski </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Charles Darwin </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Charles de Montesquieu </a></li>
					<li class="nav-item"><a class="nav-link" href="author-view.php"> Charles Dickens </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">D Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">E Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">F Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> A. A. Milne</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> A. P. J. Abdul Kalam</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Abraham Lincoln Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Abraham Maslow</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Adam Smith</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aeschylus</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aesop</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alan Watts</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Camus Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Einstein Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Schweitzer</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aldous Huxley</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Hamilton</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Pope</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander the Great</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexis de Tocqueville</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alfred Lord Tennyson</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alice Walker</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Ambrose Bierce</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Amelia Earhart</a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">G Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> B. F. Skinner </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Barack Obama Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> bell hooks </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Ben Carson </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Ben Shapiro </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Benjamin Disraeli </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Benjamin Franklin Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bernie Sanders </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bertrand Russell </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Beyonce Knowles </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bill Gates </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bill Murray </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Billy Graham </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Blaise Pascal </a></li> 
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">H Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> C. S. Lewis Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Calvin Coolidge </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carl Jung </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carl Sagan </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carol Burnett </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Cesar Chavez </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Chanakya </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Baudelaire </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Bukowski </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Darwin </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles de Montesquieu </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Dickens </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">I Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">J Authors</h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
</div>
<?php include('footer.php');?>