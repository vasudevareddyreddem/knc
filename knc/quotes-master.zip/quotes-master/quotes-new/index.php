<?php include('header.php');?>
<div class="container-fluid mt-3 home_signal_quote">
  <blockquote class="blockquote mb-0 quote-card text-center">
      <p class="font_s15">I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</p>
      <footer class="blockquote-footer">William Shakespeare<div class="mt-2"><small class=""><a href="#"><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i></a> &nbsp;&nbsp;<a href="#"><i class="fa fa-refresh font_s12 vm" aria-hidden="true"></i></a></small></div></footer>
   </blockquote>
</div>
<div class="container-fluid mt-3 popular_section">
	<div class="card-group">
	  <div class="card">
		<div class="card-body">
		  <h4 class="card-title">Popular Topics</h4>
			<ul class="nav flex-column">
				<li class="nav-item"><a class="nav-link active" href="#">Motivational</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Life</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Inspirational</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Love</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Friendship</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Funny</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Positive</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Smile</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Leadership</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Education</a></li>
				<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More Topics</a></li>
			</ul>
		</div>
	  </div>
	  <div class="card">
		<div class="card-body">
		  <h4 class="card-title">Popular Authors</h4>
			<ul class="nav flex-column">
				<li class="nav-item"><a class="nav-link active" href="#">Albert Einstein</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Mahatma Gandhi</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Martin Luther King, Jr.</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Mark Twain</a></li>
				<li class="nav-item"><a class="nav-link" href="#">William Shakespeare</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Buddha</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Winston Churchill</a></li>
				<li class="nav-item"><a class="nav-link" href="#">John F. Kennedy</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Abraham Lincoln</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Confucius</a></li>
				<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More Authors</a></li>
			</ul>
		</div>
	  </div>
	  <div class="card">
		<div class="card-body">
		  <h4 class="card-title">Today's Birthdays</h4>
		 <ul class="nav flex-column">
				<li class="nav-item"><a class="nav-link active" href="#">1888 - T. S. Elio</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1967 - Shannon Hoon</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1946 - Andrea Dworkin</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1981 - Serena Williams</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1889 - Martin Heidegger</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1946 - Andrea Dworkin</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Winston Churchill</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1889 - Martin Heidegger</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1967 - Shannon Hoon</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1946 - Andrea Dworkin</a></li>
				<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More Birthdays</a></li>
			</ul>
		</div>
	  </div>
	  <div class="card">
		<div class="card-body">
		  <h4 class="card-title">Ad Here</h4>
		 <ul class="nav flex-column">
				<li class="nav-item"><a class="nav-link active" href="#">1888 - T. S. Elio</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1967 - Shannon Hoon</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1946 - Andrea Dworkin</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1981 - Serena Williams</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1889 - Martin Heidegger</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1946 - Andrea Dworkin</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Winston Churchill</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1889 - Martin Heidegger</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1967 - Shannon Hoon</a></li>
				<li class="nav-item"><a class="nav-link" href="#">1946 - Andrea Dworkin</a></li>
				<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More Birthdays</a></li>
			</ul>
		</div>
	  </div>
	</div>
</div>
<div class="container-fluid mt-3 popular_section">
	<div class="card">
		<div class="card-header title_fonts">Authors to Explore</div>
		<div class="card-body">
			<div class="card-group">	
				<div class="card">
					<div class="">
						<ul class="nav flex-column">
							<li class="nav-item"><a class="nav-link active" href="#">A. P. J. Abdul Kalam</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Albert Camus</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Aristotle</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Audrey Hepburn</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Audrey Hepburn</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Benjamin Franklin</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Bill Gates</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Bob Marley</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Bruce Lee</a></li>
							<li class="nav-item"><a class="nav-link" href="#">C. S. Lewis</a></li>
						</ul>
					</div>
				</div>
				<div class="card">
					<div class="">
						<ul class="nav flex-column">
							<li class="nav-item"><a class="nav-link active" href="#">Carol Burnett</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Christopher Reeve</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Colin Kaepernick</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Conor McGregor</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Dalai Lama</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Donald Trump</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Edgar Allan Poe</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Elon Musk</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Eleanor Roosevelt</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Eminem</a></li>
						</ul>
					</div>
				</div>
				<div class="card">
					<div class="">
						<ul class="nav flex-column">
							<li class="nav-item"><a class="nav-link active" href="#">Johann Wolfgang von Goethe</a></li>
							<li class="nav-item"><a class="nav-link" href="#">John Muir</a></li>
							<li class="nav-item"><a class="nav-link" href="#">John Wooden</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Marilyn Monroe</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Marcus Aurelius</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Maya Angelou</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Napoleon Bonaparte</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Nelson Mandela</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Niccolo Machiavelli</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Norman Cousins</a></li>
						</ul>
					</div>
				</div>
				<div class="card">
					<div class="">
						<ul class="nav flex-column">
							<li class="nav-item"><a class="nav-link active" href="#">Ernest Hemingway</a></li>
							<li class="nav-item"><a class="nav-link" href="#">George Bernard Shaw</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Karl Marx</a></li>
							<li class="nav-item"><a class="nav-link" href="#">George Orwell</a></li>
							<li class="nav-item"><a class="nav-link" href="#">George Washington</a></li>
							<li class="nav-item"><a class="nav-link" href="#">H. Jackson Brown, Jr.</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Helen Keller</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Henry David Thoreau</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Henry Ford</a></li>
							<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More Authors</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Quotes Trending -->
<div class="container-fluid mt-4 quotescard">
<div class="title_heading_center pos_r mar_b20 mb-3 social_sharing"><h4><span class="span_bg_g">Quotes Currently Trending</span></h4><div class="title_lines"></div></div>				
<!--<div class="title_fonts text-left mb-3">Quotes currently Trending</div>-->
<div class="card-columns">
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">America will never be destroyed from the outside. If we falter and lose our freedoms, it will be because we destroyed ourselves.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">I refuse to accept the view that mankind is so tragically bound to the starless midnight of racism and war that the bright daybreak of peace and brotherhood can never become a reality... I believe that unarmed truth and unconditional love will have the final word.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">Life is like riding a bicycle. To keep your balance, you must keep moving.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">The ultimate tragedy is not the oppression and cruelty by the bad people but the silence over that by the good people.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">If we ever forget that we are One Nation Under God, then we will be a nation gone under.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">The good man is the friend of all living things.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">Patriotism is when love of your own people comes first; nationalism, when hate for people other than your own comes first.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">Guard against the impostures of pretended patriotism.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">Martin Luther King, Jr. didn't carry just a piece of cloth to symbolize his belief in racial equality; he carried the American flag.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">America will never be destroyed from the outside. If we falter and lose our freedoms, it will be because we destroyed ourselves.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">I refuse to accept the view that mankind is so tragically bound to the starless midnight of racism and war that the bright daybreak of peace and brotherhood can never become a reality... I believe that unarmed truth and unconditional love will have the final word.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">Life is like riding a bicycle. To keep your balance, you must keep moving.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">The ultimate tragedy is not the oppression and cruelty by the bad people but the silence over that by the good people.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">If we ever forget that we are One Nation Under God, then we will be a nation gone under.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p><a href="quote-view.php" class="quotescard_anchor">The good man is the friend of all living things.</a></p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
</div>
<?php include('footer.php');?>