<?php include('header.php');?>
<div class="container-fluid mt-5 popular_section">
	<div class="">
		<div class="row justify-content-md-center">
			<div class="col-md-8 col-lg-8 col-sm-8 ">
				<div class="card">
					<div class="card-body">
					<h4 class="card-title">Post a Quote</h4>
						<form>
							<div class="form-group row">
								<label for="staticEmail" class="col-sm-2 col-form-label">Categories</label>
								<div class="col-sm-10">
									<select class="custom-select mb-2 mr-sm-2 mb-sm-0 post_a_quote_width" id="inlineFormCustomSelect">
										<option selected>Choose...</option>
										<option value="1">Motivational</option>
										<option value="2">Life</option>
										<option value="3">Inspirational</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword" class="col-sm-2 col-form-label">Languages</label>
								<div class="col-sm-10">
									<select class="custom-select mb-2 mr-sm-2 mb-sm-0 post_a_quote_width" id="inlineFormCustomSelect">
										<option selected>Choose...</option>
										<option value="1">English</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword" class="col-sm-2 col-form-label">Quote Image</label>
								<div class="col-sm-10">
									<label class="custom-file post_a_quote_width">
									<input type="file" id="file2" class="custom-file-input">
									<span class="custom-file-control"></span>
									</label>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword" class="col-sm-2 col-form-label">Wrote a Quote</label>
								<div class="col-sm-10">
									 <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword" class="col-sm-2 col-form-label">Keywords</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="inputPassword" placeholder="Keywords">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword" class="col-sm-2 col-form-label">&nbsp;</label>
								<div class="col-sm-10">
									<button type="button" class="btn btn-primary">Post Your Quote</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include('footer.php');?>