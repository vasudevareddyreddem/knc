<?php include('header.php');?>
<div class="container-fluid mt-5">
	<div class="row justify-content-md-center">
		<div class="col-sm-5 col-md-5 col-lg-5">
			<div class="card text-center">
				<img class="mx-auto mt-4 d-block rounded-circle" src="images/avatar04.png" alt="Card image cap" width="150">
				<div class="card-body">
					<h4 class="card-title">John Andreson Smith</h4>
					<p class="small text-muted">johnandresonsmith@gmail.com</p>
					<p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				</div>
				
				<div class="card-body">
					<a href="#" class="card-link">Card link</a>
					<a href="#" class="card-link">Another link</a>
					<a href="#" class="card-link">Another link</a>
			
				</div>
			</div>
		</div>
	</div>
</div>
<?php include('footer.php');?>