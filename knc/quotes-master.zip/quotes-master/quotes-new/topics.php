<?php include('header.php');?>
<div class="container-fluid mt-3 popular_section author_col">
<div class="white_bg">
	<div class="main_title"><h2>Topic Index</h2></div>
	<div class="card-columns">
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">A </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> A. A. Milne</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> A. P. J. Abdul Kalam</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Abraham Lincoln Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Abraham Maslow</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Adam Smith</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aeschylus</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aesop </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alan Watts</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Camus Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Einstein Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Schweitzer</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aldous Huxley</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Hamilton</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Pope</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander the Great</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexis de Tocqueville</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alfred Lord Tennyson</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alice Walker</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Ambrose Bierce</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Amelia Earhart</a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">B </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> B. F. Skinner </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Barack Obama Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> bell hooks </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Ben Carson </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Ben Shapiro </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Benjamin Disraeli </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Benjamin Franklin Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bernie Sanders </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bertrand Russell </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Beyonce Knowles </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bill Gates </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bill Murray </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Billy Graham </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Blaise Pascal </a></li> 
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">C </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> C. S. Lewis Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Calvin Coolidge </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carl Jung </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carl Sagan </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carol Burnett </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Cesar Chavez </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Chanakya </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Baudelaire </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Bukowski </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Darwin </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles de Montesquieu </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Dickens </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">D </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">E </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">F </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> A. A. Milne</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> A. P. J. Abdul Kalam</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Abraham Lincoln Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Abraham Maslow</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Adam Smith</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aeschylus</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aesop</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alan Watts</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Camus Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Einstein Favorite</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Albert Schweitzer</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Aldous Huxley</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Hamilton</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander Pope</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexander the Great</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alexis de Tocqueville</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alfred Lord Tennyson</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Alice Walker</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Ambrose Bierce</a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Amelia Earhart</a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">G </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> B. F. Skinner </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Barack Obama Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> bell hooks </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Ben Carson </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Ben Shapiro </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Benjamin Disraeli </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Benjamin Franklin Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bernie Sanders </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bertrand Russell </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Beyonce Knowles </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bill Gates </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Bill Murray </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Billy Graham </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Blaise Pascal </a></li> 
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">H </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> C. S. Lewis Favorite </a></li> 
					<li class="nav-item"><a class="nav-link" href="#"> Calvin Coolidge </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carl Jung </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carl Sagan </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Carol Burnett </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Cesar Chavez </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Chanakya </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Baudelaire </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Bukowski </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Darwin </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles de Montesquieu </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Charles Dickens </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">I </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			  <h4 class="card-title">J </h4>
				<ul class="nav flex-column">
					<li class="nav-item"><a class="nav-link" href="#"> Dalai Lama Favorite </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dale Carnegie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dan Quayle </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dante Alighieri </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Dave Grohl </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Bowie </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Coverdale </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Lynch </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> David Ogilvy </a></li>
					<li class="nav-item"><a class="nav-link" href="#"> Deepak Chopra </a></li>
					<li class="nav-item mt-2"><a class="btn btn-primary btn-sm" href="#">More</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
</div>
<?php include('footer.php');?>