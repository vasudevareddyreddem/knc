<?php include('header.php');?>
<div class="container-fluid mt-3">
	<div class="">
		<div class="row">
			<div class="col-md-9 col-lg-9 col-sm-9">
				<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner slider_quote">
						<div class="carousel-item active">
							<div class="card no_padding">
								<blockquote class="blockquote mb-0 quote-card">
								<p class="font_s15">I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</p>
								<footer class="blockquote-footer"><a href="#">William Shakespeare</a></footer>
								</blockquote>
								<div class="card-footer">
								<div class="pull-left">
								<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
								</div>
								</div>
								<div class="pull-right">
								<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
								<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
								<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
								</div>
								<div class="clearfix"></div>
								</div>
							</div>
						</div>
						<div class="carousel-item">
						<div class="card no_padding">
								<blockquote class="blockquote mb-0 quote-card">
								<p class="font_s15">I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</p>
								<footer class="blockquote-footer"><a href="#">William Shakespeare</a></footer>
								</blockquote>
								<div class="card-footer">
								<div class="pull-left">
								<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
								</div>
								</div>
								<div class="pull-right">
								<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
								<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
								<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
								</div>
								<div class="clearfix"></div>
								</div>
							</div>
						</div>
						<div class="carousel-item">
						<div class="card no_padding">
								<blockquote class="blockquote mb-0 quote-card">
								<p class="font_s15">I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</p>
								<footer class="blockquote-footer"><a href="#">William Shakespeare</a></footer>
								</blockquote>
								<div class="card-footer">
								<div class="pull-left">
								<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
								</div>
								</div>
								<div class="pull-right">
								<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
								<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
								<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
								</div>
								<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</div>
					<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"><i class="fa fa-angle-left" aria-hidden="true"></i></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- Related Trending -->
<div class="container-fluid mt-4 quotescard">
<div class="title_heading_center pos_r mar_b20 mb-3 social_sharing"><h4><span class="span_bg_g">Related Quotes </span></h4><div class="title_lines"></div></div>				
<!--<div class="title_fonts text-left mb-3">Quotes currently Trending</div>-->
<div class="card-columns">
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>America will never be destroyed from the outside. If we falter and lose our freedoms, it will be because we destroyed ourselves.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>I refuse to accept the view that mankind is so tragically bound to the starless midnight of racism and war that the bright daybreak of peace and brotherhood can never become a reality... I believe that unarmed truth and unconditional love will have the final word.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>Life is like riding a bicycle. To keep your balance, you must keep moving.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>The ultimate tragedy is not the oppression and cruelty by the bad people but the silence over that by the good people.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>If we ever forget that we are One Nation Under God, then we will be a nation gone under.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>The good man is the friend of all living things.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>Patriotism is when love of your own people comes first; nationalism, when hate for people other than your own comes first.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>Guard against the impostures of pretended patriotism.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>Martin Luther King, Jr. didn't carry just a piece of cloth to symbolize his belief in racial equality; he carried the American flag.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>America will never be destroyed from the outside. If we falter and lose our freedoms, it will be because we destroyed ourselves.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>I refuse to accept the view that mankind is so tragically bound to the starless midnight of racism and war that the bright daybreak of peace and brotherhood can never become a reality... I believe that unarmed truth and unconditional love will have the final word.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>Life is like riding a bicycle. To keep your balance, you must keep moving.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>The ultimate tragedy is not the oppression and cruelty by the bad people but the silence over that by the good people.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>If we ever forget that we are One Nation Under God, then we will be a nation gone under.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>I see Americans of every party, every background, every faith who believe that we are stronger together: black, white, Latino, Asian, Native American; young, old; gay, straight; men, women, folks with disabilities, all pledging allegiance under the same proud flag to this big, bold country that we love. That's what I see. That's the America I know!</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card">
		<blockquote class="blockquote mb-0 card-body">
			<p>The good man is the friend of all living things.</p>
			<footer class="blockquote-footer">
			<small class="text-muted">
			<a href="#">Abraham Lincoln</a>
			</small>
			</footer>
		</blockquote>
		<div class="card-keywords">
			<small><a href="#">Peace,</a> <a href="#">Peaceful,</a> <a href="#"> Impossible</a></small>	
		</div>
		<div class="card-footer">
			<div class="pull-left">
				<div class="mar_t3"><small class="" ><i class="fa fa-heart-o fa-1x_h" aria-hidden="true"></i> 400</small> 
				<small class="" ><span class="font_w600"> &nbsp;&nbsp; 1477 Views</span></small></div>
			</div>
			<div class="pull-right">
				<div class="social google-pluse"><i class="fa fa-google-plus fa-1x"></i></div>
				<div class="social facebook"><i class="fa fa-facebook fa-1x"></i></div>
				<div class="social twitter"><i class="fa fa-twitter fa-1x"></i></div> 
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
</div>
<?php include('footer.php');?>
<script>
$('.carousel').carousel({
 interval: false
})
</script>