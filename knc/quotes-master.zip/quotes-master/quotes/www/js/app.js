// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services', 'ngCordova','ngResource'])
   .run(function($ionicPlatform) {
       $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
          if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);

          }
          if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
          }
       });
})

.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
	$ionicConfigProvider.views.maxCache(0);
  $stateProvider

  .state('app', {
      url: '/app',
      abstract: true,
      templateUrl: 'templates/menu.html',
      controller: 'AppCtrl'
  })

   .state('app.home', {
        url: '/home',
        views: {
          'menuContent': {
            templateUrl: 'templates/home.html',
            controller: 'HomeCtrl'
        }
      }
    })

    .state('app.postquote', {
      url: '/postquote',
      views: {
        'menuContent': {
          templateUrl: 'templates/postquote.html',
          controller: 'PostQuoteCtrl'
        }
      }
    })
    
     .state('app.updatequote', {
      url: '/updatequote/:quoteId',
      views: {
        'menuContent': {
          templateUrl: 'templates/updatequote.html',
          controller: 'UpdateQuoteCtrl'
        }
      }
    })
	.state('app.landing', {
        url: '/landing',
        views: {
          'menuContent': {
            templateUrl: 'templates/landing.html',
            controller: 'LandingCtrl'
        }
      }
    })
	.state('app.register', {
        url: '/register',
        views: {
          'menuContent': {
            templateUrl: 'templates/register.html',
            controller: 'RegisterCtrl'
        }
      }
    })

    .state('app.quoteview', {
        url: '/quoteview/:quoteId',
        views: {
          'menuContent': {
            templateUrl: 'templates/quoteview.html',
            controller: 'QuoteViewCtrl'
        }
      }
    })
     
   .state('app.quotes', {
        url: '/quotes/:authorId/:categoryId',
        views: {
          'menuContent': {
            templateUrl: 'templates/quotes.html',
            controller: 'QuotesCtrl'
      }
    }
  })

  .state('app.authors', {
      url: '/authors',
      views: {
        'menuContent': {
          templateUrl: 'templates/authors.html',
          controller: 'AuthorsCtrl'
      }
    }
  })

  .state('app.categories', {
        url: '/categories',
        views: {
          'menuContent': {
            templateUrl: 'templates/categories.html',
            controller: 'CategoriesCtrl'
        }
      }
    })

  .state('app.userquotes', {
      url: '/userquotes/:flagId',
      views: {
        'menuContent': {
          templateUrl: 'templates/userquotes.html',
           controller: 'UserQuotesCtrl'
        }
      }
    })

	.state('app.profile', {
      url: '/profile',
      views: {
        'menuContent': {
          templateUrl: 'templates/profile.html',
          controller: 'ProfileCtrl'
        }
      }
    })
	
  	.state('app.updateprofile', {
      url: '/updateprofile',
      views: {
        'menuContent': {
          templateUrl: 'templates/updateprofile.html',
          controller: 'UpdateProfileCtrl'
        }
      }
    })

    .state('app.searchresults', {
      url: '/searchresults/:searchword',
      views: {
        'menuContent': {
          templateUrl: 'templates/searchresults.html',
          controller: 'SearchResultsCtrl'
        }
      }
    })

    //not use
	.state('app.settings', {
      url: '/settings',
      views: {
        'menuContent': {
          templateUrl: 'templates/settings.html'
        }
      }
    })

  .state('app.single', {
    url: '/playlists/:playlistId',
    views: {
      'menuContent': {
        templateUrl: 'templates/playlist.html',
        controller: 'PlaylistCtrl'
      }
    }
  });
  // if none of the above states are matched, use this as the fallback
   $urlRouterProvider.otherwise('/app/home');
   
});

