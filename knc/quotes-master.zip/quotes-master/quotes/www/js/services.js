// var serviceUrl = "http://spreadthequote.com/";
var serviceUrl = "http://localhost/quotes/trunk/";

angular.module('starter.services', [])

.factory('LoginService', ['$resource', function ($resource) {
    return {
      Login: $resource(serviceUrl + 'sign-in', {}, {
        save: { method: "POST" },
      }),
      Registration: $resource(serviceUrl + 'sign-up', {}, {
          save: { method: "POST"},
        }),
        Get: $resource(serviceUrl + 'reg-authentication/:userId', {}, {
          get: { method: "GET" ,params:{userId:'@userId'}},
        }),
      }
   }])

    .factory('SearchService', ['$resource', function ($resource) {
      return {
        SearchResults: $resource(serviceUrl + 'search-results-app', {}, {
          save: { method: "POST"},
        }),
        Favorites: $resource(serviceUrl + 'favoriting-quote', {}, {
          save: { method: "POST"},
        }),
      }
   }])

 .factory('HomeService', ['$resource', function ($resource) {
      return {
        GetAll: $resource(serviceUrl + 'quote-admin-user', {}, {
          save: { method: "POST" },
        }),
        GetRandomQuotes: $resource(serviceUrl + 'refresh-quote/refresh-:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId'} },
        }),
        Favorites: $resource(serviceUrl + 'favoriting-quote', {}, {
          save: { method: "POST"},
        }),
        PostQuote: $resource(serviceUrl + 'post-quote', {}, {
          save: { method: "POST"},
        }),
         Languages: $resource(serviceUrl + 'languages-list', {}, {
          get: { method: "GET"},
        }),
      }
   }])

 .factory('GetQuotesInfoService', ['$resource', function ($resource) {
      return {
        QuotesInformation: $resource(serviceUrl + 'quote-information', {}, {
          save: { method: "POST"},
        }),
        Favorites: $resource(serviceUrl + 'favoriting-quote', {}, {
          save: { method: "POST"},
        }),
       }
   }])

 .factory('GetLatestQuotesService', ['$resource', function ($resource) {
      return {
        GetLatestQuotes: $resource(serviceUrl + 'latest-quotes/:count-:pageno-:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId',pageno:'@pageno',count:'@count'} },
        }),
        GetviewsCount:$resource(serviceUrl + 'viewed-quote', {}, {
          save: { method: "POST"},
        }),
        Favorites: $resource(serviceUrl + 'favoriting-quote', {}, {
          save: { method: "POST"},
        }),
      }
   }])

 .factory('GetAllAuthorsService', ['$resource', function ($resource) {
     return {
      GetAuthors: $resource(serviceUrl + 'authors-list/:count-:pageno', {}, {
        get: { method: "GET" ,params:{pageno:'@pageno',count:'@count'} },
      }),
      AuthorQuotes: $resource(serviceUrl + 'author-quotes', {}, {
          save: { method: "POST"},
        }),
      }
   }])

  .factory('GetCatageriosService', ['$resource', function ($resource) {
      return {
        GetCatagories: $resource(serviceUrl + 'load-categories-list/:count-:pageno', {}, {
          get: { method: "GET" ,params:{pageno:'@pageno',count:'@count'} },
        }),
        CatagoryQuotes: $resource(serviceUrl + 'category-quotes', {}, {
          save: { method: "POST"},
        }),
       }
    }])

  .factory('GetUserQuotesService', ['$resource', function ($resource) {
      return {
        GetFavoriteQuotes: $resource(serviceUrl + 'user-favorites/:count-:pageno-:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId',pageno:'@pageno',count:'@count'} },
        }),
        GetUserQuotes: $resource(serviceUrl + 'user-quotes/:count-:pageno-:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId',pageno:'@pageno',count:'@count'} },
        }),
        GetTopQuotes: $resource(serviceUrl + 'top-quotes/:count-:pageno-:userId', {}, {
          get: { method: "GET" ,params:{ count:'@count',pageno:'@pageno',userId:'@userId'} },
        }),
        EditQuote: $resource(serviceUrl + 'edit-user-quote/:quoteId', {}, {
          get: { method: "GET" ,params:{ quoteId:'@quoteId'} },
        }),
        GetUpdateQuoteInfo: $resource(serviceUrl + 'update-user-quote/:quoteId', {}, {
          put: { method: "PUT" ,params:{ quoteId:'@quoteId'} },
        }),
        DeleteQuote: $resource(serviceUrl + 'quote-user-del/:quoteId', {}, {
          del: { method: "DELETE" ,params:{ quoteId:'@quoteId'}},
        }),
        Favorites: $resource(serviceUrl + 'favoriting-quote', {}, {
          save: { method: "POST"},
        }),
        GetviewsCount:$resource(serviceUrl + 'viewed-quote', {}, {
          save: { method: "POST"},
        }),
      }
   }])

  .factory('ProfileService', ['$resource', function ($resource) {
      return {
        GetUserInfo: $resource(serviceUrl + 'view-user-details/:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId'} },
        }),
        GetFavoriteQuotes: $resource(serviceUrl + 'user-favorites/:count-:pageno-:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId',pageno:'@pageno',count:'@count'} },
        }),
        GetUserQuotes: $resource(serviceUrl + 'user-quotes/:count-:pageno-:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId',pageno:'@pageno',count:'@count'} },
        }),
        GetUserDetails: $resource(serviceUrl + 'view-user-details/:userId', {}, {
          get: { method: "GET" ,params:{ userId:'@userId'} },
        }),
        GetUpdateProfileInfo: $resource(serviceUrl + 'update-user-details/:userId', {}, {
          put: { method: "PUT" ,params:{ userId:'@userId'} },
        }),

        fbLogin: $resource(serviceUrl + 'scoial-logins', {}, {
        save: { method: "POST" },
      })
      }
   }])

   .factory('SocialLoginService', ['$resource', function ($resource) {
    return {
      Login: $resource(serviceUrl + 'scoial-logins', {}, {
        save: { method: "POST" },
      })
    }
  }]);



  