angular.module('starter.controllers', [])

  .controller('AppCtrl', function ($scope, $ionicModal, $timeout, $state, $rootScope) {

    if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
      $scope.userLoginStatus = false;
    } else {
      $scope.userLoginStatus = true;
    }

    $rootScope.$on("CallParentMethod", function () {
      $scope.reloadMenu();
    });

    $scope.reloadMenu = function () {
      $scope.userLoginStatus = false;
      $state.go('app.profile');
    }

    $scope.searchOpen = function () {
      $scope.showMe = !$scope.showMe;
     // $scope.searchword={{searchword}};
    }

    $scope.goToSearchResultPage = function () {
      // var searchword = document.getElementById('wordSearch').value;
      var searchword = 'sugar';
      $state.go('app.searchresults', { searchword: searchword });
    }

    $scope.searchClose = function () {
      $scope.showMe = false;
    }

    $scope.logout = function () {
      localStorage.removeItem('userId');
      $state.go('app.home');
    }

    $scope.login = function () {
      if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
        $state.go('app.profile');
      } else {
        $state.go('app.landing');
      }
    }

    $scope.getQuotes = function (authorId, categoryId) {
      $state.go('app.quotes', { authorId: authorId, categoryId: categoryId });
    }

    $scope.getfavoritequotes = function (userId, flagId) {
      $state.go('app.userquotes', { userId: userId, flagId: flagId });
    }

    $scope.getUserquotes = function (userId, flagId) {
      $state.go('app.userquotes', { userId: userId, flagId: flagId });
    }

    $scope.gettopquotes = function (userId, flagId) {
      $state.go('app.userquotes', { userId: userId, flagId: flagId });
    }

    $scope.getusers = function (userId) {
      $state.go('app.profile', { userId: userId });
    }

  })

  .controller('SearchResultsCtrl', function ($ionicLoading, $rootScope, $scope, $stateParams, $state, SearchService) {
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
      $scope.favshowhide = true;
    } else {
      $scope.favshowhide = false;
    }
    var wordsearch = $stateParams.searchword;
    SearchService.SearchResults.save({ QtSearch: wordsearch }, function (response) {
      $scope.SearchInformation = response.searchQtList;
      $ionicLoading.hide();
    });

    $scope.shareQuote = function (message) {
      window.plugins.socialsharing.share(message, null, null, null);
    }

    $scope.quoteview = function (quoteId) {
      $state.go('app.quoteview', { quoteId: quoteId });
    }

    $scope.favorite = function (quoteId) {
      var userId = localStorage.getItem('userId');
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      SearchService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        $scope.favorites = response;
        $ionicLoading.hide();
      })
    }

  })


  .controller('HomeCtrl', function ($compile, $ionicLoading, $scope, $stateParams, $state, HomeService) {
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
      $scope.favshowhide = true;
      $scope.postquoteshowhide = true;
      $scope.unfavshowhide = true;
    } else {
      $scope.favshowhide = false;
      $scope.postquoteshowhide = false;
      $scope.unfavshowhide = false;
    }
    var userId = localStorage.getItem('userId');
    HomeService.GetAll.save({ u_id: userId }, function (response) {
      $scope.quoteoftheday = response.quoteoftheday;
      $scope.bestuserquote = response.bestuserquote;
      $scope.randomQuote = response.randomQuote;
      $ionicLoading.hide();
    });

    $scope.randomquote = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      HomeService.GetRandomQuotes.get({userId:userId},function (response) {
        $scope.randomQuote = response.randomQuote;
        console.log(response.randomQuote.checkquotefav);
        if(response.randomQuote.checkquotefav=='0')
        {
          $scope.unfavshowhide = true;
        }
        else{
          $scope.favshowhide = true; 
        }
        $ionicLoading.hide();
      })
    }

    $scope.postquote = function () {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      $state.go('app.postquote');
      $ionicLoading.hide();
    }

    $scope.shareQuote = function (message) {
      window.plugins.socialsharing.share(message, null, null, null);
    }

    $scope.favorite = function (quoteId) {
      var userId = localStorage.getItem('userId');
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      HomeService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        angular.element(document.querySelector('#favorite_id_' + quoteId)).html("");
        angular.element(document.querySelector('#favorite_id_' + quoteId)).append($compile('<a href="javascript:void(0)" ng-click="unfavorite(' + quoteId + ')"><i class="icon ion-android-favorite-outline"></i></a>&nbsp;&nbsp;&nbsp;')($scope));
        $ionicLoading.hide();
      })
    }

    $scope.unfavorite = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      HomeService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        angular.element(document.querySelector('#favorite_id_' + quoteId)).html("");
        angular.element(document.querySelector('#favorite_id_' + quoteId)).append($compile('<a href="javascript:void(0)" ng-click="favorite(' + quoteId + ')"><i class="icon ion-android-favorite"></i></a>&nbsp;&nbsp;&nbsp;')($scope));
        $ionicLoading.hide();
      })
    }

    $scope.quoteview = function (quoteId) {
      $state.go('app.quoteview', { quoteId: quoteId });
    }
    $ionicLoading.hide();
  })

  .controller('PostQuoteCtrl', function ($ionicLoading, $rootScope, $scope, $stateParams, $state, HomeService,GetCatageriosService) {
    HomeService.Languages.get(function (response) {
      $scope.Languagelist = response.langList;
    })
    count=20;
    pageno=1;
    GetCatageriosService.GetCatagories.get({ count: count, pageno: pageno }, function (response) {
      $scope.Catagorieslist = response.catArray;
    })
      $scope.postquote = function () {
       $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      var userId = localStorage.getItem('userId');
      var catagories = document.getElementById('catagory').value;
      console.log(catagories);
      var quotename = document.getElementById('qname').value;
      var lang = document.getElementById('language').value;
      var keytags = document.getElementById('qtags').value;
      HomeService.PostQuote.save({ u_id: userId, qc_lang_id: lang, qc_name: quotename, qc_tags: keytags, qc_qc_cat_id: catagories }, function (response) {
        $scope.postQuoteInfo = response;
        $ionicLoading.hide();
        $state.go('app.userquotes', { userId: userId, flagId: 2 });
     });
    }
  })

  .controller('QuoteViewCtrl', function ($ionicLoading, $scope, $stateParams, $state, GetQuotesInfoService) {
    var quoteId = $stateParams.quoteId;
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
      $scope.favshowhide = true;
    } else {
      $scope.favshowhide = false;
    }

    GetQuotesInfoService.QuotesInformation.save({ qc_id: quoteId }, function (response) {
      $scope.QuotesInfo = response.quoteinfo;
      $ionicLoading.hide();
    });

    $scope.shareQuote = function (message) {
      window.plugins.socialsharing.share(message, null, null, null);
    }
    $scope.wikiLink = function (wikiURL) {
      cordova.InAppBrowser.open(wikiURL, '_blank');
    }

    $scope.favorite = function (quoteId) {
      var userId = localStorage.getItem('userId');
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      GetQuotesInfoService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        $scope.favorites = response;
        $ionicLoading.hide();
      });
    }

  })

  .controller('LandingCtrl', function ($ionicLoading, $rootScope, $scope, $stateParams, $state, LoginService, SocialLoginService) {
    $scope.facebookLogin = function () {
      facebookConnectPlugin.login(["public_profile", "email"], fbLoginSuccess, function (error) {
        if (window.plugins.toast) {
          window.plugins.toast.showWithOptions({
            message: "Authentication failed",
            duration: "short",
            position: "top",
            styling: {
              opacity: 0.75,
              backgroundColor: '#3b5998',
              textColor: '#FFFFFF',
              textSize: 20.5,
              cornerRadius: 16,
              horizontalPadding: 20,
              verticalPadding: 16
            }
          });
        }

      })
    }
    function fblogout() {
      facebookConnectPlugin.logout(function () { }, function (e) {
        if (window.plugins.toast) {
          window.plugins.toast.showWithOptions({
            message: "error" + e,
            duration: "short",
            position: "top",
            styling: {
              opacity: 0.75,
              backgroundColor: '#3b5998',
              textColor: '#FFFFFF',
              textSize: 20.5,
              cornerRadius: 16,
              horizontalPadding: 20,
              verticalPadding: 16
            }
          });
        }
      });
    }

    function fbLoginSuccess(response) {
      if (response.authResponse) {
        processFacebook();
      }
    }

    function processFacebook() {
      facebookConnectPlugin.api("me/?fields=id,last_name,email,gender,first_name", ["public_profile", "email"], fbAPIResponse);
    }

    function fbAPIResponse(response) {
      var id = response.id;
      var email = response.email;
      var name = response.first_name;
      var lname = response.last_name;
      var loginSocial = 'fbLogin';

      SocialLoginService.Login.save({ id: id, email: email, name: name, lname: lname, loginSocial: loginSocial }, function (response) {
        $scope.userId = response.userInfo.u_id;
        localStorage.setItem('userId', $scope.userId);
        $rootScope.$emit("CallParentMethod", {});
      });
    }

    $scope.googleLogin = function () {
      console.log("googleLogin");
      window.plugins.googleplus.login(
        {
          'scopes': 'profile',
          'webClientId': '505959480794-1hjjp3pi5ej4nf2i96kjv72f4v6k0ctq.apps.googleusercontent.com',
          'offline': true,
        },
        function (obj) {
          var id = obj.userId;
          var email = obj.email;
          var name = obj.displayName;
          var lname = " ";
          var loginSocial = 'gplusLogin';
          $rootScope.$emit("CallParentMethod", {});
        },
        function (msg) {
          navigator.notification.alert('error: ' + msg);
          if (window.plugins.toast) {
            window.plugins.toast.showWithOptions({
              message: msg,
              duration: "short",
              position: "top",
              styling: {
                opacity: 0.75,
                backgroundColor: '#D34836',
                textColor: '#FFFFFF',
                textSize: 20.5,
                cornerRadius: 16,
                horizontalPadding: 20,
                verticalPadding: 16
              }
            });
          }
        });
    }

    function googleLogout() {
      window.plugins.googleplus.logout(
        function (msg) {
        }
      );
    }


    $scope.register = function () {
      $state.go('app.register');
    }

    $scope.loginFailMessage = "";
    $scope.gotoprofile = function () {
      var email = document.getElementById('userEmail').value;
      var pwd = document.getElementById('userPwd').value;
      var emailavail = 1;
      if (email != "" && pwd != "") {
        $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
        LoginService.Login.save({ u_email: email, u_password: pwd, loginwithemail: emailavail }, function (response) {
          if (response.output == 'fail') {
            $ionicLoading.hide();
            $scope.loginFailMessage = "Invalid Email id & Password.";
          } else {
            localStorage.setItem('userId', response.userdata.uid);
            $ionicLoading.hide();
            $rootScope.$emit("CallParentMethod", {});
          }
        })
      }
      else {
        $scope.loginFailMessage = "Invalid Email id & Password.";
      }
    }
  })

  .controller('RegisterCtrl', function ($ionicLoading, $rootScope, $scope, $stateParams, $state, LoginService) {
    $scope.gotologin = function () {
      var username = document.getElementById('userName').value;
      var email = document.getElementById('Email').value;
      var pwd = document.getElementById('Pwd').value;
      var imgfile = document.getElementById('imagefile').value;
      var aboutme = document.getElementById('aboutMe').value;
      LoginService.Registration.save({
        uf_fname: username, uf_lname: '', u_email: email, u_password: pwd, uf_pic: imgfile,
        uf_about_me: aboutme
      }, function (response) {
        $scope.registrationRes = response;
        var uid = response.u_id;
        if (response.u_id == uid) {
          LoginService.Get.get({ userId: uid }, function (response) {
            $scope.userdetails = response.userdata;
            $state.go('app.landing');
          })
        }
      }
      )
    }
  })

  .controller('QuotesCtrl', function ($compile, $ionicLoading, $scope, $stateParams, $state, GetCatageriosService, GetAllAuthorsService, GetLatestQuotesService) {
    var authorId = $stateParams.authorId;
    var categoryId = $stateParams.categoryId;
    var userId = localStorage.getItem('userId');
    var pageCnt = 10;
    var pageno = 1;
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
      $scope.favshowhide = true;
      $scope.unfavshowhide = true;
    } else {
      $scope.favshowhide = false;
      $scope.unfavshowhide = false;
    }
    $scope.refreshHideShow = true;
    $scope.pagecount = function () {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      var favshowhide = '';
      var pageCnt = 10;
      var html = "";
      var incpageno = document.getElementById('pageno').value;
      var incpageno = parseInt(incpageno) + 1;
      var pageno = incpageno;
      var presentViewCount = pageCnt * pageno;
      document.getElementById('pageno').value = incpageno;
       if (authorId == 0 && categoryId == 0) {
        GetLatestQuotesService.GetLatestQuotes.get({ count: pageCnt, pageno: pageno, userId: userId }, function (response) {
          angular.forEach(response.latestquotes, function (value, key) {
            if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
              if (value.checkquotefav == 1) {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="favorite(' + value.qc_id + ')"><i class="icon ion-android-favorite" ></i></a>&nbsp;&nbsp;&nbsp;</span>';
              } else {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="unfavorite(' + value.qc_id + ')"><i class="icon ion-android-favorite-outline" ></i></a>&nbsp;&nbsp;&nbsp;</span>';
              }
            }
            html += '<div class="card card_list"><div class="item item-text-wrap"><span ng-click="latestquoteview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="latestquoteview(' + value.qc_id + ')"> ' + value.au_fname + ' ' + value.au_lname + '  </div><p class="text_right favoriate_s pos_rp">' + favshowhide + '<a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
          });
          angular.element(document.querySelector('#append_quotes_div')).append($compile(html)($scope));
          $ionicLoading.hide();
          if (response.totalLatestQuotes <= presentViewCount) {
            $scope.refreshHideShow = false;
          }
        })
      }
      else if (authorId != 0 && categoryId == 0) {
        GetAllAuthorsService.AuthorQuotes.save({ loadmorecount: pageCnt, au_id: authorId, pageno: pageno }, function (response) {
          angular.forEach(response.authorquotes, function (value, key) {
            if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
              if (value.checkquotefav == 1) {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="favorite(' + value.qc_id + ')"><i class="icon ion-android-favorite" ></i></a>&nbsp;&nbsp;&nbsp;</span>';
              } else {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="unfavorite(' + value.qc_id + ')"><i class="icon ion-android-favorite-outline" ></i></a>&nbsp;&nbsp;&nbsp;</span>';
              }
            }
            html += '<div class="card card_list"><div class="item item-text-wrap"><span ng-click="latestquoteview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="latestquoteview(' + value.qc_id + ')"> ' + value.au_fname + ' ' + value.au_lname + '  </div><p class="text_right favoriate_s pos_rp">' + favshowhide + '<a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
          });
          angular.element(document.querySelector('#append_quotes_div')).append($compile(html)($scope));
          $ionicLoading.hide();
          if (response.totalAuthorQuotes <= presentViewCount) {
            $scope.refreshHideShow = false;
          }
        })
      }
      else if (authorId == 0 && categoryId != 0) {
        GetCatageriosService.CatagoryQuotes.save({ loadmorecount: pageCnt, qc_cat_id: categoryId, pageno: pageno }, function (response) {
          angular.forEach(response.categoryquotes, function (value, key) {
            if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
              if (value.checkquotefav == 1) {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="favorite(' + value.qc_id + ')"><i class="icon ion-android-favorite" ></i></a>&nbsp;&nbsp;&nbsp;</span>';
              } else {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="unfavorite(' + value.qc_id + ')"><i class="icon ion-android-favorite-outline" ></i></a>&nbsp;&nbsp;&nbsp;</span>';
              }
            }
            html += '<div class="card card_list"><div class="item item-text-wrap"><span ng-click="latestquoteview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="latestquoteview(' + value.qc_id + ')"> ' + value.au_fname + ' ' + value.au_lname + '  </div><p class="text_right favoriate_s pos_rp">' + favshowhide + '<a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
          });
          angular.element(document.querySelector('#append_quotes_div')).append($compile(html)($scope));
          $ionicLoading.hide();
          if (response.totalCategoryQuotes <= presentViewCount) {
            $scope.refreshHideShow = false;
          }
        })
      }
    }

    if (authorId == 0 && categoryId == 0) {
      GetLatestQuotesService.GetLatestQuotes.get({ count: pageCnt, pageno: pageno, userId: userId }, function (response) {
        $scope.CatagoryQuotelist = response.latestquotes;
        $ionicLoading.hide();
        if (response.totalLatestQuotes <= 10) {
          $scope.refreshHideShow = false;
        }
      })
    }
    else if (authorId != 0 && categoryId == 0) {
      GetAllAuthorsService.AuthorQuotes.save({ loadmorecount: pageCnt, au_id: authorId, pageno: pageno, u_id: userId }, function (response) {
        $scope.CatagoryQuotelist = response.authorquotes;
        $ionicLoading.hide();
        if (response.totalAuthorQuotes <= 10) {
          $scope.refreshHideShow = false;
        }
      })
    }
    else if (authorId == 0 && categoryId != 0) {
      GetCatageriosService.CatagoryQuotes.save({ loadmorecount: pageCnt, qc_cat_id: categoryId, pageno: pageno, u_id: userId }, function (response) {
        $scope.CatagoryQuotelist = response.categoryquotes;
        $ionicLoading.hide();
        if (response.totalCategoryQuotes <= 10) {
          $scope.refreshHideShow = false;
        }
      })
    }

    $scope.shareQuote = function (message) {
      window.plugins.socialsharing.share(message, null, null, null);
    }

    $scope.favorite = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      GetLatestQuotesService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).html("");
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).append($compile('<a href="javascript:void(0)" ng-click="unfavorite(' + quoteId + ')"><i class="icon ion-android-favorite-outline"></i></a>&nbsp;&nbsp;&nbsp;')($scope));
        $ionicLoading.hide();
      })
    }

    $scope.unfavorite = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      GetLatestQuotesService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).html("");
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).append($compile('<a href="javascript:void(0)" ng-click="favorite(' + quoteId + ')"><i class="icon ion-android-favorite"></i></a>&nbsp;&nbsp;&nbsp;')($scope));
        $ionicLoading.hide();
      })
    }

    $scope.latestquoteview = function (quoteId) {
      if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
        var userId = localStorage.getItem('userId');
        GetLatestQuotesService.GetviewsCount.save({ u_id: userId, qc_id: quoteId }, function (response) {
          $scope.viewcounts = response;
          $ionicLoading.hide();
        })
      }
      else {
        var userId = '127.0.0.1';
        GetLatestQuotesService.GetviewsCount.save({ u_id: userId, qc_id: quoteId }, function (response) {
          $scope.viewcounts = response;
          $ionicLoading.hide();
        })
      }
      $state.go('app.quoteview', { quoteId: quoteId });
    }

  })

  .controller('AuthorsCtrl', function ($compile, $ionicLoading, $scope, $stateParams, $state, GetAllAuthorsService) {
    var categoryId = 0;
    var count = 5;
    var pageno = 1;
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    $scope.refreshHideShow = true;
    $scope.pagecount = function () {
      var count = 5;
      var html = "";
      var incpageno = document.getElementById('pageno').value;
      var incpageno = parseInt(incpageno) + 1;
      var pageno = incpageno;
      var presentViewCount = count * pageno;
      document.getElementById('pageno').value = incpageno;
      GetAllAuthorsService.GetAuthors.get({ count: count, pageno: incpageno }, function (response) {
        angular.forEach(response.authorArray, function (value, key) {
          html += ' <div class="list"><div class="item item-thumbnail-left animated fadeInRight"><img data-ng-src="http://aapthitech.com/ea/quotes/public/authorpics/' + value.au_pic + '" data-err-src="img/thumb1.png" ng-click="authorQuotes(' + value.au_id + ')" href="javascript:void(0);"/><h2 ng-click="authorQuotes(' + value.au_id + ')" href="javascript:void(0);"> ' + value.au_fname + ' ' + value.au_lname + '</h2><p class="date_c" ng-click="authorQuotes(' + value.au_id + ')" href="javascript:void(0);">' + value.au_birth_year + '-' + value.au_deadth_year + '</p><p class="text_normal" ng-click="authorQuotes(' + value.au_id + ')" href="javascript:void(0);">' + value.au_descrpt + '</p><div class="mar_left_80 text_right"><a ng-click="wikiLink(' + value.au_wiki_link + ')">Wiki Link</a></div></div></div>';
        });
        console.log(html);
        angular.element(document.querySelector('#append_authorlist_div')).append($compile(html)($scope));
        $ionicLoading.hide();
        if (response.totalAuthorsList <= presentViewCount) {
          $scope.refreshHideShow = false;
        }

      })
    }
    GetAllAuthorsService.GetAuthors.get({ count: count, pageno: pageno }, function (response) {
      $scope.Authorslist = response.authorArray;
      $ionicLoading.hide();
      if (response.totalAuthorsList <= 5) {
        $scope.refreshHideShow = false;
      }
    })
    $scope.authorQuotes = function (authorId) {
      $state.go('app.quotes', { authorId: authorId, categoryId: categoryId });
    }
    $scope.wikiLink = function (wikiURL) {
      cordova.InAppBrowser.open(wikiURL, '_blank');
    }

  })

  .controller('CategoriesCtrl', function ($compile, $ionicLoading, $rootScope, $scope, $stateParams, $state, GetCatageriosService) {
    var authorId = 0;
    var count = 5;
    var pageno = 1;
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    $scope.refreshHideShow = true;
    $scope.pagecount = function () {
      var count = 5;
      var html = "";
      var incpageno = document.getElementById('pageno').value;
      var incpageno = parseInt(incpageno) + 1;
      var pageno = incpageno;
      var presentViewCount = count * pageno;
      document.getElementById('pageno').value = incpageno;
      GetCatageriosService.GetCatagories.get({ count: count, pageno: incpageno }, function (response) {
        angular.forEach(response.catArray, function (value, key) {
          html += '<div class="cotagories"><a ng-click="catagoryQuotes(' + value.qc_cat_id + ')" href="javascript:void(0)" style="text-decoration: none"><button class="button button-block button-stable icon-right ion-chevron-right animated fadeInRight"> ' + value.qc_cat_name + '</button></a></div>';
        });
        angular.element(document.querySelector('#append_catlist_div')).append($compile(html)($scope));
        $ionicLoading.hide();
        if (response.totalCateList <= presentViewCount) {
          $scope.refreshHideShow = false;
        }
      })
    }
    GetCatageriosService.GetCatagories.get({ count: count, pageno: pageno }, function (response) {
      $scope.Catagorieslist = response.catArray;
      $ionicLoading.hide();
      if (response.totalCateList <= 5) {
        $scope.refreshHideShow = false;
      }
    })
    $scope.catagoryQuotes = function (categoryId) {
      $state.go('app.quotes', { authorId: authorId, categoryId: categoryId });
    }
  })

  .controller('UserQuotesCtrl', function ($compile, $ionicLoading, $rootScope, $scope, $stateParams, $state, GetUserQuotesService) {
    var userId = localStorage.getItem('userId');
    var flagId = $stateParams.flagId;
    var count = 10;
    var pageno = 1;
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    $scope.refreshHideShow = true;
    $scope.pagecount = function () {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      var count = 10;
      var html = "";
      var incpageno = document.getElementById('pageno').value;
      var incpageno = parseInt(incpageno) + 1;
      var pageno = incpageno;
      var presentViewCount = count * pageno;
      document.getElementById('pageno').value = incpageno;
      if (flagId == 0) {
        var favshowhide = '';
        GetUserQuotesService.GetTopQuotes.get({ count: count, pageno: incpageno, userId: userId }, function (response) {
          angular.forEach(response.topQuotes, function (value, key) {
            if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
              if (value.checkquotefav == 1) {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="favorite(' + value.qc_id + ')"><i class="icon ion-android-favorite"></i></a>&nbsp;&nbsp;&nbsp;</span>';
              } else {
                favshowhide = '<span id="favUnfav_id_' + value.qc_id + '"><a href="javascript:void(0)" ng-click="unfavorite(' + value.qc_id + ')"><i class="icon ion-android-favorite-outline"></i></a>&nbsp;&nbsp;&nbsp;</span>';
              }
            }
            html += ' <div class="card card_list" ><div class="item item-text-wrap"><span ng-click="Quotesview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="Quotesview(' + value.qc_id + ')">' + value.au_fname + ' ' + value.au_lname + ' </div><P class="text_right favoriate_s pos_rp">' + favshowhide + ' <a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
          });
          angular.element(document.querySelector('#append_topquotes_div')).append($compile(html)($scope));
          $ionicLoading.hide();
          if (response.totalTopQuotes <= presentViewCount) {
            $scope.refreshHideShow = false;
          }
        })
      }
      else if (flagId == 1) {
        GetUserQuotesService.GetFavoriteQuotes.get({ count: count, pageno: incpageno, userId: userId }, function (response) {
          angular.forEach(response.userFavorites, function (value, key) {
            html += ' <div class="card card_list" ><div class="item item-text-wrap"><span ng-click="Quotesview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="Quotesview(' + value.qc_id + ')">' + value.au_fname + ' ' + value.au_lname + ' </div><p class="text_right favoriate_s pos_rp"><a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
          });
          angular.element(document.querySelector('#append_topquotes_div')).append($compile(html)($scope));
          $ionicLoading.hide();
          if (response.totalFavoriteQuotes <= presentViewCount) {
            $scope.refreshHideShow = false;
          }
        })
      }
      else if (flagId == 2) {
        var editshowhide = '';
        var delshowhide = '';
        editshowhide = '';
        delshowhide = '';
        GetUserQuotesService.GetUserQuotes.get({ count: count, pageno: incpageno, userId: userId }, function (response) {
          angular.forEach(response.userquotes, function (value, key) {
            html += ' <div class="card card_list" ><div class="item item-text-wrap"><span ng-click="Quotesview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="Quotesview(' + value.qc_id + ')">' + value.au_fname + ' ' + value.au_lname + ' </div><P class="text_right favoriate_s pos_rp"><span><a href="javascript:void(0)" ng-click="editquote(' + value.qc_id + ')"><i class="icon ion-edit"style="display:' + editshowhide + '"></i></a>&nbsp;&nbsp;&nbsp;</span><span><a href="javascript:void(0)" ng-click="deletequote(' + value.qc_id + ')"><i class="icon ion-trash-a" style="display:' + delshowhide + '"></i></a>&nbsp;&nbsp;&nbsp;</span><a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
          });
          angular.element(document.querySelector('#append_topquotes_div')).append($compile(html)($scope));
          $ionicLoading.hide();
          if (response.totalUserQuotes <= presentViewCount) {
            $scope.refreshHideShow = false;
          }
        })
      }

    }
    if (flagId == 0) {
      if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
        $scope.favshowhide = true;
        $scope.unfavshowhide = true;
      } else {
        $scope.favshowhide = false;
        $scope.unfavshowhide = false;
      }
      GetUserQuotesService.GetTopQuotes.get({ count: count, pageno: pageno, userId: userId }, function (response) {
        $scope.userQuotesDetails = response.topQuotes;
        $ionicLoading.hide();
        if (response.totalTopQuotes <= 10) {
          $scope.refreshHideShow = false;
        }
      })
    }
    else if (flagId == 1) {
      GetUserQuotesService.GetFavoriteQuotes.get({ count: count, pageno: pageno, userId: userId }, function (response) {
        $scope.userQuotesDetails = response.userFavorites;
        $ionicLoading.hide();
        if (response.totalFavoriteQuotes <= 10) {
          $scope.refreshHideShow = false;
        }
      })
    }
    else if (flagId == 2) {
      $scope.editshowhide = true;
      $scope.delshowhide = true;
      GetUserQuotesService.GetUserQuotes.get({ count: count, pageno: pageno, userId: userId }, function (response) {
        $scope.userQuotesDetails = response.userquotes;
        $ionicLoading.hide();
        if (response.totalUserQuotes <= 10) {
          $scope.refreshHideShow = false;
        }
      })
    }

    $scope.shareQuote = function (message) {
      window.plugins.socialsharing.share(message, null, null, null);
    }
    $scope.favorite = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      GetUserQuotesService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).html("");
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).append($compile('<a href="javascript:void(0)" ng-click="unfavorite(' + quoteId + ')"><i class="icon ion-android-favorite-outline"></i></a>&nbsp;&nbsp;&nbsp;')($scope));
        $ionicLoading.hide();
      })
    }
    $scope.unfavorite = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      GetUserQuotesService.Favorites.save({ fav_u_id: userId, fav_qc_id: quoteId }, function (response) {
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).html("");
        angular.element(document.querySelector('#favUnfav_id_' + quoteId)).append($compile('<a href="javascript:void(0)" ng-click="favorite(' + quoteId + ')"><i class="icon ion-android-favorite"></i></a>&nbsp;&nbsp;&nbsp;')($scope));
        $ionicLoading.hide();
      })
    }

    $scope.editquote = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      $state.go('app.updatequote', { quoteId: quoteId });
      $ionicLoading.hide();
    }

    $scope.deletequote = function (quoteId) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      $scope.quoid = quoteId;
      var quoteid = btoa($scope.quoid);
      GetUserQuotesService.DeleteQuote.del({ quoteId: quoteid }, function (response) {
        angular.element(document.querySelector('#userquotes_' + quoteId)).remove();
        $ionicLoading.hide();
      })
    }

    $scope.Quotesview = function (quoteId) {
      if (typeof localStorage.getItem('userId') != 'undefined' && localStorage.getItem('userId') != null) {
        var userId = localStorage.getItem('userId');
        GetUserQuotesService.GetviewsCount.save({ u_id: userId, qc_id: quoteId }, function (response) {
          $scope.viewcounts = response;
          $ionicLoading.hide();
        })
      }
      else {
        var userId = '127.0.0.1';
        GetUserQuotesService.GetviewsCount.save({ u_id: userId, qc_id: quoteId }, function (response) {
          $scope.viewcounts = response;
          $ionicLoading.hide();
        })
      }
      $state.go('app.quoteview', { quoteId: quoteId });
    }
  })

  .controller('UpdateQuoteCtrl', function ($ionicLoading, $rootScope, $scope, $stateParams, $state, GetUserQuotesService,HomeService) {
     HomeService.Languages.get(function (response) {
      $scope.Languagelist = response.langList;
    })
    var userId = localStorage.getItem('userId');
    var quoid = $stateParams.quoteId;
    var quoteid = btoa(quoid);
    console.log(quoteid);
    GetUserQuotesService.EditQuote.get({ quoteId: quoteid }, function (response) {
      $scope.Editquotedata = response.quotedata;
      $ionicLoading.hide();
    })
    $scope.updatequote = function () {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      console.log("welcome");
      var catagories = [1, 2, 3];
      var quotename = document.getElementById('qname').value;
      var lang = document.getElementById('language').value;;
      var keytags = document.getElementById('qtags').value;
      GetUserQuotesService.GetUpdateQuoteInfo.put({ quoteId: quoteid, qc_lang_id: lang, qc_name: quotename, qc_tags: keytags, qc_qc_cat_id: catagories }, function (response) {
        $scope.UpdatedQuoteDetails = response;
        $state.go('app.userquotes', { userId: userId, flagId: 2 });
        $ionicLoading.hide();
      })
    }
  })

  .controller('ProfileCtrl', function ($compile, $ionicLoading, $rootScope, $scope, $stateParams, $state, ProfileService) {
    var userId = localStorage.getItem('userId');
    $scope.updateProfile = function (userId) {
      $state.go('app.updateprofile');

    }
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    ProfileService.GetUserInfo.get({ userId: userId }, function (response) {
      $scope.getUserDetails = response.usData;
      $ionicLoading.hide();

    });

    $scope.shareQuote = function (message) {
      window.plugins.socialsharing.share(message, null, null, null);
    }
    $scope.tabone = true;
    $scope.tabEv = function (typeDiv) {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      if (typeDiv == 1) {
        $scope.tabone = true;
        $scope.tabtwo = false;
        $scope.tabthree = false;
        ProfileService.GetUserInfo.get({ userId: userId }, function (response) {
          $scope.getUserDetails = response.usData;
          $ionicLoading.hide();
        })
      }
      else if (typeDiv == 2) {
        $scope.tabone = false;
        $scope.tabtwo = true;
        $scope.tabthree = false;
        var count = 10;
        var pageno = 1;
        ProfileService.GetFavoriteQuotes.get({ userId: userId, pageno: pageno, count: count }, function (response) {
          $scope.userQuotesDetails = response.userFavorites;
          $ionicLoading.hide();
          if (response.totalFavoriteQuotes <= 10) {
            $scope.refreshHideShow = false;
          }
          else {
            $scope.refreshHideShow = true;
            $scope.pagecount = function () {
              $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
              var count = 10;
              var html = "";
              var incpageno = document.getElementById('pageno').value;
              var incpageno = parseInt(incpageno) + 1;
              var pageno = incpageno;
              var presentViewCount = count * pageno;
              document.getElementById('pageno').value = incpageno;
              ProfileService.GetFavoriteQuotes.get({ userId: userId, pageno: pageno, count: count }, function (response) {
                angular.forEach(response.userFavorites, function (value, key) {
                  html += ' <div class="card card_list"><div class="item item-text-wrap"><span ng-click="latestquoteview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="latestquoteview(' + value.qc_id + ')"> ' + value.au_fname + '' + value.au_lname + '</div><P class="text_right favoriate_s pos_rp"><a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
                });
                angular.element(document.querySelector('#append_favorites')).append($compile(html)($scope));
                $ionicLoading.hide();
                if (response.totalFavoriteQuotes <= presentViewCount) {
                  $scope.refreshHideShow = false;
                }
              })
            }
          }
        })
      }
      else if (typeDiv == 3) {
        $scope.tabone = false;
        $scope.tabtwo = false;
        $scope.tabthree = true;
        var count = 10;
        var pageno = 1;
        ProfileService.GetUserQuotes.get({ userId: userId, pageno: pageno, count: count }, function (response) {
          $scope.userQuotesDetails = response.userquotes;
          $ionicLoading.hide();
          if (response.totalUserQuotes <= 10) {
            $scope.refreshHideShow = false;
          }
          else {
            $scope.refreshHideShow = true;
            $scope.pagecount = function () {
              $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
              var count = 10;
              var html = "";
              var incpageno = document.getElementById('pageno').value;
              var incpageno = parseInt(incpageno) + 1;
              var pageno = incpageno;
              var presentViewCount = count * pageno;
              document.getElementById('pageno').value = incpageno;
              ProfileService.GetUserQuotes.get({ userId: userId, pageno: pageno, count: count }, function (response) {
                angular.forEach(response.userquotes, function (value, key) {
                  html += ' <div class="card card_list"><div class="item item-text-wrap"><span ng-click="latestquoteview(' + value.qc_id + ')">' + value.qc_name + '</span><div class="author_name" ng-click="latestquoteview(' + value.qc_id + ')"> ' + value.au_fname + ' ' + value.au_lname + '</div><P class="text_right favoriate_s pos_rp"><a href="javascript:void(0)" ng-click="shareQuote(' + value.qc_id + ')"><i class="icon ion-android-share-alt"></i></a></p></div></div>';
                });
                angular.element(document.querySelector('#append_userquotes')).append($compile(html)($scope));
                $ionicLoading.hide();
                if (response.totalUserQuotes <= presentViewCount) {
                  $scope.refreshHideShow = false;
                }
              })
            }
          }

        })
      }
    }
    $scope.latestquoteview = function (quoteId) {
      $state.go('app.quoteview', { quoteId: quoteId });
    }
  })

  .controller('UpdateProfileCtrl', function ($ionicLoading, $rootScope, $scope, $stateParams, $state, ProfileService) {
    var userId = localStorage.getItem('userId');
    $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
    ProfileService.GetUserDetails.get({ userId: userId }, function (response) {
      $scope.userDetails = response.usData;
      $ionicLoading.hide();
    })
    $scope.updateuser = function () {
      $ionicLoading.show({ template: '<img src="img/ajax-loader1.gif">' });
      var username = document.getElementById('userName').value;
      var imgfile = document.getElementById('imagefile').value;
      var aboutme = document.getElementById('aboutMe').value;
      ProfileService.GetUpdateProfileInfo.put({ userId: userId, fname: username, uf_pic: imgfile, uf_about_me: aboutme }, function (response) {
        $scope.UpdatedUserDetails = response;
        console.log($scope.UpdatedUserDetails);
        $state.go('app.profile');
        $ionicLoading.hide();
      })
    }
  });
